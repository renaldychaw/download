Set WshShell = CreateObject("WScript.Shell")
WshShell.Run chr(34) & CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName) & "\Start WMS Server.bat" & chr(34), 7
' 7 = minimized window, server runs in background
