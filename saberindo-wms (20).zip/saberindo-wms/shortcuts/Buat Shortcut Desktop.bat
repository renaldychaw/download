@echo off
title Saberindo WMS - Buat Shortcut Desktop
color 0B

echo.
echo  ==============================================
echo    Saberindo WMS - Buat Shortcut Desktop
echo  ==============================================
echo.

for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    set "LOCAL_IP=%%a"
    goto :found_ip
)
:found_ip
set "LOCAL_IP=%LOCAL_IP: =%"

echo  IP komputer ini: %LOCAL_IP%
echo.
echo  Pilih mode:
echo    1. Shortcut untuk PC INI - localhost
echo    2. Shortcut untuk PC LAIN - IP: %LOCAL_IP%
echo.
set /p MODE="  Pilih (1/2): "

if "%MODE%"=="1" (
    set "WMS_URL=http://localhost:3000"
) else (
    set "WMS_URL=http://%LOCAL_IP%:3000"
)

set "DESKTOP=%USERPROFILE%\Desktop"

echo [InternetShortcut]> "%DESKTOP%\Saberindo WMS.url"
echo URL=%WMS_URL%>> "%DESKTOP%\Saberindo WMS.url"
echo IconFile=C:\Windows\System32\shell32.dll>> "%DESKTOP%\Saberindo WMS.url"
echo IconIndex=13>> "%DESKTOP%\Saberindo WMS.url"

echo.
echo  ==============================================
echo  Shortcut berhasil dibuat di Desktop
echo  URL: %WMS_URL%
echo  ==============================================
echo.

pause
