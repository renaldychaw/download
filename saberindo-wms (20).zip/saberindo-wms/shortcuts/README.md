# Panduan Setup — Saberindo WMS

## Setup PC Server (sekali saja)

1. Klik 2x **`INSTALL.bat`** di root folder project
2. Script akan otomatis:
   - Cek Node.js → jika belum ada, buka halaman download
   - Cek Python → jika belum ada, buka halaman download
   - Install pdfplumber (Python)
   - Install npm packages
   - Buat file `.env.local`
   - Buat shortcut di Desktop
3. Setelah semua OK, pilih `y` untuk langsung jalankan server

## Setup PC Kepala Gudang / Staff (sekali saja)

1. Copy file **`SETUP-CLIENT.bat`** ke PC kepala gudang (via flashdisk/share folder)
2. Klik 2x → masukkan IP PC Server (contoh: `192.168.1.100`)
3. Shortcut "Saberindo WMS" otomatis muncul di Desktop
4. Selesai — klik icon kapan saja untuk buka WMS

## Penggunaan Sehari-hari

### PC Server:
- Klik 2x **"Start WMS Server"** di Desktop (atau di folder `shortcuts/`)
- Biarkan window terbuka selama jam kerja
- Atau taruh `Start WMS (Background).vbs` di folder Startup (`Win+R` → `shell:startup`)

### PC Kepala Gudang / Staff:
- Klik 2x **"Saberindo WMS"** di Desktop → langsung buka browser

## File-file

| File | Fungsi |
|------|--------|
| `INSTALL.bat` | Auto-installer untuk PC Server |
| `SETUP-CLIENT.bat` | Setup shortcut untuk PC Staff |
| `shortcuts/Start WMS Server.bat` | Start server + buka browser |
| `shortcuts/Start WMS (Background).vbs` | Start server minimized |
| `shortcuts/Start WMS Production.bat` | Build + start production |
| `shortcuts/Buat Shortcut Desktop.bat` | Buat shortcut manual |

## Tips

- **Firewall:** Buka port 3000 di Windows Firewall agar PC lain bisa akses
- **Auto-start:** Copy `shortcuts/Start WMS (Background).vbs` ke `shell:startup`
- **Password default:** `saberindo2024` (ubah di `.env.local`)
