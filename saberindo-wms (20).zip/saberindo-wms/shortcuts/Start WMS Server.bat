@echo off
title Saberindo WMS Server
color 0A

echo.
echo  ==============================================
echo    Saberindo WMS - Fire Protection
echo    Warehouse Management System
echo  ==============================================
echo.

cd /d "%~dp0.."

if not exist "node_modules" (
    echo  Installing dependencies...
    call npm install
    echo.
)

echo  Starting server...
echo  Buka browser: http://localhost:3000
echo  Tekan Ctrl+C untuk stop server
echo.

start /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:3000"

call npm run dev
