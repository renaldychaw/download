import { NextRequest, NextResponse } from "next/server";
import { getAllTransaksi, createTransaksi } from "@/lib/excel";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";
import { TransaksiFormData } from "@/lib/types";

// GET /api/transaksi — get all transactions, optionally filtered by barangId
export async function GET(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const { searchParams } = new URL(request.url);
    const barangId = searchParams.get("barangId");

    let transaksi = await getAllTransaksi();

    if (barangId) {
      transaksi = transaksi.filter((t) => t.barangId === barangId);
    }

    return NextResponse.json({ success: true, data: transaksi });
  } catch (error) {
    console.error("GET /api/transaksi error:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengambil data transaksi" },
      { status: 500 }
    );
  }
}

// POST /api/transaksi — create new transaction (auto-updates stock)
export async function POST(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const body: TransaksiFormData = await request.json();

    // Validation
    if (!body.barangId || !body.tipe || !body.jumlah) {
      return NextResponse.json(
        { success: false, error: "Barang, Tipe, dan Jumlah wajib diisi" },
        { status: 400 }
      );
    }

    if (body.jumlah <= 0) {
      return NextResponse.json(
        { success: false, error: "Jumlah harus lebih dari 0" },
        { status: 400 }
      );
    }

    if (body.tipe !== "Masuk" && body.tipe !== "Keluar") {
      return NextResponse.json(
        { success: false, error: "Tipe harus 'Masuk' atau 'Keluar'" },
        { status: 400 }
      );
    }

    const result = await createTransaksi(body);

    const tipeLabel = body.tipe === "Masuk" ? "Barang Masuk" : "Barang Keluar";

    return NextResponse.json(
      {
        success: true,
        data: result,
        message: `${tipeLabel} berhasil dicatat. Stok ${result.barang.kode}: ${result.transaksi.stokSebelum} → ${result.transaksi.stokSesudah} ${result.barang.satuan}`,
      },
      { status: 201 }
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Gagal mencatat transaksi";
    console.error("POST /api/transaksi error:", message);
    return NextResponse.json(
      { success: false, error: message },
      { status: 400 }
    );
  }
}
