import { NextRequest, NextResponse } from "next/server";
import { getAllLokasi, createLokasi, updateLokasi, deleteLokasi } from "@/lib/excel";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";
import { LokasiFormData } from "@/lib/types";

export async function GET(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const lokasi = await getAllLokasi();
    return NextResponse.json({ success: true, data: lokasi });
  } catch (error) {
    console.error("GET /api/lokasi error:", error);
    return NextResponse.json({ success: false, error: "Gagal mengambil data lokasi" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const body: LokasiFormData = await request.json();
    if (!body.kode || !body.nama || !body.zona) {
      return NextResponse.json({ success: false, error: "Kode, Nama, dan Zona wajib diisi" }, { status: 400 });
    }
    const newLokasi = await createLokasi(body);
    return NextResponse.json({ success: true, data: newLokasi, message: "Lokasi berhasil ditambahkan" }, { status: 201 });
  } catch (error) {
    console.error("POST /api/lokasi error:", error);
    return NextResponse.json({ success: false, error: "Gagal menambahkan lokasi" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const body = await request.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ success: false, error: "ID lokasi wajib diisi" }, { status: 400 });
    const updated = await updateLokasi(id, data as LokasiFormData);
    if (!updated) return NextResponse.json({ success: false, error: "Lokasi tidak ditemukan" }, { status: 404 });
    return NextResponse.json({ success: true, data: updated, message: "Lokasi berhasil diperbarui" });
  } catch (error) {
    console.error("PUT /api/lokasi error:", error);
    return NextResponse.json({ success: false, error: "Gagal memperbarui lokasi" }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "ID lokasi wajib diisi" }, { status: 400 });
    const deleted = await deleteLokasi(id);
    if (!deleted) return NextResponse.json({ success: false, error: "Lokasi tidak ditemukan" }, { status: 404 });
    return NextResponse.json({ success: true, message: "Lokasi berhasil dihapus" });
  } catch (error) {
    console.error("DELETE /api/lokasi error:", error);
    return NextResponse.json({ success: false, error: "Gagal menghapus lokasi" }, { status: 500 });
  }
}
