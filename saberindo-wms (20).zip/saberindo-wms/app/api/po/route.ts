import { NextRequest, NextResponse } from "next/server";
import { getAllPO, createPO, updatePO, deletePO, recalcAllPOStatuses } from "@/lib/excel";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";
import { POFormData } from "@/lib/types";
import { execSync } from "child_process";
import fs from "fs";
import path from "path";
import os from "os";

// GET /api/po — list all POs
export async function GET(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const poList = await getAllPO();
    return NextResponse.json({ success: true, data: poList });
  } catch (error) {
    console.error("GET /api/po error:", error);
    return NextResponse.json({ success: false, error: "Gagal mengambil data PO" }, { status: 500 });
  }
}

// POST /api/po — create PO or parse PDF via Python pdfplumber
export async function POST(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const contentType = request.headers.get("content-type") || "";

    // PDF upload → parse with Python pdfplumber
    if (contentType.includes("multipart/form-data")) {
      const formData = await request.formData();
      const files = formData.getAll("files") as File[];

      if (!files.length) {
        return NextResponse.json({ success: false, error: "Tidak ada file PDF" }, { status: 400 });
      }

      // Save uploaded files to temp directory
      const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "po-"));
      const tmpPaths: string[] = [];

      try {
        for (const file of files) {
          const buffer = Buffer.from(await file.arrayBuffer());
          const tmpPath = path.join(tmpDir, file.name.replace(/[^a-zA-Z0-9._-]/g, "_"));
          fs.writeFileSync(tmpPath, buffer);
          tmpPaths.push(tmpPath);
        }

        // Call Python parser (python on Windows, python3 on Linux/Mac)
        const scriptPath = path.join(process.cwd(), "scripts", "parse-po.py");
        const args = tmpPaths.map((p) => `"${p}"`).join(" ");
        const pythonCmd = process.platform === "win32" ? "python" : "python3";
        const cmd = `${pythonCmd} "${scriptPath}" ${args}`;

        const output = execSync(cmd, {
          encoding: "utf-8",
          timeout: 60000,
          maxBuffer: 10 * 1024 * 1024,
        });

        const allParsed = JSON.parse(output);

        if (allParsed.length === 0) {
          return NextResponse.json(
            { success: false, error: "Tidak ada data PO yang berhasil diekstrak dari PDF" },
            { status: 422 }
          );
        }

        return NextResponse.json({
          success: true,
          data: allParsed,
          message: `${allParsed.length} PO berhasil diekstrak dari ${files.length} file`,
        });
      } finally {
        // Cleanup temp files
        for (const p of tmpPaths) {
          try { fs.unlinkSync(p); } catch {}
        }
        try { fs.rmdirSync(tmpDir); } catch {}
      }
    }

    // JSON body → create PO (single or batch array)
    const body = await request.json();

    // Batch mode: array of POs (dari hasil ekstrak PDF)
    if (Array.isArray(body)) {
      if (body.length === 0) {
        return NextResponse.json({ success: false, error: "Tidak ada PO yang dikirim" }, { status: 400 });
      }

      const created = [];
      const errors: string[] = [];

      for (const poData of body as POFormData[]) {
        if (!poData.poNumber) {
          errors.push(`PO dilewati: PO Number kosong`);
          continue;
        }
        // Default supplier jika kosong
        if (!poData.supplier) poData.supplier = "-";
        try {
          const newPO = await createPO(poData);
          created.push(newPO);
        } catch (e) {
          errors.push(`Gagal simpan PO ${poData.poNumber}: ${e instanceof Error ? e.message : String(e)}`);
        }
      }

      if (created.length === 0) {
        return NextResponse.json(
          { success: false, error: errors.join("; ") || "Semua PO gagal disimpan" },
          { status: 422 }
        );
      }

      return NextResponse.json(
        {
          success: true,
          data: created,
          message: `${created.length} PO berhasil disimpan`,
          ...(errors.length ? { warnings: errors } : {}),
        },
        { status: 201 }
      );
    }

    // Single mode: satu object PO
    const singlePO = body as POFormData;
    if (!singlePO.poNumber) {
      return NextResponse.json({ success: false, error: "PO Number wajib diisi" }, { status: 400 });
    }
    if (!singlePO.supplier) singlePO.supplier = "-";

    const newPO = await createPO(singlePO);
    return NextResponse.json({ success: true, data: newPO, message: "PO berhasil disimpan" }, { status: 201 });
  } catch (error) {
    console.error("POST /api/po error:", error);
    return NextResponse.json({ success: false, error: "Gagal memproses PO" }, { status: 500 });
  }
}

// PUT /api/po — update PO
export async function PUT(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const body = await request.json();
    const { id, ...data } = body;
    if (!id) return NextResponse.json({ success: false, error: "ID PO wajib diisi" }, { status: 400 });
    const updated = await updatePO(id, data);
    if (!updated) return NextResponse.json({ success: false, error: "PO tidak ditemukan" }, { status: 404 });
    return NextResponse.json({ success: true, data: updated, message: "PO berhasil diperbarui" });
  } catch (error) {
    console.error("PUT /api/po error:", error);
    return NextResponse.json({ success: false, error: "Gagal memperbarui PO" }, { status: 500 });
  }
}

// DELETE /api/po?id=xxx
export async function DELETE(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "ID PO wajib diisi" }, { status: 400 });
    const deleted = await deletePO(id);
    if (!deleted) return NextResponse.json({ success: false, error: "PO tidak ditemukan" }, { status: 404 });
    return NextResponse.json({ success: true, message: "PO berhasil dihapus" });
  } catch (error) {
    console.error("DELETE /api/po error:", error);
    return NextResponse.json({ success: false, error: "Gagal menghapus PO" }, { status: 500 });
  }
}

// PATCH /api/po — recalculate all PO statuses
export async function PATCH(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();
  try {
    const fixed = await recalcAllPOStatuses();
    return NextResponse.json({ success: true, fixed, message: `${fixed} status PO berhasil diperbaiki` });
  } catch (error) {
    console.error("PATCH /api/po error:", error);
    return NextResponse.json({ success: false, error: "Gagal recalculate status PO" }, { status: 500 });
  }
}