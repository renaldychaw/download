import { NextRequest, NextResponse } from "next/server";
import { receiveFromPO, ReceiveItem } from "@/lib/excel";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";

// POST /api/po/receive — receive items from a PO
export async function POST(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const body = await request.json();
    const { poId, items, keterangan } = body as {
      poId: string;
      items: ReceiveItem[];
      keterangan: string;
    };

    if (!poId) {
      return NextResponse.json({ success: false, error: "PO ID wajib diisi" }, { status: 400 });
    }

    if (!items || items.length === 0) {
      return NextResponse.json({ success: false, error: "Tidak ada item yang diterima" }, { status: 400 });
    }

    const validItems = items.filter((i) => i.qtyToReceive > 0);
    if (validItems.length === 0) {
      return NextResponse.json({ success: false, error: "Jumlah penerimaan harus lebih dari 0" }, { status: 400 });
    }

    const result = await receiveFromPO(poId, validItems, keterangan || "");

    return NextResponse.json({
      success: true,
      data: result,
      message: `${result.created} item berhasil diterima dari PO. Stok & transaksi otomatis diperbarui.`,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Gagal menerima barang";
    console.error("POST /api/po/receive error:", message);
    return NextResponse.json({ success: false, error: message }, { status: 400 });
  }
}
