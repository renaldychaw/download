import { NextRequest, NextResponse } from "next/server";
import { getAllTransaksi, getAllBarang, generateExcelReport } from "@/lib/excel";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";
import { Transaksi, LaporanSummary } from "@/lib/types";

// Helper: parse Indonesian date string "d/m/yy hh.mm.ss" to comparable format
function parseTanggal(tanggal: string): Date | null {
  try {
    // Format from getNow(): "d/m/yy, hh.mm.ss" or "d/m/yyyy, hh.mm.ss"
    const parts = tanggal.split(",")[0]?.trim().split("/");
    if (!parts || parts.length < 3) return null;
    const day = parseInt(parts[0]);
    const month = parseInt(parts[1]) - 1;
    let year = parseInt(parts[2]);
    if (year < 100) year += 2000;
    return new Date(year, month, day);
  } catch {
    return null;
  }
}

function filterTransaksi(
  list: Transaksi[],
  dari: string,
  sampai: string,
  tipe: string,
  kategori: string,
  barangKategori: Record<string, string>
): Transaksi[] {
  return list.filter((trx) => {
    // Filter by tipe
    if (tipe && trx.tipe !== tipe) return false;

    // Filter by kategori (match barang's kategori)
    if (kategori && barangKategori[trx.barangId] !== kategori) return false;

    // Filter by date range
    if (dari || sampai) {
      const trxDate = parseTanggal(trx.tanggal);
      if (!trxDate) return true; // can't parse, include it

      if (dari) {
        const fromDate = new Date(dari);
        fromDate.setHours(0, 0, 0, 0);
        if (trxDate < fromDate) return false;
      }
      if (sampai) {
        const toDate = new Date(sampai);
        toDate.setHours(23, 59, 59, 999);
        if (trxDate > toDate) return false;
      }
    }

    return true;
  });
}

function buildSummary(filtered: Transaksi[]): LaporanSummary {
  const masuk = filtered.filter((t) => t.tipe === "Masuk");
  const keluar = filtered.filter((t) => t.tipe === "Keluar");

  const qtyMasuk = masuk.reduce((s, t) => s + t.jumlah, 0);
  const qtyKeluar = keluar.reduce((s, t) => s + t.jumlah, 0);

  // Find most frequent barang
  const masukCount: Record<string, number> = {};
  const keluarCount: Record<string, number> = {};
  masuk.forEach((t) => { masukCount[t.namaBarang] = (masukCount[t.namaBarang] || 0) + t.jumlah; });
  keluar.forEach((t) => { keluarCount[t.namaBarang] = (keluarCount[t.namaBarang] || 0) + t.jumlah; });

  const topMasuk = Object.entries(masukCount).sort((a, b) => b[1] - a[1])[0];
  const topKeluar = Object.entries(keluarCount).sort((a, b) => b[1] - a[1])[0];

  return {
    totalTransaksi: filtered.length,
    totalMasuk: masuk.length,
    totalKeluar: keluar.length,
    jumlahMasuk: qtyMasuk,
    jumlahKeluar: qtyKeluar,
    barangTerbanyakMasuk: topMasuk ? `${topMasuk[0]} (${topMasuk[1]})` : "-",
    barangTerbanyakKeluar: topKeluar ? `${topKeluar[0]} (${topKeluar[1]})` : "-",
  };
}

// GET /api/laporan — get filtered transactions + summary
export async function GET(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const { searchParams } = new URL(request.url);
    const dari = searchParams.get("dari") || "";
    const sampai = searchParams.get("sampai") || "";
    const tipe = searchParams.get("tipe") || "";
    const kategori = searchParams.get("kategori") || "";
    const format = searchParams.get("format") || "json";

    const allTransaksi = await getAllTransaksi();
    const allBarang = await getAllBarang();

    // Build barang kategori map
    const barangKategori: Record<string, string> = {};
    allBarang.forEach((b) => { barangKategori[b.id] = b.kategori; });

    const filtered = filterTransaksi(allTransaksi, dari, sampai, tipe, kategori, barangKategori);

    // Excel export
    if (format === "excel") {
      const buffer = await generateExcelReport(filtered, allBarang, { dari, sampai, tipe });
      const filename = `laporan_${dari || "all"}_${sampai || "now"}.xlsx`;

      return new NextResponse(new Uint8Array(buffer), {
        headers: {
          "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "Content-Disposition": `attachment; filename="${filename}"`,
        },
      });
    }

    // JSON response
    const summary = buildSummary(filtered);
    return NextResponse.json({
      success: true,
      data: { transaksi: filtered, summary, totalBarang: allBarang.length },
    });
  } catch (error) {
    console.error("GET /api/laporan error:", error);
    return NextResponse.json({ success: false, error: "Gagal membuat laporan" }, { status: 500 });
  }
}