import { NextRequest, NextResponse } from "next/server";
import {
  getAllBarang,
  createBarang,
  updateBarang,
  deleteBarang,
  getDashboardStats,
} from "@/lib/excel";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";
import { BarangFormData } from "@/lib/types";

// GET /api/barang
export async function GET(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const { searchParams } = new URL(request.url);

    if (searchParams.get("stats") === "true") {
      const stats = await getDashboardStats();
      return NextResponse.json({ success: true, data: stats });
    }

    const barang = await getAllBarang();
    return NextResponse.json({ success: true, data: barang });
  } catch (error) {
    console.error("GET /api/barang error:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengambil data barang" },
      { status: 500 }
    );
  }
}

// POST /api/barang
export async function POST(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const body: BarangFormData = await request.json();

    if (!body.kode || !body.nama || !body.kategori || !body.satuan) {
      return NextResponse.json(
        { success: false, error: "Kode, Nama, Kategori, dan Satuan wajib diisi" },
        { status: 400 }
      );
    }

    const newBarang = await createBarang(body);
    return NextResponse.json(
      { success: true, data: newBarang, message: "Barang berhasil ditambahkan" },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST /api/barang error:", error);
    return NextResponse.json(
      { success: false, error: "Gagal menambahkan barang" },
      { status: 500 }
    );
  }
}

// PUT /api/barang
export async function PUT(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const body = await request.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID barang wajib diisi" },
        { status: 400 }
      );
    }

    const updated = await updateBarang(id, data as BarangFormData);

    if (!updated) {
      return NextResponse.json(
        { success: false, error: "Barang tidak ditemukan" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      data: updated,
      message: "Barang berhasil diperbarui",
    });
  } catch (error) {
    console.error("PUT /api/barang error:", error);
    return NextResponse.json(
      { success: false, error: "Gagal memperbarui barang" },
      { status: 500 }
    );
  }
}

// DELETE /api/barang
export async function DELETE(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "ID barang wajib diisi" },
        { status: 400 }
      );
    }

    const deleted = await deleteBarang(id);

    if (!deleted) {
      return NextResponse.json(
        { success: false, error: "Barang tidak ditemukan" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Barang berhasil dihapus",
    });
  } catch (error) {
    console.error("DELETE /api/barang error:", error);
    return NextResponse.json(
      { success: false, error: "Gagal menghapus barang" },
      { status: 500 }
    );
  }
}
