import { NextRequest, NextResponse } from "next/server";
import { verifyAuth, unauthorizedResponse } from "@/lib/auth";
import { getExcelPath } from "@/lib/excel";
import fs from "fs";

// GET /api/download — download file warehouse.xlsx
export async function GET(request: NextRequest) {
  if (!verifyAuth(request)) return unauthorizedResponse();

  try {
    const filePath = getExcelPath();

    if (!fs.existsSync(filePath)) {
      return NextResponse.json(
        { success: false, error: "File Excel belum dibuat" },
        { status: 404 }
      );
    }

    const fileBuffer = fs.readFileSync(filePath);
    const filename = `warehouse_${new Date().toISOString().slice(0, 10)}.xlsx`;

    return new NextResponse(new Uint8Array(fileBuffer), {
      headers: {
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (error) {
    console.error("GET /api/download error:", error);
    return NextResponse.json(
      { success: false, error: "Gagal mengunduh file" },
      { status: 500 }
    );
  }
}
