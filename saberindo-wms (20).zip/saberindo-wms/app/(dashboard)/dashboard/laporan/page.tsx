"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import {
  FileBarChart, Search, Filter, RefreshCw, Loader2,
  Download, ArrowDownToLine, ArrowUpFromLine, Printer,
  Calendar, TrendingUp, TrendingDown, ArrowLeftRight,
  FileSpreadsheet, PackagePlus, PackageMinus,
} from "lucide-react";
import { Transaksi, LaporanSummary, KATEGORI_OPTIONS } from "@/lib/types";
import toast from "react-hot-toast";

export default function LaporanPage() {
  // Filters
  const [dari, setDari] = useState("");
  const [sampai, setSampai] = useState("");
  const [tipe, setTipe] = useState<"" | "Masuk" | "Keluar">("");
  const [kategori, setKategori] = useState("");

  // Data
  const [transaksiList, setTransaksiList] = useState<Transaksi[]>([]);
  const [summary, setSummary] = useState<LaporanSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [hasFetched, setHasFetched] = useState(false);

  // Quick date filters
  const setQuickRange = (days: number) => {
    const end = new Date();
    const start = new Date();
    start.setDate(start.getDate() - days);
    setDari(start.toISOString().slice(0, 10));
    setSampai(end.toISOString().slice(0, 10));
  };

  const setThisMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth(), 1);
    setDari(start.toISOString().slice(0, 10));
    setSampai(now.toISOString().slice(0, 10));
  };

  const setLastMonth = () => {
    const now = new Date();
    const start = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const end = new Date(now.getFullYear(), now.getMonth(), 0);
    setDari(start.toISOString().slice(0, 10));
    setSampai(end.toISOString().slice(0, 10));
  };

  // Fetch report data
  const fetchReport = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (dari) params.set("dari", dari);
      if (sampai) params.set("sampai", sampai);
      if (tipe) params.set("tipe", tipe);
      if (kategori) params.set("kategori", kategori);

      const res = await fetch(`/api/laporan?${params.toString()}`);
      const data = await res.json();

      if (data.success) {
        setTransaksiList(data.data.transaksi);
        setSummary(data.data.summary);
        setHasFetched(true);
      } else {
        toast.error(data.error || "Gagal memuat laporan");
      }
    } catch {
      toast.error("Gagal terhubung ke server");
    } finally {
      setLoading(false);
    }
  }, [dari, sampai, tipe, kategori]);

  // Export to Excel
  const exportExcel = async () => {
    setExporting(true);
    try {
      const params = new URLSearchParams();
      if (dari) params.set("dari", dari);
      if (sampai) params.set("sampai", sampai);
      if (tipe) params.set("tipe", tipe);
      if (kategori) params.set("kategori", kategori);
      params.set("format", "excel");

      const res = await fetch(`/api/laporan?${params.toString()}`);
      if (!res.ok) {
        toast.error("Gagal membuat laporan Excel");
        return;
      }

      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `laporan_${dari || "all"}_${sampai || "now"}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Laporan Excel berhasil diunduh");
    } catch {
      toast.error("Gagal mengunduh laporan");
    } finally {
      setExporting(false);
    }
  };

  // Print (PDF via browser print dialog)
  const handlePrint = () => {
    window.print();
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Laporan & Export</h1>
          <p className="text-sm text-navy-500 mt-1">
            Buat laporan transaksi dan ekspor ke Excel/PDF
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={exportExcel}
            disabled={exporting || !hasFetched || transaksiList.length === 0}
            className="btn-primary bg-emerald-600 hover:bg-emerald-700"
          >
            {exporting ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
            Export Excel
          </button>
          <button
            onClick={handlePrint}
            disabled={!hasFetched || transaksiList.length === 0}
            className="btn-secondary"
          >
            <Printer className="w-4 h-4" />
            Cetak PDF
          </button>
        </div>
      </div>

      {/* Filter Section */}
      <div className="card p-5 mb-6 print:hidden">
        <h3 className="text-sm font-semibold text-navy-700 mb-4 flex items-center gap-2">
          <Filter className="w-4 h-4" />
          Filter Laporan
        </h3>

        {/* Quick date buttons */}
        <div className="flex flex-wrap gap-2 mb-4">
          <button onClick={() => setQuickRange(7)} className="text-xs px-3 py-1.5 rounded-lg border border-navy-200 text-navy-600 hover:bg-navy-50 transition-colors">
            7 Hari Terakhir
          </button>
          <button onClick={() => setQuickRange(30)} className="text-xs px-3 py-1.5 rounded-lg border border-navy-200 text-navy-600 hover:bg-navy-50 transition-colors">
            30 Hari Terakhir
          </button>
          <button onClick={setThisMonth} className="text-xs px-3 py-1.5 rounded-lg border border-navy-200 text-navy-600 hover:bg-navy-50 transition-colors">
            Bulan Ini
          </button>
          <button onClick={setLastMonth} className="text-xs px-3 py-1.5 rounded-lg border border-navy-200 text-navy-600 hover:bg-navy-50 transition-colors">
            Bulan Lalu
          </button>
          <button onClick={() => { setDari(""); setSampai(""); }} className="text-xs px-3 py-1.5 rounded-lg border border-navy-200 text-navy-500 hover:bg-navy-50 transition-colors">
            Semua Waktu
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
          <div>
            <label className="label">Dari Tanggal</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
              <input type="date" value={dari} onChange={(e) => setDari(e.target.value)} className="input-field pl-10" />
            </div>
          </div>
          <div>
            <label className="label">Sampai Tanggal</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
              <input type="date" value={sampai} onChange={(e) => setSampai(e.target.value)} className="input-field pl-10" />
            </div>
          </div>
          <div>
            <label className="label">Tipe Transaksi</label>
            <select value={tipe} onChange={(e) => setTipe(e.target.value as "" | "Masuk" | "Keluar")} className="input-field">
              <option value="">Semua</option>
              <option value="Masuk">Barang Masuk</option>
              <option value="Keluar">Barang Keluar</option>
            </select>
          </div>
          <div>
            <label className="label">Kategori Barang</label>
            <select value={kategori} onChange={(e) => setKategori(e.target.value)} className="input-field">
              <option value="">Semua Kategori</option>
              {KATEGORI_OPTIONS.map((k) => (<option key={k} value={k}>{k}</option>))}
            </select>
          </div>
        </div>

        <button onClick={fetchReport} disabled={loading} className="btn-primary w-full sm:w-auto">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
          Tampilkan Laporan
        </button>
      </div>

      {/* Summary Cards */}
      {summary && hasFetched && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <div className="card p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
                <ArrowLeftRight className="w-5 h-5 text-blue-500" />
              </div>
              <div>
                <p className="text-xs text-navy-500">Total Transaksi</p>
                <p className="text-xl font-bold text-navy-900">{summary.totalTransaksi}</p>
              </div>
            </div>
          </div>

          <div className="card p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center">
                <PackagePlus className="w-5 h-5 text-emerald-500" />
              </div>
              <div>
                <p className="text-xs text-navy-500">Barang Masuk</p>
                <p className="text-xl font-bold text-emerald-700">{summary.totalMasuk}</p>
                <p className="text-[11px] text-navy-400">{summary.jumlahMasuk.toLocaleString("id-ID")} unit</p>
              </div>
            </div>
          </div>

          <div className="card p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                <PackageMinus className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <p className="text-xs text-navy-500">Barang Keluar</p>
                <p className="text-xl font-bold text-red-700">{summary.totalKeluar}</p>
                <p className="text-[11px] text-navy-400">{summary.jumlahKeluar.toLocaleString("id-ID")} unit</p>
              </div>
            </div>
          </div>

          <div className="card p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center">
                {summary.jumlahMasuk >= summary.jumlahKeluar ? (
                  <TrendingUp className="w-5 h-5 text-purple-500" />
                ) : (
                  <TrendingDown className="w-5 h-5 text-purple-500" />
                )}
              </div>
              <div>
                <p className="text-xs text-navy-500">Selisih Stok</p>
                <p className={`text-xl font-bold ${summary.jumlahMasuk >= summary.jumlahKeluar ? "text-emerald-700" : "text-red-700"}`}>
                  {summary.jumlahMasuk >= summary.jumlahKeluar ? "+" : ""}{(summary.jumlahMasuk - summary.jumlahKeluar).toLocaleString("id-ID")}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Top items */}
      {summary && hasFetched && summary.totalTransaksi > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 print:hidden">
          <div className="card p-4 flex items-center gap-3">
            <ArrowDownToLine className="w-5 h-5 text-emerald-500 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-navy-500">Barang Terbanyak Masuk</p>
              <p className="text-sm font-semibold text-navy-800 truncate">{summary.barangTerbanyakMasuk}</p>
            </div>
          </div>
          <div className="card p-4 flex items-center gap-3">
            <ArrowUpFromLine className="w-5 h-5 text-red-500 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-xs text-navy-500">Barang Terbanyak Keluar</p>
              <p className="text-sm font-semibold text-navy-800 truncate">{summary.barangTerbanyakKeluar}</p>
            </div>
          </div>
        </div>
      )}

      {/* Print Header (only visible when printing) */}
      <div className="hidden print:block mb-6">
        <h1 className="text-xl font-bold text-center">LAPORAN TRANSAKSI GUDANG</h1>
        <p className="text-sm text-center text-gray-500">PT Saberindo Pacific — Fire Protection</p>
        <p className="text-sm text-center text-gray-500 mt-1">
          Periode: {dari || "Awal"} s/d {sampai || "Sekarang"}
          {tipe && ` | Tipe: ${tipe}`}
          {kategori && ` | Kategori: ${kategori}`}
        </p>
        {summary && (
          <div className="flex justify-center gap-8 mt-3 text-sm">
            <span>Total: <strong>{summary.totalTransaksi}</strong></span>
            <span>Masuk: <strong className="text-green-700">{summary.totalMasuk} ({summary.jumlahMasuk} unit)</strong></span>
            <span>Keluar: <strong className="text-red-700">{summary.totalKeluar} ({summary.jumlahKeluar} unit)</strong></span>
          </div>
        )}
        <hr className="mt-3" />
      </div>

      {/* Transaction Table */}
      {!hasFetched ? (
        <div className="card p-12 text-center print:hidden">
          <FileBarChart className="w-12 h-12 text-navy-200 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-navy-700 mb-2">Buat Laporan</h3>
          <p className="text-sm text-navy-400 max-w-md mx-auto">
            Atur filter di atas lalu klik &quot;Tampilkan Laporan&quot; untuk melihat data.
            Setelah itu bisa export ke Excel atau cetak PDF.
          </p>
        </div>
      ) : loading ? (
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 text-navy-300 animate-spin mx-auto mb-3" />
          <p className="text-sm text-navy-500">Memuat data laporan...</p>
        </div>
      ) : transaksiList.length === 0 ? (
        <div className="card p-12 text-center">
          <FileBarChart className="w-10 h-10 text-navy-300 mx-auto mb-3" />
          <p className="text-sm text-navy-500">Tidak ada transaksi dalam periode yang dipilih.</p>
        </div>
      ) : (
        <div className="table-container bg-white">
          <table>
            <thead>
              <tr>
                <th className="print:text-[10px]">No</th>
                <th className="print:text-[10px]">Tanggal</th>
                <th className="print:text-[10px]">Tipe</th>
                <th className="print:text-[10px]">Kode</th>
                <th className="print:text-[10px]">Nama Barang</th>
                <th className="text-center print:text-[10px]">Jumlah</th>
                <th className="text-center print:text-[10px]">Sebelum</th>
                <th className="text-center print:text-[10px]">Sesudah</th>
                <th className="print:text-[10px]">Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {transaksiList.map((trx, i) => {
                const isMasuk = trx.tipe === "Masuk";
                return (
                  <tr key={trx.id} className="print:text-[10px]">
                    <td className="text-navy-400 text-xs">{i + 1}</td>
                    <td className="text-xs text-navy-500 whitespace-nowrap">{trx.tanggal}</td>
                    <td>
                      <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-semibold print:px-0 print:bg-transparent ${
                        isMasuk ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"
                      }`}>
                        <span className="print:hidden">
                          {isMasuk ? <ArrowDownToLine className="w-3 h-3" /> : <ArrowUpFromLine className="w-3 h-3" />}
                        </span>
                        {trx.tipe}
                      </span>
                    </td>
                    <td>
                      <span className="font-mono text-xs text-navy-600">{trx.kodeBarang}</span>
                    </td>
                    <td className="font-medium text-navy-900 text-sm">{trx.namaBarang}</td>
                    <td className="text-center">
                      <span className={`font-mono font-bold ${isMasuk ? "text-emerald-600" : "text-red-600"}`}>
                        {isMasuk ? "+" : "-"}{trx.jumlah}
                      </span>
                    </td>
                    <td className="text-center font-mono text-navy-400">{trx.stokSebelum}</td>
                    <td className="text-center font-mono font-semibold text-navy-700">{trx.stokSesudah}</td>
                    <td className="text-xs text-navy-500 max-w-[150px] truncate print:max-w-none">{trx.keterangan || "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Footer count */}
      {hasFetched && transaksiList.length > 0 && (
        <div className="mt-4 flex items-center justify-between text-xs text-navy-400 print:hidden">
          <span>Menampilkan {transaksiList.length} transaksi</span>
          <div className="flex gap-2">
            <button onClick={exportExcel} disabled={exporting} className="inline-flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium">
              <Download className="w-3.5 h-3.5" />Export Excel
            </button>
            <span className="text-navy-200">|</span>
            <button onClick={handlePrint} className="inline-flex items-center gap-1 text-blue-600 hover:text-blue-700 font-medium">
              <Printer className="w-3.5 h-3.5" />Cetak
            </button>
          </div>
        </div>
      )}

      {/* Print-only footer */}
      <div className="hidden print:block mt-8 text-xs text-gray-400 text-center">
        Dicetak dari Saberindo WMS — {new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
      </div>
    </div>
  );
}
