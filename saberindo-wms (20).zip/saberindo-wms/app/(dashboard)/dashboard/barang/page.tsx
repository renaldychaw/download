"use client";

import { useEffect, useState, useMemo } from "react";
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  X,
  Loader2,
  Package,
  Filter,
  AlertTriangle,
  RefreshCw,
} from "lucide-react";
import { Barang, BarangFormData, Lokasi, KATEGORI_OPTIONS, SATUAN_OPTIONS } from "@/lib/types";
import toast from "react-hot-toast";

// ============================================
// Form Modal
// ============================================
function BarangFormModal({
  isOpen,
  onClose,
  onSubmit,
  initialData,
  isLoading,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: BarangFormData) => void;
  initialData?: Barang | null;
  isLoading: boolean;
}) {
  const [form, setForm] = useState<BarangFormData>({
    kode: "", nama: "", kategori: "", satuan: "Pcs",
    stok: 0, stokMinimum: 0, stokAwal: 0, lokasi: "", keterangan: "",
  });
  const [lokasiOptions, setLokasiOptions] = useState<Lokasi[]>([]);

  useEffect(() => {
    fetch("/api/lokasi").then(r => r.json()).then(d => {
      if (d.success) setLokasiOptions(d.data);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (initialData) {
      setForm({
        kode: initialData.kode, nama: initialData.nama,
        kategori: initialData.kategori, satuan: initialData.satuan,
        stok: initialData.stok, stokMinimum: initialData.stokMinimum,
        stokAwal: initialData.stokAwal ?? 0,
        lokasi: initialData.lokasi, keterangan: initialData.keterangan,
      });
    } else {
      setForm({ kode: "", nama: "", kategori: "", satuan: "Pcs", stok: 0, stokMinimum: 0, stokAwal: 0, lokasi: "", keterangan: "" });
    }
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  const update = (field: keyof BarangFormData, value: string | number) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg card p-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-navy-100">
          <h2 className="text-lg font-semibold text-navy-900">
            {initialData ? "Edit Barang" : "Tambah Barang Baru"}
          </h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-navy-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Kode Barang <span className="text-red-500">*</span></label>
              <input type="text" value={form.kode} onChange={(e) => update("kode", e.target.value.toUpperCase())} placeholder="SPR-001" className="input-field font-mono" required />
            </div>
            <div>
              <label className="label">Kategori <span className="text-red-500">*</span></label>
              <select value={form.kategori} onChange={(e) => update("kategori", e.target.value)} className="input-field" required>
                <option value="">Pilih kategori</option>
                {KATEGORI_OPTIONS.map((k) => (<option key={k} value={k}>{k}</option>))}
              </select>
            </div>
          </div>

          <div>
            <label className="label">Nama Barang <span className="text-red-500">*</span></label>
            <input type="text" value={form.nama} onChange={(e) => update("nama", e.target.value)} placeholder="Sprinkler Pendant 1/2 inch" className="input-field" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Satuan <span className="text-red-500">*</span></label>
              <select value={form.satuan} onChange={(e) => update("satuan", e.target.value)} className="input-field" required>
                {SATUAN_OPTIONS.map((s) => (<option key={s} value={s}>{s}</option>))}
              </select>
            </div>
            <div>
              <label className="label">Stok Awal</label>
              <input type="number" value={form.stok} onChange={(e) => update("stok", parseInt(e.target.value) || 0)} min="0" className="input-field" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Stok Minimum</label>
              <input type="number" value={form.stokMinimum} onChange={(e) => update("stokMinimum", parseInt(e.target.value) || 0)} min="0" className="input-field" />
            </div>
            <div>
              <label className="label">
                Stok Awal
                <span className="ml-1 text-[10px] text-navy-400 font-normal">(notifikasi ≤40%)</span>
              </label>
              <input
                type="number"
                value={form.stokAwal}
                onChange={(e) => update("stokAwal", parseInt(e.target.value) || 0)}
                min="0"
                className="input-field"
                disabled={!!initialData}
                title={initialData ? "Stok awal tidak dapat diubah setelah barang dibuat" : ""}
              />
              {initialData && (
                <p className="text-[10px] text-navy-400 mt-1">Tidak dapat diubah setelah dibuat</p>
              )}
            </div>
          </div>

          <div>
            <label className="label">Lokasi Gudang / Rak</label>
            <select value={form.lokasi} onChange={(e) => update("lokasi", e.target.value)} className="input-field">
              <option value="">Pilih lokasi</option>
              {lokasiOptions.map((l) => (
                <option key={l.id} value={l.kode}>{l.kode} — {l.nama} ({l.zona})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="label">Keterangan</label>
            <textarea value={form.keterangan} onChange={(e) => update("keterangan", e.target.value)} placeholder="Catatan tambahan..." className="input-field resize-none" rows={2} />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary">Batal</button>
            <button type="submit" disabled={isLoading} className="btn-primary">
              {isLoading ? (<><Loader2 className="w-4 h-4 animate-spin" />Menyimpan...</>) : initialData ? "Simpan Perubahan" : "Tambah Barang"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================
// Delete Modal
// ============================================
function DeleteModal({
  isOpen, onClose, onConfirm, barang, isLoading,
}: {
  isOpen: boolean; onClose: () => void; onConfirm: () => void;
  barang: Barang | null; isLoading: boolean;
}) {
  if (!isOpen || !barang) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-sm card p-6 shadow-2xl text-center">
        <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-6 h-6 text-red-500" />
        </div>
        <h3 className="text-lg font-semibold text-navy-900 mb-2">Hapus Barang?</h3>
        <p className="text-sm text-navy-500 mb-1">
          <span className="font-mono text-navy-700">{barang.kode}</span> — {barang.nama}
        </p>
        <p className="text-xs text-navy-400 mb-6">Data yang dihapus tidak dapat dikembalikan.</p>
        <div className="flex items-center justify-center gap-3">
          <button onClick={onClose} className="btn-secondary">Batal</button>
          <button onClick={onConfirm} disabled={isLoading} className="btn-primary bg-red-600 hover:bg-red-700">
            {isLoading ? (<><Loader2 className="w-4 h-4 animate-spin" />Menghapus...</>) : "Ya, Hapus"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main Page
// ============================================
export default function MasterBarangPage() {
  const [barangList, setBarangList] = useState<Barang[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [filterKategori, setFilterKategori] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editData, setEditData] = useState<Barang | null>(null);
  const [showDelete, setShowDelete] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Barang | null>(null);

  const fetchBarang = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/barang");
      const data = await res.json();
      if (data.success) setBarangList(data.data);
      else toast.error(data.error || "Gagal memuat data");
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchBarang(); }, []);

  const filteredBarang = useMemo(() => {
    return barangList.filter((b) => {
      const matchSearch = !search || b.nama.toLowerCase().includes(search.toLowerCase()) || b.kode.toLowerCase().includes(search.toLowerCase());
      const matchKategori = !filterKategori || b.kategori === filterKategori;
      return matchSearch && matchKategori;
    });
  }, [barangList, search, filterKategori]);

  const categories = useMemo(() => Array.from(new Set(barangList.map((b) => b.kategori))).sort(), [barangList]);

  const handleSubmit = async (data: BarangFormData) => {
    setSaving(true);
    try {
      const isEdit = !!editData;
      const res = await fetch("/api/barang", {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(isEdit ? { id: editData.id, ...data } : data),
      });
      const result = await res.json();
      if (result.success) {
        toast.success(result.message || "Berhasil!");
        setShowForm(false);
        setEditData(null);
        fetchBarang();
      } else { toast.error(result.error || "Gagal menyimpan"); }
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/barang?id=${deleteTarget.id}`, { method: "DELETE" });
      const result = await res.json();
      if (result.success) {
        toast.success("Barang berhasil dihapus");
        setShowDelete(false);
        setDeleteTarget(null);
        fetchBarang();
      } else { toast.error(result.error || "Gagal menghapus"); }
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setSaving(false); }
  };

  const StockBadge = ({ stok, minimum, maksimum }: { stok: number; minimum: number; maksimum: number }) => {
    if (stok === 0) return <span className="badge-red">Kosong</span>;
    if (maksimum > 0 && stok <= maksimum * 0.4) return <span className="badge-yellow">Rendah</span>;
    if (maksimum === 0 && stok <= minimum) return <span className="badge-yellow">Rendah</span>;
    return <span className="badge-green">Aman</span>;
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Master Barang</h1>
          <p className="text-sm text-navy-500 mt-1">Kelola data barang di gudang ({filteredBarang.length} item)</p>
        </div>
        <button onClick={() => { setEditData(null); setShowForm(true); }} className="btn-primary">
          <Plus className="w-4 h-4" />Tambah Barang
        </button>
      </div>

      {/* Search & Filter */}
      <div className="card p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari nama atau kode barang..." className="input-field pl-10" />
          </div>
          <div className="relative sm:w-52">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <select value={filterKategori} onChange={(e) => setFilterKategori(e.target.value)} className="input-field pl-10 appearance-none">
              <option value="">Semua Kategori</option>
              {categories.map((k) => (<option key={k} value={k}>{k}</option>))}
            </select>
          </div>
          <button onClick={fetchBarang} disabled={loading} className="btn-secondary sm:w-auto">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 text-navy-300 animate-spin mx-auto mb-3" />
          <p className="text-sm text-navy-500">Memuat data dari Excel...</p>
        </div>
      ) : filteredBarang.length === 0 ? (
        <div className="card p-12 text-center">
          <Package className="w-10 h-10 text-navy-300 mx-auto mb-3" />
          <p className="text-sm text-navy-500">
            {search || filterKategori ? 'Tidak ada barang yang cocok dengan filter.' : 'Belum ada data barang. Klik "Tambah Barang" untuk mulai.'}
          </p>
        </div>
      ) : (
        <div className="table-container bg-white">
          <table>
            <thead>
              <tr>
                <th>Kode</th>
                <th>Nama Barang</th>
                <th>Kategori</th>
                <th>Lokasi</th>
                <th className="text-center">Stok</th>
                <th className="text-center">Min</th>
                <th className="text-center">Stok Awal</th>
                <th className="text-center">Status</th>
                <th className="text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filteredBarang.map((item) => (
                <tr key={item.id}>
                  <td><span className="font-mono text-xs font-medium text-navy-600 bg-navy-50 px-2 py-0.5 rounded">{item.kode}</span></td>
                  <td className="font-medium text-navy-900">{item.nama}</td>
                  <td><span className="badge-blue">{item.kategori}</span></td>
                  <td className="text-navy-500 text-xs">{item.lokasi || "—"}</td>
                  <td className="text-center font-mono font-semibold">{item.stok}</td>
                  <td className="text-center font-mono text-navy-400">{item.stokMinimum}</td>
                  <td className="text-center font-mono text-navy-400">{item.stokAwal > 0 ? item.stokAwal : "—"}</td>
                  <td className="text-center"><StockBadge stok={item.stok} minimum={item.stokMinimum} maksimum={item.stokAwal ?? 0} /></td>
                  <td className="text-right">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => { setEditData(item); setShowForm(true); }} className="p-2 rounded-lg text-navy-400 hover:bg-blue-50 hover:text-blue-600 transition-colors" title="Edit">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => { setDeleteTarget(item); setShowDelete(true); }} className="p-2 rounded-lg text-navy-400 hover:bg-red-50 hover:text-red-600 transition-colors" title="Hapus">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <BarangFormModal isOpen={showForm} onClose={() => { setShowForm(false); setEditData(null); }} onSubmit={handleSubmit} initialData={editData} isLoading={saving} />
      <DeleteModal isOpen={showDelete} onClose={() => { setShowDelete(false); setDeleteTarget(null); }} onConfirm={handleDelete} barang={deleteTarget} isLoading={saving} />
    </div>
  );
}