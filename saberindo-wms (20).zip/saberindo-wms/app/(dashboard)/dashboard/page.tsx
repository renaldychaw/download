"use client";

import { useEffect, useState } from "react";
import {
  Package,
  AlertTriangle,
  XCircle,
  Boxes,
  RefreshCw,
  FileSpreadsheet,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeftRight,
} from "lucide-react";
import { DashboardStats } from "@/lib/types";
import toast from "react-hot-toast";

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/barang?stats=true");
      const data = await res.json();
      if (data.success) {
        setStats(data.data);
      } else {
        toast.error(data.error || "Gagal memuat statistik");
      }
    } catch {
      toast.error("Gagal terhubung ke server");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  const statCards = stats
    ? [
        {
          label: "Total Jenis Barang",
          value: stats.totalBarang,
          icon: Package,
          color: "text-blue-600",
          bg: "bg-blue-50",
          border: "border-blue-100",
        },
        {
          label: "Total Stok",
          value: stats.totalStok.toLocaleString("id-ID"),
          icon: Boxes,
          color: "text-emerald-600",
          bg: "bg-emerald-50",
          border: "border-emerald-100",
        },
        {
          label: "Stok Rendah",
          value: stats.stokRendah,
          icon: AlertTriangle,
          color: "text-amber-600",
          bg: "bg-amber-50",
          border: "border-amber-100",
          alert: stats.stokRendah > 0,
        },
        {
          label: "Stok Kosong",
          value: stats.stokKosong,
          icon: XCircle,
          color: "text-red-600",
          bg: "bg-red-50",
          border: "border-red-100",
          alert: stats.stokKosong > 0,
        },
      ]
    : [];

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Dashboard</h1>
          <p className="text-sm text-navy-500 mt-1">
            Ringkasan data gudang PT Saberindo Pacific
          </p>
        </div>
        <button onClick={fetchStats} disabled={loading} className="btn-secondary">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {/* Stat Cards */}
      {loading && !stats ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="card p-5 animate-pulse">
              <div className="h-10 w-10 rounded-xl bg-navy-100 mb-3" />
              <div className="h-4 w-24 bg-navy-100 rounded mb-2" />
              <div className="h-7 w-16 bg-navy-100 rounded" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {statCards.map((card) => (
            <div
              key={card.label}
              className={`card p-5 border ${card.border} ${
                card.alert ? "ring-2 ring-offset-1 ring-red-200" : ""
              }`}
            >
              <div className={`w-10 h-10 rounded-xl ${card.bg} flex items-center justify-center mb-3`}>
                <card.icon className={`w-5 h-5 ${card.color}`} />
              </div>
              <p className="text-xs font-medium text-navy-500 uppercase tracking-wide">
                {card.label}
              </p>
              <p className="text-2xl font-bold text-navy-900 mt-1">{card.value}</p>
            </div>
          ))}
        </div>
      )}

      {/* Kategori Breakdown */}
      {stats && Object.keys(stats.kategoriCount).length > 0 && (
        <div className="card p-6 mb-6">
          <h2 className="text-base font-semibold text-navy-800 mb-4">
            Distribusi per Kategori
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {Object.entries(stats.kategoriCount)
              .sort((a, b) => b[1] - a[1])
              .map(([kategori, count]) => (
                <div
                  key={kategori}
                  className="flex items-center justify-between rounded-lg border border-navy-100 px-4 py-3"
                >
                  <span className="text-sm text-navy-700">{kategori}</span>
                  <span className="badge-blue">{count}</span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Transaksi Hari Ini */}
      {stats && stats.totalBarang > 0 && (
        <div className="card p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-semibold text-navy-800">Transaksi Hari Ini</h2>
            <a href="/dashboard/transaksi" className="text-xs text-brand-600 hover:text-brand-700 font-medium">
              Lihat semua →
            </a>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="flex items-center gap-3 rounded-lg border border-navy-100 px-4 py-3">
              <ArrowLeftRight className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-xs text-navy-500">Total</p>
                <p className="text-lg font-bold text-navy-900">{stats.totalTransaksiHariIni}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg border border-emerald-100 bg-emerald-50/30 px-4 py-3">
              <ArrowDownToLine className="w-5 h-5 text-emerald-500" />
              <div>
                <p className="text-xs text-navy-500">Masuk</p>
                <p className="text-lg font-bold text-emerald-700">{stats.totalMasukHariIni}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 rounded-lg border border-red-100 bg-red-50/30 px-4 py-3">
              <ArrowUpFromLine className="w-5 h-5 text-red-500" />
              <div>
                <p className="text-xs text-navy-500">Keluar</p>
                <p className="text-lg font-bold text-red-700">{stats.totalKeluarHariIni}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {stats && stats.totalBarang === 0 && (
        <div className="card p-12 text-center">
          <Package className="w-12 h-12 text-navy-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-navy-800 mb-2">Belum Ada Data Barang</h3>
          <p className="text-sm text-navy-500 mb-6 max-w-md mx-auto">
            Mulai tambahkan data barang ke gudang melalui halaman Master Barang.
          </p>
          <a href="/dashboard/barang" className="btn-primary">
            <Package className="w-4 h-4" />
            Tambah Barang Pertama
          </a>
        </div>
      )}

      {/* Storage Info */}
      <div className="mt-6 flex items-center justify-center gap-2 text-xs text-navy-400">
        <FileSpreadsheet className="w-3.5 h-3.5" />
        <span>Data tersimpan di <code className="font-mono bg-navy-100 px-1.5 py-0.5 rounded text-navy-600">data/warehouse.xlsx</code></span>
      </div>
    </div>
  );
}
