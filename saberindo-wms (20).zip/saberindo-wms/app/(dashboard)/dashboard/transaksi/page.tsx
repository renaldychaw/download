"use client";

import { useEffect, useState, useMemo } from "react";
import {
  ArrowDownToLine, ArrowUpFromLine, Search, X, Loader2,
  ArrowLeftRight, Filter, RefreshCw, PackagePlus, PackageMinus,
  AlertTriangle, CheckCircle2, ClipboardList, ChevronRight, Clock,
} from "lucide-react";
import { Barang, Transaksi, TransaksiFormData, TipeTransaksi, PurchaseOrder, POItem } from "@/lib/types";
import toast from "react-hot-toast";

// ============================================
// Manual Transaction Form Modal (existing)
// ============================================
function TransaksiFormModal({
  isOpen, onClose, onSubmit, barangList, isLoading, defaultTipe,
}: {
  isOpen: boolean; onClose: () => void; onSubmit: (data: TransaksiFormData) => void;
  barangList: Barang[]; isLoading: boolean; defaultTipe: TipeTransaksi;
}) {
  const [form, setForm] = useState<TransaksiFormData>({ tipe: defaultTipe, barangId: "", jumlah: 1, keterangan: "" });
  const [searchBarang, setSearchBarang] = useState("");

  useEffect(() => {
    if (isOpen) { setForm({ tipe: defaultTipe, barangId: "", jumlah: 1, keterangan: "" }); setSearchBarang(""); }
  }, [isOpen, defaultTipe]);

  if (!isOpen) return null;

  const filteredBarang = barangList.filter(
    (b) => !searchBarang || b.nama.toLowerCase().includes(searchBarang.toLowerCase()) || b.kode.toLowerCase().includes(searchBarang.toLowerCase())
  );
  const selectedBarang = barangList.find((b) => b.id === form.barangId);
  const isMasuk = form.tipe === "Masuk";

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); if (!form.barangId) { toast.error("Pilih barang"); return; } onSubmit(form); };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-lg card p-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className={`flex items-center justify-between px-6 py-4 border-b ${isMasuk ? "border-emerald-100 bg-emerald-50/50" : "border-red-100 bg-red-50/50"}`}>
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${isMasuk ? "bg-emerald-100" : "bg-red-100"}`}>
              {isMasuk ? <ArrowDownToLine className="w-5 h-5 text-emerald-600" /> : <ArrowUpFromLine className="w-5 h-5 text-red-600" />}
            </div>
            <h2 className="text-lg font-semibold text-navy-900">{isMasuk ? "Barang Masuk (Manual)" : "Barang Keluar"}</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-white/80"><X className="w-5 h-5" /></button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Tipe toggle */}
          <div>
            <label className="label">Tipe Transaksi</label>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" onClick={() => setForm((p) => ({ ...p, tipe: "Masuk" }))}
                className={`flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold border transition-all ${isMasuk ? "bg-emerald-50 border-emerald-300 text-emerald-700 ring-2 ring-emerald-200" : "bg-white border-navy-200 text-navy-500 hover:bg-navy-50"}`}>
                <ArrowDownToLine className="w-4 h-4" />Barang Masuk
              </button>
              <button type="button" onClick={() => setForm((p) => ({ ...p, tipe: "Keluar" }))}
                className={`flex items-center justify-center gap-2 rounded-lg px-4 py-3 text-sm font-semibold border transition-all ${!isMasuk ? "bg-red-50 border-red-300 text-red-700 ring-2 ring-red-200" : "bg-white border-navy-200 text-navy-500 hover:bg-navy-50"}`}>
                <ArrowUpFromLine className="w-4 h-4" />Barang Keluar
              </button>
            </div>
          </div>

          {/* Pilih Barang */}
          <div>
            <label className="label">Pilih Barang <span className="text-red-500">*</span></label>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
              <input type="text" value={searchBarang} onChange={(e) => setSearchBarang(e.target.value)} placeholder="Cari kode atau nama barang..." className="input-field pl-10" />
            </div>
            <div className="max-h-40 overflow-y-auto rounded-lg border border-navy-200 divide-y divide-navy-50">
              {filteredBarang.length === 0 ? (
                <div className="px-4 py-3 text-sm text-navy-400 text-center">Tidak ada barang ditemukan</div>
              ) : filteredBarang.map((b) => (
                <button key={b.id} type="button" onClick={() => setForm((p) => ({ ...p, barangId: b.id }))}
                  className={`w-full flex items-center justify-between px-4 py-2.5 text-left text-sm transition-colors ${form.barangId === b.id ? (isMasuk ? "bg-emerald-50 border-l-4 border-emerald-500" : "bg-red-50 border-l-4 border-red-500") : "hover:bg-navy-50"}`}>
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="font-mono text-xs text-navy-500 bg-navy-100 px-1.5 py-0.5 rounded flex-shrink-0">{b.kode}</span>
                    <span className="text-navy-800 truncate">{b.nama}</span>
                  </div>
                  <span className="text-xs font-mono font-semibold text-navy-600 flex-shrink-0 ml-2">{b.stok} {b.satuan}</span>
                </button>
              ))}
            </div>
          </div>

          {selectedBarang && (
            <div className={`rounded-lg px-4 py-3 text-sm ${isMasuk ? "bg-emerald-50 border border-emerald-200" : "bg-red-50 border border-red-200"}`}>
              <p className="font-medium text-navy-800">{selectedBarang.kode} — {selectedBarang.nama}</p>
              <p className="text-navy-500 mt-0.5">Stok saat ini: <span className="font-mono font-semibold text-navy-700">{selectedBarang.stok} {selectedBarang.satuan}</span></p>
            </div>
          )}

          <div>
            <label className="label">Jumlah {isMasuk ? "Masuk" : "Keluar"} <span className="text-red-500">*</span></label>
            <input type="number" value={form.jumlah} onChange={(e) => setForm((p) => ({ ...p, jumlah: parseInt(e.target.value) || 0 }))} min="1" className="input-field font-mono text-lg" required />
            {selectedBarang && !isMasuk && form.jumlah > selectedBarang.stok && (
              <p className="mt-1.5 text-xs text-red-500 flex items-center gap-1"><AlertTriangle className="w-3 h-3" />Melebihi stok!</p>
            )}
          </div>

          <div>
            <label className="label">Keterangan</label>
            <textarea value={form.keterangan} onChange={(e) => setForm((p) => ({ ...p, keterangan: e.target.value }))}
              placeholder={isMasuk ? "e.g. Pengiriman dari supplier..." : "e.g. Untuk proyek..."} className="input-field resize-none" rows={2} />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary">Batal</button>
            <button type="submit" disabled={isLoading || !form.barangId || form.jumlah <= 0}
              className={`btn-primary ${isMasuk ? "bg-emerald-600 hover:bg-emerald-700" : "bg-red-600 hover:bg-red-700"}`}>
              {isLoading ? (<><Loader2 className="w-4 h-4 animate-spin" />Menyimpan...</>) : isMasuk ? (<><PackagePlus className="w-4 h-4" />Catat Barang Masuk</>) : (<><PackageMinus className="w-4 h-4" />Catat Barang Keluar</>)}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================
// PO Receive Modal — Terima Barang dari PO
// ============================================
function POReceiveModal({
  isOpen, onClose, onSaved,
}: {
  isOpen: boolean; onClose: () => void; onSaved: () => void;
}) {
  const [poList, setPOList] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);
  const [receiveQty, setReceiveQty] = useState<Record<string, number>>({});
  const [keterangan, setKeterangan] = useState("");
  const [step, setStep] = useState<"select" | "receive">("select");
  const [searchPO, setSearchPO] = useState("");

  useEffect(() => {
    if (!isOpen) return;
    setStep("select"); setSelectedPO(null); setReceiveQty({}); setKeterangan(""); setSearchPO("");
    setLoading(true);
    fetch("/api/po").then((r) => r.json()).then((d) => {
      if (d.success) {
        // Only show POs that are not complete
        setPOList(d.data.filter((po: PurchaseOrder) => po.status !== "Complete"));
      }
    }).catch(() => toast.error("Gagal memuat data PO")).finally(() => setLoading(false));
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredPO = poList.filter((po) =>
    !searchPO || po.poNumber.toLowerCase().includes(searchPO.toLowerCase()) ||
    po.supplier.toLowerCase().includes(searchPO.toLowerCase())
  );

  const selectPO = (po: PurchaseOrder) => {
    setSelectedPO(po);
    // Pre-fill: qty remaining (sisa yang belum diterima) untuk setiap item
    const qty: Record<string, number> = {};
    po.items.forEach((item) => {
      const remaining = item.qtyOrdered - (item.qtyReceived || 0);
      qty[item.itemCode] = Math.max(0, remaining);
    });
    setReceiveQty(qty);
    setStep("receive");
  };

  const handleReceive = async () => {
    if (!selectedPO) return;
    const items = selectedPO.items
      .map((item) => ({
        itemCode: item.itemCode,
        namaBarang: item.namaBarang,
        qtyToReceive: receiveQty[item.itemCode] || 0,
      }))
      .filter((i) => i.qtyToReceive > 0);

    if (items.length === 0) { toast.error("Masukkan jumlah penerimaan"); return; }

    setSaving(true);
    try {
      const res = await fetch("/api/po/receive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ poId: selectedPO.id, items, keterangan }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(data.message);
        onSaved();
        onClose();
      } else {
        toast.error(data.error || "Gagal menerima barang");
      }
    } catch { toast.error("Gagal menghubungi server"); }
    finally { setSaving(false); }
  };

  const totalToReceive = Object.values(receiveQty).reduce((s, v) => s + (v || 0), 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl card p-0 shadow-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-blue-100 bg-blue-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <ClipboardList className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-navy-900">Terima Barang dari PO</h2>
              <p className="text-xs text-navy-500">
                {step === "select" ? "Pilih Purchase Order" : `PO: ${selectedPO?.poNumber}`}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-white/80"><X className="w-5 h-5" /></button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* Step 1: Select PO */}
          {step === "select" && (
            <div className="p-6">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
                <input type="text" value={searchPO} onChange={(e) => setSearchPO(e.target.value)}
                  placeholder="Cari PO number atau supplier..." className="input-field pl-10" />
              </div>

              {loading ? (
                <div className="text-center py-8">
                  <Loader2 className="w-6 h-6 text-navy-300 animate-spin mx-auto mb-2" />
                  <p className="text-sm text-navy-400">Memuat daftar PO...</p>
                </div>
              ) : filteredPO.length === 0 ? (
                <div className="text-center py-8">
                  <ClipboardList className="w-8 h-8 text-navy-200 mx-auto mb-2" />
                  <p className="text-sm text-navy-400">
                    {searchPO ? "Tidak ada PO yang cocok." : "Tidak ada PO yang menunggu penerimaan."}
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredPO.map((po) => {
                    const totalOrd = po.items.reduce((s, i) => s + i.qtyOrdered, 0);
                    const totalRcv = po.items.reduce((s, i) => s + (i.qtyReceived || 0), 0);
                    const pct = totalOrd > 0 ? Math.round((totalRcv / totalOrd) * 100) : 0;
                    const isPending = po.status === "Pending";

                    return (
                      <button key={po.id} onClick={() => selectPO(po)}
                        className="w-full text-left card p-4 border border-navy-100 hover:border-blue-300 hover:shadow-md transition-all group">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <span className="font-mono text-sm font-bold text-blue-600">{po.poNumber}</span>
                            <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold ${isPending ? "bg-red-50 text-red-600" : "bg-amber-50 text-amber-600"}`}>
                              {isPending ? <Clock className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                              {po.status}
                            </span>
                          </div>
                          <ChevronRight className="w-4 h-4 text-navy-300 group-hover:text-blue-500 transition-colors" />
                        </div>
                        <p className="text-sm text-navy-700 truncate">{po.supplier}</p>
                        <div className="flex items-center gap-3 mt-2">
                          <span className="text-xs text-navy-400">{po.poDate}</span>
                          <span className="text-xs text-navy-400">{po.items.length} item</span>
                          <div className="flex-1 flex items-center gap-2">
                            <div className="flex-1 h-1.5 bg-navy-100 rounded-full overflow-hidden max-w-[100px]">
                              <div className={`h-full rounded-full ${pct >= 100 ? "bg-emerald-500" : pct > 0 ? "bg-amber-400" : "bg-navy-200"}`} style={{ width: `${pct}%` }} />
                            </div>
                            <span className="text-[10px] font-mono text-navy-400">{pct}%</span>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Step 2: Receive items */}
          {step === "receive" && selectedPO && (
            <div className="p-6 space-y-4">
              <button onClick={() => setStep("select")} className="text-xs text-blue-600 hover:text-blue-700 font-medium">← Pilih PO lain</button>

              {/* PO Summary */}
              <div className="rounded-lg bg-navy-50 border border-navy-200 p-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-sm font-bold text-blue-600">{selectedPO.poNumber}</span>
                  <span className="text-xs text-navy-400">{selectedPO.poDate}</span>
                </div>
                <p className="text-sm text-navy-700">{selectedPO.supplier}</p>
                {selectedPO.description && <p className="text-xs text-navy-400 mt-1 truncate">{selectedPO.description}</p>}
              </div>

              {/* Item rows */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-semibold text-navy-700">Item yang Diterima</label>
                  <button type="button" onClick={() => {
                    const qty: Record<string, number> = {};
                    selectedPO.items.forEach((item) => {
                      qty[item.itemCode] = Math.max(0, item.qtyOrdered - (item.qtyReceived || 0));
                    });
                    setReceiveQty(qty);
                  }} className="text-xs text-blue-600 hover:text-blue-700 font-medium">
                    Isi semua (sisa)
                  </button>
                </div>

                <div className="space-y-2">
                  {selectedPO.items.map((item) => {
                    const remaining = item.qtyOrdered - (item.qtyReceived || 0);
                    const isDone = remaining <= 0;
                    const currentQty = receiveQty[item.itemCode] || 0;

                    return (
                      <div key={item.itemCode} className={`rounded-lg border p-4 ${isDone ? "border-emerald-200 bg-emerald-50/30" : "border-navy-200"}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="font-mono text-xs text-navy-500 bg-navy-100 px-1.5 py-0.5 rounded">{item.itemCode}</span>
                              {isDone && <span className="badge-green text-[10px]">Lengkap</span>}
                            </div>
                            <p className="text-sm text-navy-800 truncate">{item.namaBarang}</p>
                            <p className="text-xs text-navy-400 mt-1">
                              Dipesan: <span className="font-semibold">{item.qtyOrdered}</span>
                              {" · "}Diterima: <span className="font-semibold text-emerald-600">{item.qtyReceived || 0}</span>
                              {" · "}Sisa: <span className={`font-semibold ${remaining > 0 ? "text-amber-600" : "text-emerald-600"}`}>{Math.max(0, remaining)}</span>
                            </p>
                          </div>

                          {/* Qty input */}
                          <div className="flex-shrink-0 w-24">
                            <label className="text-[10px] text-navy-400 block mb-1">Terima</label>
                            <input type="number" min="0" max={remaining}
                              value={currentQty}
                              onChange={(e) => setReceiveQty((p) => ({ ...p, [item.itemCode]: Math.max(0, parseInt(e.target.value) || 0) }))}
                              disabled={isDone}
                              className={`input-field text-center font-mono font-semibold text-sm py-2 ${isDone ? "bg-emerald-50 opacity-50" : currentQty > 0 ? "border-emerald-400 ring-1 ring-emerald-200" : ""}`} />
                          </div>
                        </div>

                        {currentQty > remaining && remaining > 0 && (
                          <p className="text-[11px] text-amber-600 mt-2 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" />Melebihi sisa yang belum diterima ({remaining}). Qty akan tetap tercatat sesuai input.
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Keterangan */}
              <div>
                <label className="label">Keterangan (opsional)</label>
                <textarea value={keterangan} onChange={(e) => setKeterangan(e.target.value)}
                  placeholder="e.g. Penerimaan partial batch 1..." className="input-field resize-none" rows={2} />
              </div>

              {/* Preview */}
              {totalToReceive > 0 && (
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 px-4 py-3">
                  <p className="text-xs text-emerald-700 font-semibold">
                    {Object.values(receiveQty).filter((v) => v > 0).length} item akan diterima (total {totalToReceive} unit)
                  </p>
                  <p className="text-[11px] text-emerald-600 mt-0.5">
                    Stok di Master Barang akan otomatis bertambah & transaksi tercatat
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        {step === "receive" && (
          <div className="border-t border-navy-100 px-6 py-4 flex justify-end gap-3">
            <button onClick={onClose} className="btn-secondary">Batal</button>
            <button onClick={handleReceive} disabled={saving || totalToReceive === 0}
              className="btn-primary bg-emerald-600 hover:bg-emerald-700">
              {saving ? (<><Loader2 className="w-4 h-4 animate-spin" />Memproses...</>) : (<><CheckCircle2 className="w-4 h-4" />Terima {totalToReceive > 0 ? `${totalToReceive} Item` : "Barang"}</>)}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================
// Main Page
// ============================================
export default function TransaksiPage() {
  const [transaksiList, setTransaksiList] = useState<Transaksi[]>([]);
  const [barangList, setBarangList] = useState<Barang[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [filterTipe, setFilterTipe] = useState<"" | "Masuk" | "Keluar">("");
  const [showForm, setShowForm] = useState(false);
  const [formTipe, setFormTipe] = useState<TipeTransaksi>("Masuk");
  const [showPOReceive, setShowPOReceive] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [trxRes, brgRes] = await Promise.all([fetch("/api/transaksi"), fetch("/api/barang")]);
      const trxData = await trxRes.json();
      const brgData = await brgRes.json();
      if (trxData.success) setTransaksiList(trxData.data);
      if (brgData.success) setBarangList(brgData.data);
    } catch { toast.error("Gagal memuat data"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const filteredTransaksi = useMemo(() => {
    return transaksiList.filter((t) => {
      const matchSearch = !search || t.namaBarang.toLowerCase().includes(search.toLowerCase()) || t.kodeBarang.toLowerCase().includes(search.toLowerCase()) || t.keterangan.toLowerCase().includes(search.toLowerCase());
      const matchTipe = !filterTipe || t.tipe === filterTipe;
      return matchSearch && matchTipe;
    });
  }, [transaksiList, search, filterTipe]);

  const handleSubmit = async (data: TransaksiFormData) => {
    setSaving(true);
    try {
      const res = await fetch("/api/transaksi", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
      const result = await res.json();
      if (result.success) { toast.success(result.message || "Transaksi berhasil!"); setShowForm(false); fetchData(); }
      else toast.error(result.error || "Gagal mencatat transaksi");
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setSaving(false); }
  };

  const openForm = (tipe: TipeTransaksi) => { setFormTipe(tipe); setShowForm(true); };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Barang Masuk / Keluar</h1>
          <p className="text-sm text-navy-500 mt-1">Catat pergerakan barang dan lihat riwayat transaksi</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* NEW: Terima dari PO button */}
          <button onClick={() => setShowPOReceive(true)}
            className="btn-primary bg-blue-600 hover:bg-blue-700">
            <ClipboardList className="w-4 h-4" />
            Terima dari PO
          </button>
          <button onClick={() => openForm("Masuk")}
            className="btn-secondary text-emerald-700 border-emerald-200 hover:bg-emerald-50">
            <ArrowDownToLine className="w-4 h-4" />
            Manual Masuk
          </button>
          <button onClick={() => openForm("Keluar")}
            className="btn-primary bg-red-600 hover:bg-red-700">
            <ArrowUpFromLine className="w-4 h-4" />
            Barang Keluar
          </button>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="card p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari kode, nama barang, atau keterangan..." className="input-field pl-10" />
          </div>
          <div className="relative sm:w-44">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <select value={filterTipe} onChange={(e) => setFilterTipe(e.target.value as "" | "Masuk" | "Keluar")} className="input-field pl-10 appearance-none">
              <option value="">Semua Tipe</option>
              <option value="Masuk">Barang Masuk</option>
              <option value="Keluar">Barang Keluar</option>
            </select>
          </div>
          <button onClick={fetchData} disabled={loading} className="btn-secondary sm:w-auto">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 text-navy-300 animate-spin mx-auto mb-3" />
          <p className="text-sm text-navy-500">Memuat riwayat transaksi...</p>
        </div>
      ) : filteredTransaksi.length === 0 ? (
        <div className="card p-12 text-center">
          <ArrowLeftRight className="w-10 h-10 text-navy-300 mx-auto mb-3" />
          <p className="text-sm text-navy-500 mb-4">
            {search || filterTipe ? "Tidak ada transaksi yang cocok." : "Belum ada transaksi."}
          </p>
          <div className="flex items-center justify-center gap-3">
            <button onClick={() => setShowPOReceive(true)} className="btn-primary bg-blue-600 hover:bg-blue-700">
              <ClipboardList className="w-4 h-4" />Terima dari PO
            </button>
            <button onClick={() => openForm("Masuk")} className="btn-secondary">
              <ArrowDownToLine className="w-4 h-4" />Manual Masuk
            </button>
          </div>
        </div>
      ) : (
        <div className="table-container bg-white">
          <table>
            <thead>
              <tr>
                <th>Tanggal</th><th>Tipe</th><th>Kode</th><th>Nama Barang</th>
                <th className="text-center">Jumlah</th><th className="text-center">Sebelum</th>
                <th className="text-center">Sesudah</th><th>Keterangan</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransaksi.map((trx) => {
                const isMasuk = trx.tipe === "Masuk";
                return (
                  <tr key={trx.id}>
                    <td className="text-xs text-navy-500 whitespace-nowrap">{trx.tanggal}</td>
                    <td>
                      <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${isMasuk ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
                        {isMasuk ? <ArrowDownToLine className="w-3 h-3" /> : <ArrowUpFromLine className="w-3 h-3" />}{trx.tipe}
                      </span>
                    </td>
                    <td><span className="font-mono text-xs font-medium text-navy-600 bg-navy-50 px-2 py-0.5 rounded">{trx.kodeBarang}</span></td>
                    <td className="font-medium text-navy-900">{trx.namaBarang}</td>
                    <td className="text-center">
                      <span className={`font-mono font-bold ${isMasuk ? "text-emerald-600" : "text-red-600"}`}>{isMasuk ? "+" : "-"}{trx.jumlah}</span>
                      <span className="text-navy-400 text-xs ml-1">{trx.satuanBarang}</span>
                    </td>
                    <td className="text-center font-mono text-navy-400">{trx.stokSebelum}</td>
                    <td className="text-center font-mono font-semibold text-navy-700">{trx.stokSesudah}</td>
                    <td className="text-xs text-navy-500 max-w-[200px] truncate">{trx.keterangan || "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {filteredTransaksi.length > 0 && (
        <div className="mt-4 flex items-center justify-center gap-6 text-xs text-navy-400">
          <span>Total: <span className="font-semibold text-navy-600">{filteredTransaksi.length}</span></span>
          <span>Masuk: <span className="font-semibold text-emerald-600">{filteredTransaksi.filter((t) => t.tipe === "Masuk").length}</span></span>
          <span>Keluar: <span className="font-semibold text-red-600">{filteredTransaksi.filter((t) => t.tipe === "Keluar").length}</span></span>
        </div>
      )}

      {/* Modals */}
      <TransaksiFormModal isOpen={showForm} onClose={() => setShowForm(false)} onSubmit={handleSubmit} barangList={barangList} isLoading={saving} defaultTipe={formTipe} />
      <POReceiveModal isOpen={showPOReceive} onClose={() => setShowPOReceive(false)} onSaved={fetchData} />
    </div>
  );
}