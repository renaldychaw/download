"use client";

import { useEffect, useState, useMemo } from "react";
import {
  Plus, Search, Edit2, Trash2, X, Loader2, MapPin, Filter,
  AlertTriangle, RefreshCw, Warehouse,
} from "lucide-react";
import { Lokasi, LokasiFormData, ZONA_OPTIONS } from "@/lib/types";
import toast from "react-hot-toast";

// ============================================
// Form Modal
// ============================================
function LokasiFormModal({
  isOpen, onClose, onSubmit, initialData, isLoading,
}: {
  isOpen: boolean; onClose: () => void; onSubmit: (data: LokasiFormData) => void;
  initialData?: Lokasi | null; isLoading: boolean;
}) {
  const [form, setForm] = useState<LokasiFormData>({
    kode: "", nama: "", zona: "", kapasitas: 10, keterangan: "",
  });

  useEffect(() => {
    if (initialData) {
      setForm({ kode: initialData.kode, nama: initialData.nama, zona: initialData.zona, kapasitas: initialData.kapasitas, keterangan: initialData.keterangan });
    } else {
      setForm({ kode: "", nama: "", zona: "", kapasitas: 10, keterangan: "" });
    }
  }, [initialData, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); onSubmit(form); };
  const update = (field: keyof LokasiFormData, value: string | number) => setForm((p) => ({ ...p, [field]: value }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-md card p-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between px-6 py-4 border-b border-navy-100">
          <h2 className="text-lg font-semibold text-navy-900">
            {initialData ? "Edit Lokasi" : "Tambah Lokasi Baru"}
          </h2>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-navy-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Kode Lokasi <span className="text-red-500">*</span></label>
              <input type="text" value={form.kode} onChange={(e) => update("kode", e.target.value.toUpperCase())} placeholder="A-01" className="input-field font-mono" required />
            </div>
            <div>
              <label className="label">Zona <span className="text-red-500">*</span></label>
              <select value={form.zona} onChange={(e) => update("zona", e.target.value)} className="input-field" required>
                <option value="">Pilih zona</option>
                {ZONA_OPTIONS.map((z) => (<option key={z} value={z}>{z}</option>))}
              </select>
            </div>
          </div>

          <div>
            <label className="label">Nama Lokasi <span className="text-red-500">*</span></label>
            <input type="text" value={form.nama} onChange={(e) => update("nama", e.target.value)} placeholder="Rak A Baris 1" className="input-field" required />
          </div>

          <div>
            <label className="label">Kapasitas (max item)</label>
            <input type="number" value={form.kapasitas} onChange={(e) => update("kapasitas", parseInt(e.target.value) || 0)} min="1" className="input-field" />
          </div>

          <div>
            <label className="label">Keterangan</label>
            <textarea value={form.keterangan} onChange={(e) => update("keterangan", e.target.value)} placeholder="Catatan tambahan..." className="input-field resize-none" rows={2} />
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button type="button" onClick={onClose} className="btn-secondary">Batal</button>
            <button type="submit" disabled={isLoading} className="btn-primary">
              {isLoading ? (<><Loader2 className="w-4 h-4 animate-spin" />Menyimpan...</>) : initialData ? "Simpan Perubahan" : "Tambah Lokasi"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============================================
// Delete Modal
// ============================================
function DeleteModal({
  isOpen, onClose, onConfirm, lokasi, isLoading,
}: {
  isOpen: boolean; onClose: () => void; onConfirm: () => void;
  lokasi: Lokasi | null; isLoading: boolean;
}) {
  if (!isOpen || !lokasi) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-sm card p-6 shadow-2xl text-center">
        <div className="w-12 h-12 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-6 h-6 text-red-500" />
        </div>
        <h3 className="text-lg font-semibold text-navy-900 mb-2">Hapus Lokasi?</h3>
        <p className="text-sm text-navy-500 mb-1">
          <span className="font-mono text-navy-700">{lokasi.kode}</span> — {lokasi.nama}
        </p>
        {lokasi.terpakai > 0 && (
          <p className="text-xs text-amber-600 mb-2">
            Lokasi ini masih digunakan oleh {lokasi.terpakai} barang.
          </p>
        )}
        <p className="text-xs text-navy-400 mb-6">Data yang dihapus tidak dapat dikembalikan.</p>
        <div className="flex items-center justify-center gap-3">
          <button onClick={onClose} className="btn-secondary">Batal</button>
          <button onClick={onConfirm} disabled={isLoading} className="btn-primary bg-red-600 hover:bg-red-700">
            {isLoading ? (<><Loader2 className="w-4 h-4 animate-spin" />Menghapus...</>) : "Ya, Hapus"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main Page
// ============================================
export default function LokasiPage() {
  const [lokasiList, setLokasiList] = useState<Lokasi[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [filterZona, setFilterZona] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editData, setEditData] = useState<Lokasi | null>(null);
  const [showDelete, setShowDelete] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Lokasi | null>(null);

  const fetchLokasi = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/lokasi");
      const data = await res.json();
      if (data.success) setLokasiList(data.data);
      else toast.error(data.error || "Gagal memuat data");
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchLokasi(); }, []);

  const zonas = useMemo(() => [...new Set(lokasiList.map((l) => l.zona))].sort(), [lokasiList]);

  const filteredLokasi = useMemo(() => {
    return lokasiList.filter((l) => {
      const matchSearch = !search || l.kode.toLowerCase().includes(search.toLowerCase()) || l.nama.toLowerCase().includes(search.toLowerCase());
      const matchZona = !filterZona || l.zona === filterZona;
      return matchSearch && matchZona;
    });
  }, [lokasiList, search, filterZona]);

  // Group by zona for display
  const groupedByZona = useMemo(() => {
    const groups: Record<string, Lokasi[]> = {};
    filteredLokasi.forEach((l) => {
      if (!groups[l.zona]) groups[l.zona] = [];
      groups[l.zona].push(l);
    });
    // Sort locations within each group by kode
    Object.values(groups).forEach((arr) => arr.sort((a, b) => a.kode.localeCompare(b.kode)));
    return groups;
  }, [filteredLokasi]);

  const handleSubmit = async (data: LokasiFormData) => {
    setSaving(true);
    try {
      const isEdit = !!editData;
      const res = await fetch("/api/lokasi", {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(isEdit ? { id: editData.id, ...data } : data),
      });
      const result = await res.json();
      if (result.success) {
        toast.success(result.message || "Berhasil!");
        setShowForm(false); setEditData(null); fetchLokasi();
      } else toast.error(result.error || "Gagal menyimpan");
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      const res = await fetch(`/api/lokasi?id=${deleteTarget.id}`, { method: "DELETE" });
      const result = await res.json();
      if (result.success) {
        toast.success("Lokasi berhasil dihapus");
        setShowDelete(false); setDeleteTarget(null); fetchLokasi();
      } else toast.error(result.error || "Gagal menghapus");
    } catch { toast.error("Gagal terhubung ke server"); }
    finally { setSaving(false); }
  };

  const getCapacityColor = (terpakai: number, kapasitas: number) => {
    if (kapasitas === 0) return "bg-navy-300";
    const ratio = terpakai / kapasitas;
    if (ratio >= 1) return "bg-red-500";
    if (ratio >= 0.8) return "bg-amber-500";
    return "bg-emerald-500";
  };

  const getCapacityBorder = (terpakai: number, kapasitas: number) => {
    if (kapasitas === 0) return "border-navy-200";
    const ratio = terpakai / kapasitas;
    if (ratio >= 1) return "border-red-200";
    if (ratio >= 0.8) return "border-amber-200";
    return "border-navy-100";
  };

  // Stats
  const stats = useMemo(() => {
    const total = lokasiList.length;
    const penuh = lokasiList.filter((l) => l.kapasitas > 0 && l.terpakai >= l.kapasitas).length;
    const kosong = lokasiList.filter((l) => l.terpakai === 0).length;
    return { total, penuh, kosong };
  }, [lokasiList]);

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Lokasi Gudang</h1>
          <p className="text-sm text-navy-500 mt-1">
            Kelola layout rak dan zona penyimpanan ({lokasiList.length} lokasi)
          </p>
        </div>
        <button onClick={() => { setEditData(null); setShowForm(true); }} className="btn-primary">
          <Plus className="w-4 h-4" />Tambah Lokasi
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center">
            <MapPin className="w-5 h-5 text-blue-500" />
          </div>
          <div>
            <p className="text-xs text-navy-500">Total Lokasi</p>
            <p className="text-xl font-bold text-navy-900">{stats.total}</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
            <Warehouse className="w-5 h-5 text-red-500" />
          </div>
          <div>
            <p className="text-xs text-navy-500">Penuh</p>
            <p className="text-xl font-bold text-red-600">{stats.penuh}</p>
          </div>
        </div>
        <div className="card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center">
            <MapPin className="w-5 h-5 text-emerald-500" />
          </div>
          <div>
            <p className="text-xs text-navy-500">Kosong</p>
            <p className="text-xl font-bold text-emerald-600">{stats.kosong}</p>
          </div>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="card p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari kode atau nama lokasi..." className="input-field pl-10" />
          </div>
          <div className="relative sm:w-48">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <select value={filterZona} onChange={(e) => setFilterZona(e.target.value)} className="input-field pl-10 appearance-none">
              <option value="">Semua Zona</option>
              {zonas.map((z) => (<option key={z} value={z}>{z}</option>))}
            </select>
          </div>
          <button onClick={fetchLokasi} disabled={loading} className="btn-secondary sm:w-auto">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Content */}
      {loading ? (
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 text-navy-300 animate-spin mx-auto mb-3" />
          <p className="text-sm text-navy-500">Memuat data lokasi...</p>
        </div>
      ) : filteredLokasi.length === 0 ? (
        <div className="card p-12 text-center">
          <MapPin className="w-10 h-10 text-navy-300 mx-auto mb-3" />
          <p className="text-sm text-navy-500">
            {search || filterZona ? "Tidak ada lokasi yang cocok." : 'Belum ada lokasi. Klik "Tambah Lokasi" untuk mulai.'}
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {Object.entries(groupedByZona)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([zona, items]) => (
              <div key={zona}>
                <div className="flex items-center gap-2 mb-3">
                  <Warehouse className="w-4 h-4 text-navy-400" />
                  <h2 className="text-sm font-semibold text-navy-600 uppercase tracking-wide">{zona}</h2>
                  <span className="text-xs text-navy-400">({items.length} lokasi)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
                  {items.map((loc) => {
                    const pct = loc.kapasitas > 0 ? Math.min(100, Math.round((loc.terpakai / loc.kapasitas) * 100)) : 0;
                    return (
                      <div key={loc.id} className={`card p-4 border ${getCapacityBorder(loc.terpakai, loc.kapasitas)} hover:shadow-md transition-all group`}>
                        {/* Header */}
                        <div className="flex items-start justify-between mb-2">
                          <span className="font-mono text-lg font-bold text-navy-800">{loc.kode}</span>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => { setEditData(loc); setShowForm(true); }} className="p-1.5 rounded-lg text-navy-400 hover:bg-blue-50 hover:text-blue-600 transition-colors" title="Edit">
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => { setDeleteTarget(loc); setShowDelete(true); }} className="p-1.5 rounded-lg text-navy-400 hover:bg-red-50 hover:text-red-600 transition-colors" title="Hapus">
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Name */}
                        <p className="text-sm text-navy-600 mb-3 truncate">{loc.nama}</p>

                        {/* Capacity bar */}
                        <div className="mb-1.5">
                          <div className="flex justify-between text-[11px] text-navy-400 mb-1">
                            <span>Terisi</span>
                            <span className="font-mono font-semibold">
                              {loc.terpakai}/{loc.kapasitas}
                            </span>
                          </div>
                          <div className="h-2.5 bg-navy-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full transition-all duration-500 ${getCapacityColor(loc.terpakai, loc.kapasitas)}`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                        </div>

                        {/* Status label */}
                        {loc.kapasitas > 0 && loc.terpakai >= loc.kapasitas && (
                          <p className="text-[10px] text-red-500 font-semibold mt-1">PENUH</p>
                        )}
                        {loc.terpakai === 0 && (
                          <p className="text-[10px] text-emerald-500 font-semibold mt-1">TERSEDIA</p>
                        )}

                        {/* Keterangan */}
                        {loc.keterangan && (
                          <p className="text-[11px] text-navy-400 mt-2 truncate">{loc.keterangan}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
        </div>
      )}

      {/* Modals */}
      <LokasiFormModal isOpen={showForm} onClose={() => { setShowForm(false); setEditData(null); }} onSubmit={handleSubmit} initialData={editData} isLoading={saving} />
      <DeleteModal isOpen={showDelete} onClose={() => { setShowDelete(false); setDeleteTarget(null); }} onConfirm={handleDelete} lokasi={deleteTarget} isLoading={saving} />
    </div>
  );
}
