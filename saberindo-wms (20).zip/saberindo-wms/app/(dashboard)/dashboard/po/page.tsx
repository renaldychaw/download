"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import {
  Plus, Search, Filter, RefreshCw, Loader2, Upload, FileText,
  X, Eye, Trash2, CheckCircle2, Clock, AlertTriangle,
  Package, ArrowDownToLine, Save, FileUp, ChevronDown, ChevronUp,
} from "lucide-react";
import { PurchaseOrder, POFormData, POItem, POStatus } from "@/lib/types";
import toast from "react-hot-toast";

// ============================================
// Status Badge
// ============================================
function StatusBadge({ status }: { status: POStatus }) {
  const cfg = {
    Pending: { bg: "bg-red-50", text: "text-red-700", icon: Clock },
    Partial: { bg: "bg-amber-50", text: "text-amber-700", icon: AlertTriangle },
    Complete: { bg: "bg-emerald-50", text: "text-emerald-700", icon: CheckCircle2 },
  }[status];
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ${cfg.bg} ${cfg.text}`}>
      <Icon className="w-3 h-3" />{status}
    </span>
  );
}

// ============================================
// PDF Upload & Parse Modal
// ============================================
function UploadModal({
  isOpen, onClose, onSaved,
}: {
  isOpen: boolean; onClose: () => void; onSaved: () => void;
}) {
  const [files, setFiles] = useState<File[]>([]);
  const [parsing, setParsing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [parsed, setParsed] = useState<any[]>([]);
  const [step, setStep] = useState<"upload" | "preview">("upload");

  const reset = () => { setFiles([]); setParsed([]); setStep("upload"); };

  useEffect(() => { if (isOpen) reset(); }, [isOpen]);

  if (!isOpen) return null;

  const handleFiles = (newFiles: FileList | null) => {
    if (!newFiles) return;
    const pdfs = Array.from(newFiles).filter((f) => f.type === "application/pdf");
    setFiles((prev) => [...prev, ...pdfs]);
  };

  const handleParse = async () => {
    if (!files.length) return;
    setParsing(true);
    try {
      const formData = new FormData();
      files.forEach((f) => formData.append("files", f));

      const res = await fetch("/api/po", { method: "POST", body: formData });
      const data = await res.json();

      if (data.success && data.data.length > 0) {
        setParsed(data.data);
        setStep("preview");
        toast.success(data.message);
      } else if (data.data?.length === 0) {
        toast.error("Tidak ada PO yang berhasil diekstrak dari PDF");
      } else {
        toast.error(data.error || "Gagal parsing PDF");
      }
    } catch { toast.error("Gagal menghubungi server"); }
    finally { setParsing(false); }
  };

  const handleSaveAll = async () => {
    setSaving(true);
    try {
      // Kirim semua PO dalam SATU request batch — mencegah race condition
      // di Vercel serverless (multiple Lambda instances dengan /tmp berbeda)
      const payload = parsed.map((po) => ({
        poNumber: po.poNumber,
        poDate: po.poDate,
        supplier: po.supplier,
        description: po.description,
        items: po.items,
      }));

      const res = await fetch("/api/po", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload), // Array → batch mode
      });
      const data = await res.json();

      if (data.success) {
        toast.success(data.message || `${data.data?.length ?? parsed.length} PO berhasil disimpan`);
        onSaved();
        onClose();
      } else {
        toast.error(data.error || "Gagal menyimpan PO");
      }
    } catch {
      toast.error("Gagal menghubungi server");
    } finally {
      setSaving(false);
    }
  };

  const removeParsed = (i: number) => setParsed((p) => p.filter((_, idx) => idx !== i));

  const updateParsed = (poIdx: number, field: string, value: string) => {
    setParsed((prev) => prev.map((po, i) =>
      i === poIdx ? { ...po, [field]: value } : po
    ));
  };

  const updateParsedItem = (poIdx: number, itemIdx: number, field: string, value: string | number) => {
    setParsed((prev) => prev.map((po, i) =>
      i === poIdx ? {
        ...po,
        items: po.items.map((item: POItem, j: number) =>
          j === itemIdx ? { ...item, [field]: value } : item
        ),
      } : po
    ));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-3xl card p-0 shadow-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-navy-100 bg-blue-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
              <FileUp className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-navy-900">Import PO dari PDF</h2>
              <p className="text-xs text-navy-500">Upload file PDF Purchase Order Saberindo</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-white/80"><X className="w-5 h-5" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {step === "upload" && (
            <div className="space-y-4">
              {/* Dropzone */}
              <div
                onDragOver={(e) => { e.preventDefault(); e.currentTarget.classList.add("border-blue-400", "bg-blue-50"); }}
                onDragLeave={(e) => { e.currentTarget.classList.remove("border-blue-400", "bg-blue-50"); }}
                onDrop={(e) => { e.preventDefault(); e.currentTarget.classList.remove("border-blue-400", "bg-blue-50"); handleFiles(e.dataTransfer.files); }}
                className="border-2 border-dashed border-navy-200 rounded-xl p-8 text-center cursor-pointer hover:border-blue-400 hover:bg-blue-50/50 transition-all"
                onClick={() => document.getElementById("pdf-input")?.click()}
              >
                <Upload className="w-10 h-10 text-navy-300 mx-auto mb-3" />
                <p className="text-sm font-medium text-navy-700">Drag & drop file PDF di sini</p>
                <p className="text-xs text-navy-400 mt-1">atau klik untuk memilih file (bisa multiple)</p>
                <input id="pdf-input" type="file" accept=".pdf" multiple className="hidden" onChange={(e) => handleFiles(e.target.files)} />
              </div>

              {/* File list */}
              {files.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs text-navy-500 font-semibold">{files.length} file dipilih:</p>
                  {files.map((f, i) => (
                    <div key={i} className="flex items-center justify-between rounded-lg border border-navy-100 px-3 py-2">
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-red-400" />
                        <span className="text-sm text-navy-700 truncate">{f.name}</span>
                        <span className="text-[10px] text-navy-400">{(f.size / 1024).toFixed(0)} KB</span>
                      </div>
                      <button onClick={() => setFiles((p) => p.filter((_, idx) => idx !== i))} className="text-navy-400 hover:text-red-500">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <button onClick={handleParse} disabled={parsing || !files.length} className="btn-primary w-full justify-center">
                {parsing ? (<><Loader2 className="w-4 h-4 animate-spin" />Membaca PDF...</>) : (<><FileText className="w-4 h-4" />Ekstrak Data PO</>)}
              </button>
            </div>
          )}

          {step === "preview" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-navy-700">{parsed.length} PO diekstrak:</p>
                <button onClick={() => setStep("upload")} className="text-xs text-blue-600 hover:text-blue-700">← Upload lagi</button>
              </div>

              {parsed.map((po, pi) => (
                <div key={pi} className="border border-navy-100 rounded-xl overflow-hidden">
                  {/* Editable header */}
                  <div className="px-4 py-3 bg-navy-50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-navy-400 font-semibold uppercase tracking-wide">PO #{pi + 1}</span>
                      <button onClick={() => removeParsed(pi)} className="text-navy-400 hover:text-red-500"><X className="w-4 h-4" /></button>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[10px] text-navy-400">PO Number</label>
                        <input type="text" value={po.poNumber} onChange={(e) => updateParsed(pi, "poNumber", e.target.value)}
                          className="input-field text-xs font-mono py-1.5" />
                      </div>
                      <div>
                        <label className="text-[10px] text-navy-400">Tanggal</label>
                        <input type="text" value={po.poDate} onChange={(e) => updateParsed(pi, "poDate", e.target.value)}
                          className="input-field text-xs py-1.5" />
                      </div>
                      <div>
                        <label className="text-[10px] text-navy-400">
                          Supplier {!po.supplier && <span className="text-red-500">*kosong</span>}
                        </label>
                        <input type="text" value={po.supplier || ""} onChange={(e) => updateParsed(pi, "supplier", e.target.value)}
                          placeholder="Isi nama supplier..."
                          className={`input-field text-xs py-1.5 ${!po.supplier ? "border-red-300 bg-red-50/50" : ""}`} />
                      </div>
                    </div>
                  </div>

                  <div className="px-4 py-2">
                    {po.description && <p className="text-xs text-navy-500 mb-2 truncate">{po.description}</p>}
                    <table className="w-full text-xs">
                      <thead><tr className="text-navy-400">
                        <th className="text-left py-1">Item Code</th><th className="text-left py-1">Nama</th><th className="text-right py-1">Qty</th>
                      </tr></thead>
                      <tbody>
                        {po.items.map((item: POItem, ii: number) => (
                          <tr key={ii} className="border-t border-navy-50">
                            <td className="py-1.5">
                              <input type="text" value={item.itemCode}
                                onChange={(e) => updateParsedItem(pi, ii, "itemCode", e.target.value)}
                                className="font-mono text-navy-600 bg-transparent border-b border-transparent hover:border-navy-200 focus:border-blue-400 outline-none w-full text-xs py-0.5" />
                            </td>
                            <td className="py-1.5">
                              <input type="text" value={item.namaBarang}
                                onChange={(e) => updateParsedItem(pi, ii, "namaBarang", e.target.value)}
                                className="text-navy-700 bg-transparent border-b border-transparent hover:border-navy-200 focus:border-blue-400 outline-none w-full text-xs py-0.5" />
                            </td>
                            <td className="py-1.5 text-right">
                              <input type="number" value={item.qtyOrdered} min={0}
                                onChange={(e) => updateParsedItem(pi, ii, "qtyOrdered", parseInt(e.target.value) || 0)}
                                className="font-mono font-semibold text-right bg-transparent border-b border-transparent hover:border-navy-200 focus:border-blue-400 outline-none w-16 ml-auto text-xs py-0.5" />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {step === "preview" && parsed.length > 0 && (
          <div className="border-t border-navy-100 px-6 py-4 flex justify-end gap-3">
            <button onClick={onClose} className="btn-secondary">Batal</button>
            <button onClick={handleSaveAll} disabled={saving} className="btn-primary bg-emerald-600 hover:bg-emerald-700">
              {saving ? (<><Loader2 className="w-4 h-4 animate-spin" />Menyimpan...</>) : (<><Save className="w-4 h-4" />Simpan {parsed.length} PO</>)}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ============================================
// PO Detail Modal
// ============================================
function DetailModal({
  isOpen, onClose, po,
}: {
  isOpen: boolean; onClose: () => void; po: PurchaseOrder | null;
}) {
  if (!isOpen || !po) return null;

  const totalOrdered = po.items.reduce((s, i) => s + i.qtyOrdered, 0);
  const totalReceived = po.items.reduce((s, i) => s + i.qtyReceived, 0);
  const pct = totalOrdered > 0 ? Math.round((totalReceived / totalOrdered) * 100) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl card p-0 shadow-2xl max-h-[85vh] overflow-hidden flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-navy-100">
          <div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-lg font-bold text-blue-600">{po.poNumber}</span>
              <StatusBadge status={po.status} />
            </div>
            <p className="text-xs text-navy-400 mt-1">{po.supplier} &bull; {po.poDate}</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-navy-100"><X className="w-5 h-5" /></button>
        </div>

        {/* Progress */}
        <div className="px-6 py-4 bg-navy-50/50 border-b border-navy-100">
          <div className="flex items-center justify-between text-xs text-navy-500 mb-1.5">
            <span>Progress Penerimaan</span>
            <span className="font-mono font-semibold">{totalReceived}/{totalOrdered} ({pct}%)</span>
          </div>
          <div className="h-3 bg-navy-200 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all ${pct >= 100 ? "bg-emerald-500" : pct > 0 ? "bg-amber-500" : "bg-navy-300"}`} style={{ width: `${pct}%` }} />
          </div>
          {po.description && <p className="text-xs text-navy-500 mt-3">{po.description}</p>}
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="bg-navy-50 border-b border-navy-100 sticky top-0">
              <tr>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-navy-500">Item Code</th>
                <th className="px-4 py-2.5 text-left text-xs font-semibold text-navy-500">Nama Barang</th>
                <th className="px-4 py-2.5 text-center text-xs font-semibold text-navy-500">Ordered</th>
                <th className="px-4 py-2.5 text-center text-xs font-semibold text-navy-500">Received</th>
                <th className="px-4 py-2.5 text-center text-xs font-semibold text-navy-500">Status</th>
              </tr>
            </thead>
            <tbody>
              {po.items.map((item, i) => {
                const done = item.qtyReceived >= item.qtyOrdered;
                const partial = item.qtyReceived > 0 && !done;
                return (
                  <tr key={i} className="border-b border-navy-50 hover:bg-navy-50/50">
                    <td className="px-4 py-3"><span className="font-mono text-xs text-navy-600 bg-navy-50 px-2 py-0.5 rounded">{item.itemCode}</span></td>
                    <td className="px-4 py-3 text-navy-800">{item.namaBarang}</td>
                    <td className="px-4 py-3 text-center font-mono">{item.qtyOrdered}</td>
                    <td className="px-4 py-3 text-center font-mono font-semibold">{item.qtyReceived}</td>
                    <td className="px-4 py-3 text-center">
                      {done ? <span className="badge-green">Lengkap</span> : partial ? <span className="badge-yellow">Sebagian</span> : <span className="badge-red">Belum</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main PO Page
// ============================================
export default function POPage() {
  const [poList, setPOList] = useState<PurchaseOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<"" | POStatus>("");
  const [showUpload, setShowUpload] = useState(false);
  const [selectedPO, setSelectedPO] = useState<PurchaseOrder | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);

  const fetchPO = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/po");
      const data = await res.json();
      if (data.success) setPOList(data.data);
    } catch { toast.error("Gagal memuat data PO"); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchPO(); }, []);

  const filteredPO = useMemo(() => {
    return poList.filter((po) => {
      const matchSearch = !search ||
        po.poNumber.toLowerCase().includes(search.toLowerCase()) ||
        po.supplier.toLowerCase().includes(search.toLowerCase()) ||
        po.description.toLowerCase().includes(search.toLowerCase());
      const matchStatus = !filterStatus || po.status === filterStatus;
      return matchSearch && matchStatus;
    });
  }, [poList, search, filterStatus]);

  const stats = useMemo(() => ({
    total: poList.length,
    pending: poList.filter((p) => p.status === "Pending").length,
    partial: poList.filter((p) => p.status === "Partial").length,
    complete: poList.filter((p) => p.status === "Complete").length,
  }), [poList]);

  const handleDelete = async (id: string) => {
    setDeleting(id);
    try {
      const res = await fetch(`/api/po?id=${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) { toast.success("PO dihapus"); fetchPO(); }
      else toast.error(data.error);
    } catch { toast.error("Gagal menghapus"); }
    finally { setDeleting(null); }
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Purchase Orders</h1>
          <p className="text-sm text-navy-500 mt-1">Kelola PO dan lacak penerimaan barang</p>
        </div>
        <button onClick={() => setShowUpload(true)} className="btn-primary">
          <Upload className="w-4 h-4" />Import dari PDF
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <button onClick={() => setFilterStatus("")} className={`card p-4 text-left transition-all hover:shadow-md ${!filterStatus ? "ring-2 ring-blue-400" : ""}`}>
          <p className="text-xs text-navy-500">Total PO</p>
          <p className="text-2xl font-bold text-navy-900">{stats.total}</p>
        </button>
        <button onClick={() => setFilterStatus(filterStatus === "Pending" ? "" : "Pending")} className={`card p-4 text-left transition-all hover:shadow-md ${filterStatus === "Pending" ? "ring-2 ring-red-400" : ""}`}>
          <p className="text-xs text-navy-500">Pending</p>
          <p className="text-2xl font-bold text-red-600">{stats.pending}</p>
        </button>
        <button onClick={() => setFilterStatus(filterStatus === "Partial" ? "" : "Partial")} className={`card p-4 text-left transition-all hover:shadow-md ${filterStatus === "Partial" ? "ring-2 ring-amber-400" : ""}`}>
          <p className="text-xs text-navy-500">Partial</p>
          <p className="text-2xl font-bold text-amber-600">{stats.partial}</p>
        </button>
        <button onClick={() => setFilterStatus(filterStatus === "Complete" ? "" : "Complete")} className={`card p-4 text-left transition-all hover:shadow-md ${filterStatus === "Complete" ? "ring-2 ring-emerald-400" : ""}`}>
          <p className="text-xs text-navy-500">Complete</p>
          <p className="text-2xl font-bold text-emerald-600">{stats.complete}</p>
        </button>
      </div>

      {/* Search */}
      <div className="card p-4 mb-6">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Cari PO number, supplier, atau deskripsi..." className="input-field pl-10" />
          </div>
          <button onClick={fetchPO} disabled={loading} className="btn-secondary">
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {/* Table */}
      {loading ? (
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 text-navy-300 animate-spin mx-auto mb-3" />
          <p className="text-sm text-navy-500">Memuat data PO...</p>
        </div>
      ) : filteredPO.length === 0 ? (
        <div className="card p-12 text-center">
          <FileText className="w-10 h-10 text-navy-300 mx-auto mb-3" />
          <p className="text-sm text-navy-500 mb-4">
            {search || filterStatus ? "Tidak ada PO yang cocok." : "Belum ada Purchase Order."}
          </p>
          <button onClick={() => setShowUpload(true)} className="btn-primary">
            <Upload className="w-4 h-4" />Import PDF
          </button>
        </div>
      ) : (
        <div className="table-container bg-white">
          <table>
            <thead>
              <tr>
                <th>PO Number</th>
                <th>Tanggal</th>
                <th>Supplier</th>
                <th className="text-center">Items</th>
                <th className="text-center">Progress</th>
                <th className="text-center">Status</th>
                <th>Deskripsi</th>
                <th className="text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {filteredPO.map((po) => {
                const totalOrd = po.items.reduce((s, i) => s + i.qtyOrdered, 0);
                const totalRcv = po.items.reduce((s, i) => s + i.qtyReceived, 0);
                const pct = totalOrd > 0 ? Math.round((totalRcv / totalOrd) * 100) : 0;
                return (
                  <tr key={po.id} className="cursor-pointer" onClick={() => { setSelectedPO(po); setShowDetail(true); }}>
                    <td><span className="font-mono text-sm font-bold text-blue-600 hover:text-blue-700">{po.poNumber}</span></td>
                    <td className="text-xs text-navy-500 whitespace-nowrap">{po.poDate}</td>
                    <td className="text-sm text-navy-800 max-w-[180px] truncate">{po.supplier}</td>
                    <td className="text-center"><span className="badge-blue">{po.items.length}</span></td>
                    <td className="text-center">
                      <div className="flex items-center gap-2 justify-center min-w-[100px]">
                        <div className="flex-1 h-2 bg-navy-100 rounded-full overflow-hidden max-w-[80px]">
                          <div className={`h-full rounded-full ${pct >= 100 ? "bg-emerald-500" : pct > 0 ? "bg-amber-500" : "bg-navy-200"}`} style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-[11px] font-mono text-navy-500">{pct}%</span>
                      </div>
                    </td>
                    <td className="text-center"><StatusBadge status={po.status} /></td>
                    <td className="text-xs text-navy-500 max-w-[150px] truncate">{po.description || "—"}</td>
                    <td className="text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1">
                        <button onClick={() => { setSelectedPO(po); setShowDetail(true); }} className="p-2 rounded-lg text-navy-400 hover:bg-blue-50 hover:text-blue-600 transition-colors" title="Detail">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDelete(po.id)} disabled={deleting === po.id} className="p-2 rounded-lg text-navy-400 hover:bg-red-50 hover:text-red-600 transition-colors" title="Hapus">
                          {deleting === po.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {filteredPO.length > 0 && (
        <p className="mt-4 text-center text-xs text-navy-400">
          Menampilkan {filteredPO.length} dari {poList.length} PO
        </p>
      )}

      {/* Modals */}
      <UploadModal isOpen={showUpload} onClose={() => setShowUpload(false)} onSaved={fetchPO} />
      <DetailModal isOpen={showDetail} onClose={() => { setShowDetail(false); setSelectedPO(null); }} po={selectedPO} />
    </div>
  );
}