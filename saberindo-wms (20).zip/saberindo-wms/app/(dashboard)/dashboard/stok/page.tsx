"use client";

import { useEffect, useState, useMemo } from "react";
import {
  Activity,
  Search,
  Filter,
  RefreshCw,
  Loader2,
  AlertTriangle,
  XCircle,
  CheckCircle2,
  X,
  ArrowDownToLine,
  ArrowUpFromLine,
  TrendingDown,
  TrendingUp,
  Package,
} from "lucide-react";
import { Barang, Transaksi } from "@/lib/types";
import toast from "react-hot-toast";

type SortMode = "status" | "nama" | "stok-asc" | "stok-desc";
type StatusFilter = "" | "kosong" | "rendah" | "aman";

// ============================================
// Stok Status helpers
// ============================================
function getStokStatus(stok: number, minimum: number, stokAwal: number = 0) {
  if (stok === 0) return { label: "Kosong", color: "red", priority: 0 };
  const threshold = stokAwal > 0 ? stokAwal * 0.4 : minimum;
  if (stok <= threshold) return { label: "Rendah", color: "amber", priority: 1 };
  return { label: "Aman", color: "emerald", priority: 2 };
}

function getStokPercentage(stok: number, minimum: number, stokAwal: number = 0): number {
  const target = stokAwal > 0 ? stokAwal : (minimum > 0 ? minimum * 2 : 0);
  if (target === 0) return stok > 0 ? 100 : 0;
  return Math.min(100, Math.round((stok / target) * 100));
}

// ============================================
// Transaction History Modal
// ============================================
function HistoryModal({
  isOpen,
  onClose,
  barang,
}: {
  isOpen: boolean;
  onClose: () => void;
  barang: Barang | null;
}) {
  const [history, setHistory] = useState<Transaksi[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!isOpen || !barang) return;
    setLoading(true);
    fetch(`/api/transaksi?barangId=${barang.id}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.success) setHistory(data.data);
      })
      .catch(() => toast.error("Gagal memuat riwayat"))
      .finally(() => setLoading(false));
  }, [isOpen, barang]);

  if (!isOpen || !barang) return null;

  const status = getStokStatus(barang.stok, barang.stokMinimum, barang.stokAwal ?? 0);
  const pct = getStokPercentage(barang.stok, barang.stokMinimum, barang.stokAwal ?? 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl card p-0 shadow-2xl max-h-[85vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-navy-100">
          <div className="min-w-0">
            <h2 className="text-lg font-semibold text-navy-900 truncate">
              {barang.nama}
            </h2>
            <p className="text-xs text-navy-400 mt-0.5">
              <span className="font-mono">{barang.kode}</span>
              {barang.lokasi && <> &bull; {barang.lokasi}</>}
              &bull; {barang.kategori}
            </p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-navy-400 hover:bg-navy-100 transition-colors flex-shrink-0 ml-4">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stok Summary */}
        <div className="px-6 py-4 bg-navy-50/50 border-b border-navy-100">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-navy-500 mb-1">Stok Saat Ini</p>
              <p className={`text-2xl font-bold ${
                status.color === "red" ? "text-red-600" :
                status.color === "amber" ? "text-amber-600" : "text-emerald-600"
              }`}>
                {barang.stok} <span className="text-sm font-normal text-navy-400">{barang.satuan}</span>
              </p>
            </div>
            <div>
              <p className="text-xs text-navy-500 mb-1">Stok Minimum</p>
              <p className="text-2xl font-bold text-navy-700">
                {barang.stokMinimum} <span className="text-sm font-normal text-navy-400">{barang.satuan}</span>
              </p>
            </div>
            <div>
              <p className="text-xs text-navy-500 mb-1">Status</p>
              <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold ${
                status.color === "red" ? "bg-red-100 text-red-700" :
                status.color === "amber" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"
              }`}>
                {status.color === "red" ? <XCircle className="w-4 h-4" /> :
                 status.color === "amber" ? <AlertTriangle className="w-4 h-4" /> :
                 <CheckCircle2 className="w-4 h-4" />}
                {status.label}
              </span>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mt-3">
            <div className="flex items-center justify-between text-[10px] text-navy-400 mb-1">
              <span>0</span>
              <span>Min: {barang.stokMinimum}</span>
              <span>{(barang.stokAwal ?? 0) > 0 ? `Awal: ${barang.stokAwal}` : `Target: ${barang.stokMinimum * 2}`}</span>
            </div>
            <div className="h-3 bg-navy-200 rounded-full overflow-hidden relative">
              {/* Minimum line marker */}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-navy-400 z-10"
                style={{ left: "50%" }}
              />
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  status.color === "red" ? "bg-red-500" :
                  status.color === "amber" ? "bg-amber-500" : "bg-emerald-500"
                }`}
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        </div>

        {/* Transaction History */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-6 py-3 border-b border-navy-100 bg-white sticky top-0">
            <h3 className="text-sm font-semibold text-navy-700">
              Riwayat Transaksi ({history.length})
            </h3>
          </div>

          {loading ? (
            <div className="p-8 text-center">
              <Loader2 className="w-6 h-6 text-navy-300 animate-spin mx-auto mb-2" />
              <p className="text-sm text-navy-400">Memuat riwayat...</p>
            </div>
          ) : history.length === 0 ? (
            <div className="p-8 text-center">
              <Package className="w-8 h-8 text-navy-200 mx-auto mb-2" />
              <p className="text-sm text-navy-400">Belum ada riwayat transaksi.</p>
            </div>
          ) : (
            <div className="divide-y divide-navy-50">
              {history.map((trx) => {
                const isMasuk = trx.tipe === "Masuk";
                return (
                  <div key={trx.id} className="px-6 py-3 flex items-center gap-4 hover:bg-navy-50/50">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                      isMasuk ? "bg-emerald-50" : "bg-red-50"
                    }`}>
                      {isMasuk ? (
                        <ArrowDownToLine className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <ArrowUpFromLine className="w-4 h-4 text-red-600" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-semibold ${isMasuk ? "text-emerald-600" : "text-red-600"}`}>
                          {isMasuk ? "+" : "-"}{trx.jumlah} {trx.satuanBarang}
                        </span>
                        <span className="text-xs text-navy-400">
                          {trx.stokSebelum} → {trx.stokSesudah}
                        </span>
                      </div>
                      {trx.keterangan && (
                        <p className="text-xs text-navy-500 truncate mt-0.5">{trx.keterangan}</p>
                      )}
                    </div>
                    <span className="text-[11px] text-navy-400 flex-shrink-0 whitespace-nowrap">
                      {trx.tanggal}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================
// Main Stok Monitor Page
// ============================================
export default function StokMonitorPage() {
  const [barangList, setBarangList] = useState<Barang[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<StatusFilter>("");
  const [sortMode, setSortMode] = useState<SortMode>("status");
  const [selectedBarang, setSelectedBarang] = useState<Barang | null>(null);
  const [showHistory, setShowHistory] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/barang");
      const data = await res.json();
      if (data.success) setBarangList(data.data);
      else toast.error(data.error || "Gagal memuat data");
    } catch {
      toast.error("Gagal terhubung ke server");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Stats
  const stats = useMemo(() => {
    const kosong = barangList.filter((b) => b.stok === 0).length;
    const rendah = barangList.filter((b) => {
      const threshold = (b.stokAwal ?? 0) > 0 ? b.stokAwal * 0.4 : b.stokMinimum;
      return b.stok > 0 && b.stok <= threshold;
    }).length;
    const aman = barangList.filter((b) => {
      const threshold = (b.stokAwal ?? 0) > 0 ? b.stokAwal * 0.4 : b.stokMinimum;
      return b.stok > threshold;
    }).length;
    return { kosong, rendah, aman, total: barangList.length };
  }, [barangList]);

  // Filter, search, sort
  const displayList = useMemo(() => {
    let list = barangList.filter((b) => {
      const matchSearch =
        !search ||
        b.nama.toLowerCase().includes(search.toLowerCase()) ||
        b.kode.toLowerCase().includes(search.toLowerCase());

      let matchStatus = true;
      const threshold = (b.stokAwal ?? 0) > 0 ? b.stokAwal * 0.4 : b.stokMinimum;
      if (filterStatus === "kosong") matchStatus = b.stok === 0;
      else if (filterStatus === "rendah") matchStatus = b.stok > 0 && b.stok <= threshold;
      else if (filterStatus === "aman") matchStatus = b.stok > threshold;

      return matchSearch && matchStatus;
    });

    list.sort((a, b) => {
      if (sortMode === "status") {
        const sa = getStokStatus(a.stok, a.stokMinimum, a.stokAwal ?? 0).priority;
        const sb = getStokStatus(b.stok, b.stokMinimum, b.stokAwal ?? 0).priority;
        return sa - sb; // critical first
      }
      if (sortMode === "nama") return a.nama.localeCompare(b.nama);
      if (sortMode === "stok-asc") return a.stok - b.stok;
      if (sortMode === "stok-desc") return b.stok - a.stok;
      return 0;
    });

    return list;
  }, [barangList, search, filterStatus, sortMode]);

  const openHistory = (barang: Barang) => {
    setSelectedBarang(barang);
    setShowHistory(true);
  };

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-navy-900">Stok Monitor</h1>
          <p className="text-sm text-navy-500 mt-1">
            Pantau level stok barang secara real-time
          </p>
        </div>
        <button onClick={fetchData} disabled={loading} className="btn-secondary">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </button>
      </div>

      {/* Status Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
        <button
          onClick={() => setFilterStatus(filterStatus === "kosong" ? "" : "kosong")}
          className={`card p-4 text-left transition-all hover:shadow-md ${
            filterStatus === "kosong" ? "ring-2 ring-red-400 border-red-200" : ""
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center">
                <XCircle className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <p className="text-xs text-navy-500 font-medium">Stok Kosong</p>
                <p className="text-xl font-bold text-red-600">{stats.kosong}</p>
              </div>
            </div>
            {stats.kosong > 0 && (
              <span className="text-[10px] bg-red-100 text-red-600 px-2 py-1 rounded-full font-bold animate-pulse">
                KRITIS
              </span>
            )}
          </div>
        </button>

        <button
          onClick={() => setFilterStatus(filterStatus === "rendah" ? "" : "rendah")}
          className={`card p-4 text-left transition-all hover:shadow-md ${
            filterStatus === "rendah" ? "ring-2 ring-amber-400 border-amber-200" : ""
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5 text-amber-500" />
            </div>
            <div>
              <p className="text-xs text-navy-500 font-medium">Stok Rendah</p>
              <p className="text-xl font-bold text-amber-600">{stats.rendah}</p>
            </div>
          </div>
        </button>

        <button
          onClick={() => setFilterStatus(filterStatus === "aman" ? "" : "aman")}
          className={`card p-4 text-left transition-all hover:shadow-md ${
            filterStatus === "aman" ? "ring-2 ring-emerald-400 border-emerald-200" : ""
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <p className="text-xs text-navy-500 font-medium">Stok Aman</p>
              <p className="text-xl font-bold text-emerald-600">{stats.aman}</p>
            </div>
          </div>
        </button>
      </div>

      {/* Alert Banner */}
      {(stats.kosong > 0 || stats.rendah > 0) && !filterStatus && (
        <div className="mb-6 rounded-xl border border-red-200 bg-gradient-to-r from-red-50 to-amber-50 p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-navy-800">
                Perhatian: {stats.kosong + stats.rendah} barang butuh restok
              </p>
              <p className="text-xs text-navy-500 mt-0.5">
                {stats.kosong > 0 && <><span className="text-red-600 font-semibold">{stats.kosong} kosong</span></>}
                {stats.kosong > 0 && stats.rendah > 0 && " dan "}
                {stats.rendah > 0 && <><span className="text-amber-600 font-semibold">{stats.rendah} di bawah minimum</span></>}
                . Segera lakukan pengadaan untuk menghindari kehabisan stok.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Search, Sort */}
      <div className="card p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari kode atau nama barang..."
              className="input-field pl-10"
            />
          </div>
          <div className="relative sm:w-48">
            <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-navy-400" />
            <select
              value={sortMode}
              onChange={(e) => setSortMode(e.target.value as SortMode)}
              className="input-field pl-10 appearance-none"
            >
              <option value="status">Urutkan: Status Kritis</option>
              <option value="nama">Urutkan: Nama A-Z</option>
              <option value="stok-asc">Urutkan: Stok Terendah</option>
              <option value="stok-desc">Urutkan: Stok Tertinggi</option>
            </select>
          </div>
          {filterStatus && (
            <button onClick={() => setFilterStatus("")} className="btn-secondary text-xs">
              <X className="w-3.5 h-3.5" />
              Reset Filter
            </button>
          )}
        </div>
      </div>

      {/* Stok Cards Grid */}
      {loading ? (
        <div className="card p-12 text-center">
          <Loader2 className="w-8 h-8 text-navy-300 animate-spin mx-auto mb-3" />
          <p className="text-sm text-navy-500">Memuat data stok...</p>
        </div>
      ) : displayList.length === 0 ? (
        <div className="card p-12 text-center">
          <Activity className="w-10 h-10 text-navy-300 mx-auto mb-3" />
          <p className="text-sm text-navy-500">
            {search || filterStatus
              ? "Tidak ada barang yang cocok dengan filter."
              : "Belum ada data barang."}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {displayList.map((item) => {
            const status = getStokStatus(item.stok, item.stokMinimum, item.stokAwal ?? 0);
            const pct = getStokPercentage(item.stok, item.stokMinimum, item.stokAwal ?? 0);

            const barColor =
              status.color === "red" ? "bg-red-500" :
              status.color === "amber" ? "bg-amber-500" : "bg-emerald-500";

            const statusBadge =
              status.color === "red" ? "bg-red-100 text-red-700" :
              status.color === "amber" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700";

            const borderColor =
              status.color === "red" ? "border-red-200 hover:border-red-300" :
              status.color === "amber" ? "border-amber-200 hover:border-amber-300" : "border-navy-100 hover:border-navy-200";

            return (
              <button
                key={item.id}
                onClick={() => openHistory(item)}
                className={`card p-5 text-left border ${borderColor} transition-all hover:shadow-md active:scale-[0.99] group`}
              >
                {/* Top row */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-navy-900 truncate group-hover:text-brand-700 transition-colors">
                      {item.nama}
                    </p>
                    <p className="text-xs text-navy-400 mt-0.5">
                      <span className="font-mono">{item.kode}</span>
                      {item.lokasi && <> &bull; {item.lokasi}</>}
                    </p>
                  </div>
                  <span className={`flex-shrink-0 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-bold ${statusBadge}`}>
                    {status.color === "red" ? <XCircle className="w-3 h-3" /> :
                     status.color === "amber" ? <AlertTriangle className="w-3 h-3" /> :
                     <CheckCircle2 className="w-3 h-3" />}
                    {status.label}
                  </span>
                </div>

                {/* Stok numbers */}
                <div className="flex items-end justify-between mb-2">
                  <div>
                    <span className={`text-2xl font-bold ${
                      status.color === "red" ? "text-red-600" :
                      status.color === "amber" ? "text-amber-600" : "text-navy-800"
                    }`}>
                      {item.stok}
                    </span>
                    <span className="text-sm text-navy-400 ml-1">{item.satuan}</span>
                  </div>
                  <span className="text-xs text-navy-400">
                    {(item.stokAwal ?? 0) > 0
                      ? <>Awal: <span className="font-mono font-semibold">{item.stokAwal}</span> · <span className="text-amber-600 font-mono font-semibold">40% = {Math.round(item.stokAwal * 0.4)}</span></>
                      : <>Min: <span className="font-mono font-semibold">{item.stokMinimum}</span></>
                    }
                  </span>
                </div>

                {/* Progress bar */}
                <div className="h-2.5 bg-navy-100 rounded-full overflow-hidden relative">
                  <div
                    className={`h-full rounded-full transition-all duration-700 ${barColor}`}
                    style={{ width: `${pct}%` }}
                  />
                  {/* Minimum marker */}
                  {item.stokMinimum > 0 && (
                    <div
                      className="absolute top-0 bottom-0 w-px bg-navy-300"
                      style={{ left: "50%" }}
                    />
                  )}
                </div>

                {/* Footer hint */}
                <p className="text-[11px] text-navy-400 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  Klik untuk lihat riwayat transaksi →
                </p>
              </button>
            );
          })}
        </div>
      )}

      {/* Count */}
      {displayList.length > 0 && (
        <p className="mt-4 text-center text-xs text-navy-400">
          Menampilkan {displayList.length} dari {barangList.length} barang
        </p>
      )}

      {/* History Modal */}
      <HistoryModal
        isOpen={showHistory}
        onClose={() => {
          setShowHistory(false);
          setSelectedBarang(null);
        }}
        barang={selectedBarang}
      />
    </div>
  );
}