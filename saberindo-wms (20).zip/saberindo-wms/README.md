# 🔥 Saberindo WMS

**Warehouse Management System** untuk PT Saberindo Pacific — sistem manajemen gudang berbasis web untuk kebutuhan distribusi peralatan fire protection.

---

## ✨ Fitur Utama

| Modul | Deskripsi |
|---|---|
| 📊 **Dashboard** | Ringkasan stok real-time, statistik transaksi harian, dan alert stok kritis |
| 📦 **Master Barang** | Kelola data barang: kode, kategori, satuan, lokasi, dan stok minimum |
| 🛒 **Purchase Order** | Input PO manual atau **upload PDF** untuk ekstrak data otomatis |
| 🔄 **Barang Masuk/Keluar** | Catat transaksi masuk dan keluar dengan update stok otomatis |
| 📡 **Stok Monitor** | Pantau stok per barang dengan indikator visual stok rendah/kosong |
| 📍 **Lokasi Gudang** | Manajemen zona dan kapasitas lokasi penyimpanan |
| 📈 **Laporan & Export** | Filter laporan berdasarkan tanggal/tipe, export ke Excel |

---

## 🛠️ Tech Stack

- **Framework:** [Next.js 14](https://nextjs.org/) (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Storage:** [Vercel Blob](https://vercel.com/docs/storage/vercel-blob) (file Excel sebagai database)
- **PDF Parsing:** [pdf-parse](https://www.npmjs.com/package/pdf-parse) (Node.js, tanpa Python)
- **Excel Processing:** [ExcelJS](https://github.com/exceljs/exceljs)
- **Icons:** [Lucide React](https://lucide.dev/)
- **Deployment:** [Vercel](https://vercel.com/)

---

## 🚀 Setup & Instalasi

### 1. Clone repository

```bash
git clone https://github.com/username/saberindo-wms.git
cd saberindo-wms
```

### 2. Install dependencies

```bash
npm install
```

### 3. Konfigurasi environment variables

Buat file `.env.local` berdasarkan template:

```bash
cp .env.local.example .env.local
```

Isi variabel berikut:

```env
# Vercel Blob Storage token
BLOB_READ_WRITE_TOKEN=your_vercel_blob_token

# Password login (plain text atau hash sesuai implementasi)
APP_PASSWORD=your_password
```

### 4. Jalankan development server

```bash
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000) di browser.

---

## 📁 Struktur Proyek

```
saberindo-wms/
├── app/
│   ├── (dashboard)/
│   │   ├── dashboard/
│   │   │   ├── barang/        # Master Barang
│   │   │   ├── po/            # Purchase Order
│   │   │   ├── transaksi/     # Barang Masuk/Keluar
│   │   │   ├── stok/          # Stok Monitor
│   │   │   ├── lokasi/        # Lokasi Gudang
│   │   │   ├── laporan/       # Laporan & Export
│   │   │   └── page.tsx       # Dashboard utama
│   │   └── layout.tsx
│   ├── api/
│   │   ├── auth/              # Login / logout
│   │   ├── barang/            # CRUD barang
│   │   ├── po/                # Purchase Order + PDF parser
│   │   ├── transaksi/         # Transaksi masuk/keluar
│   │   ├── lokasi/            # Lokasi gudang
│   │   ├── laporan/           # Laporan & filter
│   │   └── download/          # Download file Excel
│   └── page.tsx               # Login page
├── components/
│   ├── Sidebar.tsx            # Navigasi (responsive, collapsible)
│   └── Topbar.tsx             # Header + notifikasi stok
├── lib/
│   ├── excel.ts               # Semua operasi baca/tulis Excel (Vercel Blob)
│   ├── po-parser.ts           # PDF parser untuk PO (TypeScript/Node.js)
│   ├── types.ts               # Type definitions
│   └── auth.ts                # Auth helper
└── middleware.ts              # Route protection
```

---

## 📄 Fitur PDF Parser (Purchase Order)

Upload file PDF Purchase Order Saberindo, sistem akan otomatis mengekstrak:

- **PO Number** — nomor dokumen PO
- **PO Date** — tanggal PO
- **Supplier** — nama supplier
- **Item List** — kode barang, nama barang, dan qty ordered

Parser ditulis sepenuhnya dalam TypeScript (menggunakan `pdf-parse`) sehingga kompatibel dengan Vercel Serverless Functions tanpa membutuhkan Python runtime.

---

## 🌐 Deploy ke Vercel

1. Push repository ke GitHub
2. Import project di [vercel.com](https://vercel.com/)
3. Tambahkan environment variables di dashboard Vercel:
   - `BLOB_READ_WRITE_TOKEN`
   - `APP_PASSWORD`
4. Deploy otomatis setiap push ke branch `main`

---

## 📋 Kategori Barang yang Didukung

`APAR` · `Sprinkler` · `Hydrant` · `Fire Alarm` · `Valve & Fitting` · `Pipa` · `Selang` · `Nozzle` · `Foam & Chemical` · `Aksesori` · `Lainnya`

---

## ⚠️ Catatan Penting

- Data tersimpan dalam file **Excel tunggal** di Vercel Blob — cocok untuk skala penggunaan internal tim kecil
- Tidak menggunakan database relasional (tidak perlu setup DB)
- Session auth berbasis cookie sederhana, tidak menggunakan OAuth/JWT eksternal

---

## 📝 Lisensi

Private — Internal PT Saberindo Pacific. Tidak untuk didistribusikan.