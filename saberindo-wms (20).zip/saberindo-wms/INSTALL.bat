@echo off
title Saberindo WMS - Auto Installer
color 0B

echo.
echo  ==============================================
echo    SABERINDO WMS - AUTO INSTALLER
echo    Warehouse Management System
echo    PT Saberindo Pacific
echo  ==============================================
echo.

set "PROJECT_DIR=%~dp0"
set "ERRORS=0"

echo  Lokasi project: %PROJECT_DIR%
echo.
echo  Mengecek kebutuhan sistem...
echo  ----------------------------------------------
echo.

:: ============================================
:: 1. Cek Node.js
:: ============================================
echo  [1/5] Mengecek Node.js...
where node >nul 2>&1
if %ERRORLEVEL%==0 (
    for /f "tokens=1" %%v in ('node --version') do echo        OK - Node.js %%v terinstall
) else (
    echo        BELUM TERINSTALL
    echo.
    echo        Node.js belum ada di PC ini.
    echo        Download dari: https://nodejs.org/en/download
    echo        Pilih "Windows Installer" lalu install.
    echo        Setelah install, jalankan script ini lagi.
    echo.
    set /p OPEN_NODE="  Buka halaman download Node.js? (y/n): "
    if /i "%OPEN_NODE%"=="y" start https://nodejs.org/en/download
    set /a ERRORS+=1
    goto :check_python
)

:: ============================================
:: 2. Cek Python
:: ============================================
:check_python
echo.
echo  [2/5] Mengecek Python...

set "PYTHON_CMD="

python --version >nul 2>&1
if %ERRORLEVEL%==0 (
    for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo        OK - %%v terinstall
    set "PYTHON_CMD=python"
    goto :install_pip
)

python3 --version >nul 2>&1
if %ERRORLEVEL%==0 (
    for /f "tokens=*" %%v in ('python3 --version 2^>^&1') do echo        OK - %%v terinstall
    set "PYTHON_CMD=python3"
    goto :install_pip
)

echo        BELUM TERINSTALL
echo.
echo        Python belum ada di PC ini.
echo        Download dari: https://www.python.org/downloads/
echo        PENTING: Centang "Add Python to PATH" saat install
echo        Setelah install, jalankan script ini lagi.
echo.
set /p OPEN_PY="  Buka halaman download Python? (y/n): "
if /i "%OPEN_PY%"=="y" start https://www.python.org/downloads/
set /a ERRORS+=1
goto :check_npm

:: ============================================
:: 3. Install pdfplumber
:: ============================================
:install_pip
echo.
echo  [3/5] Mengecek Python packages...

%PYTHON_CMD% -c "import pdfplumber" >nul 2>&1
if %ERRORLEVEL%==0 (
    echo        OK - pdfplumber sudah terinstall
) else (
    echo        Installing pdfplumber...
    %PYTHON_CMD% -m pip install pdfplumber --quiet
    if %ERRORLEVEL%==0 (
        echo        OK - pdfplumber berhasil diinstall
    ) else (
        echo        GAGAL - Coba jalankan manual: pip install pdfplumber
        set /a ERRORS+=1
    )
)

:: ============================================
:: 4. Install npm packages
:: ============================================
:check_npm
echo.
echo  [4/5] Mengecek Node.js packages...

where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo        SKIP - Node.js belum terinstall
    goto :check_env
)

cd /d "%PROJECT_DIR%"

if exist "node_modules\next" (
    echo        OK - node_modules sudah ada
) else (
    echo        Installing npm packages... harap tunggu...
    call npm install --loglevel=error
    if %ERRORLEVEL%==0 (
        echo        OK - npm packages berhasil diinstall
    ) else (
        echo        GAGAL - Coba jalankan manual: npm install
        set /a ERRORS+=1
    )
)

:: ============================================
:: 5. Setup .env.local
:: ============================================
:check_env
echo.
echo  [5/5] Mengecek konfigurasi...

cd /d "%PROJECT_DIR%"

if exist ".env.local" (
    echo        OK - .env.local sudah ada
) else (
    echo ADMIN_PASSWORD=saberindo2024> ".env.local"
    echo        OK - .env.local dibuat, password: saberindo2024
)

if not exist "data" mkdir data

:: ============================================
:: Buat shortcut di Desktop
:: ============================================
echo.
echo  Membuat shortcut di Desktop...

set "DESKTOP=%USERPROFILE%\Desktop"

echo [InternetShortcut]> "%DESKTOP%\Saberindo WMS.url"
echo URL=http://localhost:3000>> "%DESKTOP%\Saberindo WMS.url"
echo IconFile=C:\Windows\System32\shell32.dll>> "%DESKTOP%\Saberindo WMS.url"
echo IconIndex=13>> "%DESKTOP%\Saberindo WMS.url"
echo        OK - Shortcut "Saberindo WMS" dibuat di Desktop

:: ============================================
:: Summary
:: ============================================
echo.
echo  ==============================================
echo.

if %ERRORS%==0 (
    color 0A
    echo  INSTALASI BERHASIL
    echo.
    echo  Cara menjalankan WMS:
    echo.
    echo    1. Klik 2x "Start WMS Server.bat" di folder shortcuts
    echo    2. Klik 2x "Saberindo WMS" di Desktop
    echo    3. Login password: saberindo2024
    echo.
    for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
        echo  Akses dari PC lain: http://%%a:3000
        goto :done_ip
    )
    :done_ip
) else (
    color 0C
    echo  INSTALASI BELUM LENGKAP
    echo.
    echo  Ada %ERRORS% komponen yang belum terinstall.
    echo  Install dulu, lalu jalankan script ini lagi.
)

echo.
echo  ==============================================
echo.

set /p START_NOW="  Mau langsung jalankan WMS server? (y/n): "
if /i "%START_NOW%"=="y" (
    echo.
    echo  Starting WMS server...
    cd /d "%PROJECT_DIR%"
    timeout /t 3 /nobreak >nul & start http://localhost:3000
    call npm run dev
)

pause
