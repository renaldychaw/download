#!/usr/bin/env python3
"""
PT Saberindo Pacific — PO PDF Parser (pdfplumber)
Uses dynamic column detection from table headers for accurate extraction.
Output: JSON to stdout
"""
import sys
import json
import re
import pdfplumber
from collections import defaultdict

MONTHS = {
    'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
    'mei': '05', 'may': '05', 'jun': '06', 'jul': '07',
    'agt': '08', 'aug': '08', 'sep': '09', 'okt': '10',
    'oct': '10', 'nov': '11', 'des': '12', 'dec': '12',
}


def parse_date(s):
    if not s:
        return ''
    m = re.match(r'(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})', s.strip())
    if m:
        mon = MONTHS.get(m.group(2).lower()[:3], '01')
        return f"{m.group(3)}-{mon}-{m.group(1).zfill(2)}"
    return s.strip()


def find_table_columns(words):
    """Dynamically detect column boundaries from table header positions."""
    for w in words:
        txt = w['text'].strip()
        if txt in ('No.', 'No'):
            same_row = [ww for ww in words if abs(ww['top'] - w['top']) < 4]
            texts = {ww['text'].strip(): ww for ww in same_row}

            has_item = 'Item' in texts or 'Part Number' in texts or 'Part' in texts
            has_qty = 'Qty' in texts

            if has_item and has_qty:
                no_w = w
                item_w = texts.get('Item') or texts.get('Part Number') or texts.get('Part')
                desc_w = texts.get('Description')
                qty_w = texts.get('Qty')
                price_w = texts.get('Unit Price') or texts.get('Ext Price')

                item_left = no_w['x1']
                desc_left = item_w['x1'] if item_w else item_left + 50
                qty_left = desc_w['x1'] if desc_w else qty_w['x0'] - 10
                qty_right = (qty_w['x1'] + price_w['x0']) / 2 if price_w else qty_w['x1'] + 10

                return {
                    'header_y': w['top'],
                    'item_left': item_left,
                    'desc_left': desc_left,
                    'qty_left': qty_left,
                    'qty_right': qty_right,
                }
    return None


def extract_metadata(pdf):
    """Extract PO Number, Date, Supplier, Description."""
    po_number = ''
    po_date = ''
    supplier = ''
    desc_lines = []

    for page in pdf.pages:
        text = page.extract_text() or ''
        lines = [l.strip() for l in text.split('\n') if l.strip()]

        pending = None
        for i, line in enumerate(lines):
            # PO Number
            if line in ('PO Number', 'PO'):
                pending = 'poNumber'
                continue
            if pending == 'poNumber' and line.startswith(':'):
                val = line.lstrip(': ').strip()
                if val and not po_number:
                    po_number = val.split()[0]
                pending = None
                continue
            if 'PO Number' in line and ':' in line:
                po_number = line.split(':', 1)[1].strip().split()[0]
                continue
            po_match = re.match(r'^PO\s*:\s*(\S+)', line)
            if po_match and not po_number:
                po_number = po_match.group(1)
                continue

            # PO Date
            if line in ('PO Date', 'Date'):
                pending = 'poDate'
                continue
            if pending == 'poDate' and line.startswith(':'):
                po_date = parse_date(line.lstrip(': '))
                pending = None
                continue
            if 'PO Date' in line and ':' in line:
                po_date = parse_date(line.split(':', 1)[1].strip())
                continue
            date_match = re.match(r'^Date\s*:\s*(.+)', line)
            if date_match and not po_date:
                po_date = parse_date(date_match.group(1).strip())
                continue

            # Supplier — multiple strategies
            if line.startswith('To') and ':' in line:
                val = line.split(':', 1)[1].strip()
                if len(val) > 2 and not supplier:
                    if not re.match(r'^(confirm|place|order|www)', val, re.I):
                        supplier = val
                continue

            if (line == 'To' or line == 'To :') and not supplier:
                for j in range(i + 1, min(i + 10, len(lines))):
                    nxt = lines[j].strip()
                    if nxt.startswith(':'):
                        val = nxt.lstrip(': ').strip()
                        if len(val) > 2 and not val[0].isdigit() and not re.match(r'^(Ms\.|Bp\.|Mr\.|Ibu|Bpk)', val):
                            supplier = val
                            break
                    elif 'We confirm' in nxt:
                        break
                continue

            # Description
            if line.startswith('-') and any(kw in line for kw in ['Project', 'ATG', 'PR/', 'SO#', 'STOK', 'Stok']):
                desc_lines.append(line)

            if pending and not line.startswith(':'):
                pending = None

    # Fallback supplier from header block
    if not supplier:
        for page in pdf.pages[:1]:
            text = page.extract_text() or ''
            lines = [l.strip() for l in text.split('\n') if l.strip()]
            in_header = False
            header_vals = []
            for line in lines:
                if line.startswith('To') or line == 'To':
                    in_header = True
                    continue
                if in_header:
                    if line in ('Att', 'CC', 'Fax', 'Tel'):
                        continue
                    if line.startswith(':'):
                        val = line.lstrip(': ').strip()
                        if val:
                            header_vals.append(val)
                        continue
                    if 'We confirm' in line:
                        in_header = False
                        for v in reversed(header_vals):
                            if not v[0].isdigit() and not re.match(r'^(Ms\.|Bp\.|Mr\.|Ibu|Bpk)', v):
                                supplier = v
                                break
                        break

    # Clean PO number
    if po_number:
        po_number = po_number.replace('Purchase Order', '').replace('PURCHASE ORDER', '').strip().split()[0]

    return po_number, po_date, supplier, ' '.join(desc_lines)[:500]


def extract_items(pdf):
    """Extract items using dynamic column detection per page."""
    all_items = []

    for page in pdf.pages:
        words = page.extract_words(keep_blank_chars=True, x_tolerance=3, y_tolerance=3)

        cols = find_table_columns(words)
        if not cols:
            continue

        header_y = cols['header_y']
        item_left = cols['item_left']
        desc_left = cols['desc_left']
        qty_left = cols['qty_left']
        qty_right = cols['qty_right']

        data_words = [w for w in words if w['top'] > header_y + 3]
        rows = defaultdict(list)
        for w in data_words:
            row_key = round(w['top'] * 2) / 2
            rows[row_key].append(w)

        for y in sorted(rows.keys()):
            rw = sorted(rows[y], key=lambda w: w['x0'])

            no_words = [w['text'] for w in rw if w['x0'] < item_left]
            item_words = [w['text'] for w in rw if item_left <= w['x0'] < desc_left]
            desc_words = [w['text'] for w in rw if desc_left <= w['x0'] < qty_left]
            qty_words = [w['text'] for w in rw if qty_left <= w['x0'] < qty_right]

            no_val = ' '.join(no_words).strip()
            item_val = ' '.join(item_words).strip()
            desc_val = ' '.join(desc_words).strip()
            qty_val = ' '.join(qty_words).strip()

            # Skip footer rows
            full_text = ' '.join(w['text'] for w in rw).lower()
            if any(kw in full_text for kw in [
                'sub total', 'subtotal', 'other tax', 'vat', 'ppn',
                'bank charge', 'say', 'requested by', 'authorized by',
                'catatan', 'freight',
            ]):
                break

            clean_no = no_val.replace(' ', '')
            is_item_row = clean_no.isdigit() and len(clean_no) <= 3

            if is_item_row and item_val:
                qty = 0
                try:
                    clean_qty = qty_val.strip()
                    if re.match(r'^\d{1,3}(\.\d{3})*$', clean_qty):
                        qty = int(clean_qty.replace('.', ''))
                    else:
                        qty = int(re.sub(r'[.,].*', '', clean_qty))
                except (ValueError, AttributeError):
                    qty = 0

                if qty > 0:
                    all_items.append({
                        'itemCode': item_val,
                        'namaBarang': desc_val,
                        'qtyOrdered': qty,
                        'qtyReceived': 0,
                    })
            elif item_val and not is_item_row and all_items:
                if not any(kw in item_val.lower() for kw in ['subtotal', 'sub total', 'ppn', 'vat', 'tax', 'bank', 'say']):
                    all_items[-1]['itemCode'] += item_val
            elif desc_val and not is_item_row and all_items:
                if not any(kw in desc_val.lower() for kw in ['subtotal', 'sub total', 'ppn', 'vat', 'tax']):
                    all_items[-1]['namaBarang'] += ' ' + desc_val

    return all_items


def deduplicate_items(items):
    """Merge duplicate itemCode entries — sum qtyOrdered."""
    seen = {}
    for item in items:
        key = item['itemCode'].strip()
        if key in seen:
            seen[key]['qtyOrdered'] += item['qtyOrdered']
            seen[key]['qtyReceived'] = (seen[key].get('qtyReceived') or 0) + (item.get('qtyReceived') or 0)
        else:
            seen[key] = dict(item, itemCode=key)
    return list(seen.values())


def parse_po_file(filepath):
    """Parse a single PO PDF file."""
    try:
        with pdfplumber.open(filepath) as pdf:
            po_number, po_date, supplier, description = extract_metadata(pdf)
            items = deduplicate_items(extract_items(pdf))

            # Fallback supplier: use word coordinates
            if not supplier and pdf.pages:
                words = pdf.pages[0].extract_words(keep_blank_chars=True, x_tolerance=3, y_tolerance=3)
                to_word = None
                for w in words:
                    if w['text'].strip() == 'To':
                        to_word = w
                        break
                if to_word:
                    candidates = [w for w in words if abs(w['top'] - to_word['top']) < 4 and w['x0'] > to_word['x1'] + 10]
                    if candidates:
                        val = ' '.join(c['text'] for c in sorted(candidates, key=lambda c: c['x0'])).strip().lstrip(': ').strip()
                        if len(val) > 2:
                            supplier = val

            return {
                'poNumber': po_number,
                'poDate': po_date,
                'supplier': supplier,
                'description': description,
                'items': items,
                'filename': filepath.split('/')[-1].split('\\')[-1],
            }
    except Exception as e:
        return {
            'error': str(e),
            'filename': filepath.split('/')[-1].split('\\')[-1],
        }


def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'Usage: parse-po.py <pdf_path> [...]'}))
        sys.exit(1)

    results = []
    for filepath in sys.argv[1:]:
        result = parse_po_file(filepath)
        if 'error' not in result and result.get('items'):
            results.append(result)

    print(json.dumps(results, ensure_ascii=False))


if __name__ == '__main__':
    main()
