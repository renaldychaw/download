// ============================================
// PT Saberindo Pacific — Excel Data Layer
// Simple local file storage
// ============================================
import ExcelJS from "exceljs";
import path from "path";
import fs from "fs";
import {
  Barang, BarangFormData, DashboardStats,
  Transaksi, TransaksiFormData,
  Lokasi, LokasiFormData,
  PurchaseOrder, POFormData, POStatus,
} from "./types";

const EXCEL_PATH = path.join(process.cwd(), "data", "warehouse.xlsx");

const SHEET_BARANG = "Master Barang";
const SHEET_TRANSAKSI = "Transaksi";
const SHEET_LOKASI = "Lokasi";
const SHEET_PO = "Purchase Orders";

const HEADERS_PO = [
  { key: "id", header: "ID", width: 20 },
  { key: "poNumber", header: "PO Number", width: 18 },
  { key: "poDate", header: "PO Date", width: 14 },
  { key: "supplier", header: "Supplier", width: 30 },
  { key: "description", header: "Description", width: 40 },
  { key: "status", header: "Status", width: 12 },
  { key: "items", header: "Items (JSON)", width: 60 },
  { key: "createdAt", header: "Created At", width: 22 },
  { key: "updatedAt", header: "Updated At", width: 22 },
];

const HEADERS_BARANG = [
  { key: "id", header: "ID", width: 20 },
  { key: "kode", header: "Kode", width: 14 },
  { key: "nama", header: "Nama Barang", width: 35 },
  { key: "kategori", header: "Kategori", width: 18 },
  { key: "satuan", header: "Satuan", width: 10 },
  { key: "stok", header: "Stok", width: 10 },
  { key: "stokMinimum", header: "Stok Minimum", width: 14 },
  { key: "stokAwal", header: "Stok Awal", width: 15 },
  { key: "lokasi", header: "Lokasi", width: 22 },
  { key: "keterangan", header: "Keterangan", width: 30 },
  { key: "createdAt", header: "Created At", width: 22 },
  { key: "updatedAt", header: "Updated At", width: 22 },
];

const HEADERS_TRANSAKSI = [
  { key: "id", header: "ID", width: 22 },
  { key: "tanggal", header: "Tanggal", width: 22 },
  { key: "tipe", header: "Tipe", width: 10 },
  { key: "barangId", header: "Barang ID", width: 20 },
  { key: "kodeBarang", header: "Kode Barang", width: 14 },
  { key: "namaBarang", header: "Nama Barang", width: 35 },
  { key: "jumlah", header: "Jumlah", width: 10 },
  { key: "satuanBarang", header: "Satuan", width: 10 },
  { key: "stokSebelum", header: "Stok Sebelum", width: 14 },
  { key: "stokSesudah", header: "Stok Sesudah", width: 14 },
  { key: "keterangan", header: "Keterangan", width: 30 },
  { key: "createdAt", header: "Created At", width: 22 },
];

const HEADERS_LOKASI = [
  { key: "id", header: "ID", width: 20 },
  { key: "kode", header: "Kode", width: 12 },
  { key: "nama", header: "Nama Lokasi", width: 30 },
  { key: "zona", header: "Zona", width: 18 },
  { key: "kapasitas", header: "Kapasitas", width: 12 },
  { key: "keterangan", header: "Keterangan", width: 30 },
  { key: "createdAt", header: "Created At", width: 22 },
  { key: "updatedAt", header: "Updated At", width: 22 },
];

// ============================================
// Helpers
// ============================================
function styleHeaderRow(
  sheet: ExcelJS.Worksheet,
  headers: { key: string; header: string; width: number }[]
) {
  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
  headerRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF102A43" } };
  headerRow.alignment = { vertical: "middle", horizontal: "center" };
  headerRow.height = 28;
  headerRow.commit();
  sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: headers.length } };
}

async function ensureWorkbook(): Promise<ExcelJS.Workbook> {
  const dir = path.dirname(EXCEL_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  const workbook = new ExcelJS.Workbook();
  if (fs.existsSync(EXCEL_PATH)) await workbook.xlsx.readFile(EXCEL_PATH);

  let needsSave = false;

  if (!workbook.getWorksheet(SHEET_BARANG)) {
    const s = workbook.addWorksheet(SHEET_BARANG);
    s.columns = HEADERS_BARANG;
    styleHeaderRow(s, HEADERS_BARANG);
    needsSave = true;
  }
  if (!workbook.getWorksheet(SHEET_TRANSAKSI)) {
    const s = workbook.addWorksheet(SHEET_TRANSAKSI);
    s.columns = HEADERS_TRANSAKSI;
    styleHeaderRow(s, HEADERS_TRANSAKSI);
    needsSave = true;
  }
  if (!workbook.getWorksheet(SHEET_LOKASI)) {
    const s = workbook.addWorksheet(SHEET_LOKASI);
    s.columns = HEADERS_LOKASI;
    styleHeaderRow(s, HEADERS_LOKASI);
    needsSave = true;
  }
  if (!workbook.getWorksheet(SHEET_PO)) {
    const s = workbook.addWorksheet(SHEET_PO);
    s.columns = HEADERS_PO;
    styleHeaderRow(s, HEADERS_PO);
    needsSave = true;
  }

  if (needsSave) await workbook.xlsx.writeFile(EXCEL_PATH);
  return workbook;
}

function generateId(prefix: string): string {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).substring(2, 7);
  return `${prefix}-${ts}${rand}`.toUpperCase();
}

function getNow(): string {
  return new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta", dateStyle: "short", timeStyle: "medium",
  });
}

// ============================================
// Row parsers
// ============================================
function rowToBarang(row: ExcelJS.Row): Barang {
  return {
    id: String(row.getCell(1).value || ""),
    kode: String(row.getCell(2).value || ""),
    nama: String(row.getCell(3).value || ""),
    kategori: String(row.getCell(4).value || ""),
    satuan: String(row.getCell(5).value || ""),
    stok: Number(row.getCell(6).value) || 0,
    stokMinimum: Number(row.getCell(7).value) || 0,
    stokAwal: Number(row.getCell(8).value) || 0,
    lokasi: String(row.getCell(9).value || ""),
    keterangan: String(row.getCell(10).value || ""),
    createdAt: String(row.getCell(11).value || ""),
    updatedAt: String(row.getCell(12).value || ""),
  };
}

function rowToTransaksi(row: ExcelJS.Row): Transaksi {
  return {
    id: String(row.getCell(1).value || ""),
    tanggal: String(row.getCell(2).value || ""),
    tipe: String(row.getCell(3).value || "Masuk") as "Masuk" | "Keluar",
    barangId: String(row.getCell(4).value || ""),
    kodeBarang: String(row.getCell(5).value || ""),
    namaBarang: String(row.getCell(6).value || ""),
    jumlah: Number(row.getCell(7).value) || 0,
    satuanBarang: String(row.getCell(8).value || ""),
    stokSebelum: Number(row.getCell(9).value) || 0,
    stokSesudah: Number(row.getCell(10).value) || 0,
    keterangan: String(row.getCell(11).value || ""),
    createdAt: String(row.getCell(12).value || ""),
  };
}

function rowToLokasi(row: ExcelJS.Row): Lokasi {
  return {
    id: String(row.getCell(1).value || ""),
    kode: String(row.getCell(2).value || ""),
    nama: String(row.getCell(3).value || ""),
    zona: String(row.getCell(4).value || ""),
    kapasitas: Number(row.getCell(5).value) || 0,
    terpakai: 0,
    keterangan: String(row.getCell(6).value || ""),
    createdAt: String(row.getCell(7).value || ""),
    updatedAt: String(row.getCell(8).value || ""),
  };
}

// ============================================
// BARANG CRUD
// ============================================
export async function getAllBarang(): Promise<Barang[]> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_BARANG)!;
  const items: Barang[] = [];
  sheet.eachRow((row, n) => { if (n === 1) return; const b = rowToBarang(row); if (b.id) items.push(b); });
  return items;
}

export async function getBarangById(id: string): Promise<Barang | null> {
  const all = await getAllBarang();
  return all.find((b) => b.id === id) || null;
}

export async function createBarang(data: BarangFormData): Promise<Barang> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_BARANG)!;
  const id = generateId("BRG");
  const now = getNow();
  const r = sheet.addRow([id, data.kode, data.nama, data.kategori, data.satuan, data.stok, data.stokMinimum, data.stokAwal ?? 0, data.lokasi, data.keterangan, now, now]);
  r.alignment = { vertical: "middle" }; r.commit();
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return { id, ...data, stokAwal: data.stokAwal ?? 0, createdAt: now, updatedAt: now };
}

export async function updateBarang(id: string, data: BarangFormData): Promise<Barang | null> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_BARANG)!;
  let targetRow: ExcelJS.Row | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === id) targetRow = row; });
  if (!targetRow) return null;
  const now = getNow();
  const r = targetRow as ExcelJS.Row;
  const createdAt = String(r.getCell(11).value || now);
  r.getCell(2).value = data.kode; r.getCell(3).value = data.nama; r.getCell(4).value = data.kategori;
  r.getCell(5).value = data.satuan; r.getCell(6).value = data.stok; r.getCell(7).value = data.stokMinimum;
  // col 8 = stokAwal — tidak diupdate, hanya diisi saat create
  r.getCell(9).value = data.lokasi; r.getCell(10).value = data.keterangan; r.getCell(12).value = now;
  r.commit();
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return { id, ...data, createdAt, updatedAt: now };
}

export async function deleteBarang(id: string): Promise<boolean> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_BARANG)!;
  let targetRowNumber: number | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === id) targetRowNumber = n; });
  if (targetRowNumber === null) return false;
  sheet.spliceRows(targetRowNumber, 1);
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return true;
}

// ============================================
// TRANSAKSI CRUD
// ============================================
export async function getAllTransaksi(): Promise<Transaksi[]> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_TRANSAKSI)!;
  const items: Transaksi[] = [];
  sheet.eachRow((row, n) => { if (n === 1) return; const t = rowToTransaksi(row); if (t.id) items.push(t); });
  return items.reverse();
}

export async function createTransaksi(data: TransaksiFormData): Promise<{ transaksi: Transaksi; barang: Barang }> {
  const workbook = await ensureWorkbook();
  const barangSheet = workbook.getWorksheet(SHEET_BARANG)!;
  let barangRow: ExcelJS.Row | null = null;
  barangSheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === data.barangId) barangRow = row; });
  if (!barangRow) throw new Error("Barang tidak ditemukan");

  const r = barangRow as ExcelJS.Row;
  const kodeBarang = String(r.getCell(2).value || "");
  const namaBarang = String(r.getCell(3).value || "");
  const satuanBarang = String(r.getCell(5).value || "");
  const stokSebelum = Number(r.getCell(6).value) || 0;

  let stokSesudah: number;
  if (data.tipe === "Masuk") {
    stokSesudah = stokSebelum + data.jumlah;
  } else {
    stokSesudah = stokSebelum - data.jumlah;
    if (stokSesudah < 0) throw new Error(`Stok tidak cukup! Saat ini: ${stokSebelum} ${satuanBarang}, diminta: ${data.jumlah} ${satuanBarang}`);
  }

  const now = getNow();
  r.getCell(6).value = stokSesudah; r.getCell(11).value = now; r.commit();

  const trxSheet = workbook.getWorksheet(SHEET_TRANSAKSI)!;
  const id = generateId("TRX");
  const newRow = trxSheet.addRow([id, now, data.tipe, data.barangId, kodeBarang, namaBarang, data.jumlah, satuanBarang, stokSebelum, stokSesudah, data.keterangan, now]);
  newRow.getCell(3).font = { bold: true, color: { argb: data.tipe === "Masuk" ? "FF10B981" : "FFEF4444" } };
  newRow.alignment = { vertical: "middle" }; newRow.commit();

  await workbook.xlsx.writeFile(EXCEL_PATH);
  const transaksi: Transaksi = { id, tanggal: now, tipe: data.tipe, barangId: data.barangId, kodeBarang, namaBarang, jumlah: data.jumlah, satuanBarang, stokSebelum, stokSesudah, keterangan: data.keterangan, createdAt: now };
  const updatedBarang = await getBarangById(data.barangId);
  return { transaksi, barang: updatedBarang! };
}

// ============================================
// LOKASI CRUD
// ============================================
export async function getAllLokasi(): Promise<Lokasi[]> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_LOKASI)!;
  const items: Lokasi[] = [];
  sheet.eachRow((row, n) => { if (n === 1) return; const l = rowToLokasi(row); if (l.id) items.push(l); });

  // Count barang per lokasi
  const barangSheet = workbook.getWorksheet(SHEET_BARANG)!;
  const lokasiCount: Record<string, number> = {};
  barangSheet.eachRow((row, n) => {
    if (n === 1) return;
    const loc = String(row.getCell(8).value || "");
    if (loc) {
      items.forEach((l) => {
        if (loc.includes(l.kode)) {
          lokasiCount[l.id] = (lokasiCount[l.id] || 0) + 1;
        }
      });
    }
  });

  return items.map((l) => ({ ...l, terpakai: lokasiCount[l.id] || 0 }));
}

export async function createLokasi(data: LokasiFormData): Promise<Lokasi> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_LOKASI)!;
  const id = generateId("LOK");
  const now = getNow();
  const r = sheet.addRow([id, data.kode, data.nama, data.zona, data.kapasitas, data.keterangan, now, now]);
  r.alignment = { vertical: "middle" }; r.commit();
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return { id, kode: data.kode, nama: data.nama, zona: data.zona, kapasitas: data.kapasitas, terpakai: 0, keterangan: data.keterangan, createdAt: now, updatedAt: now };
}

export async function updateLokasi(id: string, data: LokasiFormData): Promise<Lokasi | null> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_LOKASI)!;
  let targetRow: ExcelJS.Row | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === id) targetRow = row; });
  if (!targetRow) return null;
  const now = getNow();
  const r = targetRow as ExcelJS.Row;
  const createdAt = String(r.getCell(7).value || now);
  r.getCell(2).value = data.kode; r.getCell(3).value = data.nama; r.getCell(4).value = data.zona;
  r.getCell(5).value = data.kapasitas; r.getCell(6).value = data.keterangan; r.getCell(8).value = now;
  r.commit();
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return { id, kode: data.kode, nama: data.nama, zona: data.zona, kapasitas: data.kapasitas, terpakai: 0, keterangan: data.keterangan, createdAt, updatedAt: now };
}

export async function deleteLokasi(id: string): Promise<boolean> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_LOKASI)!;
  let targetRowNumber: number | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === id) targetRowNumber = n; });
  if (targetRowNumber === null) return false;
  sheet.spliceRows(targetRowNumber, 1);
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return true;
}

// ============================================
// Dashboard Statistics
// ============================================
export async function getDashboardStats(): Promise<DashboardStats> {
  const allBarang = await getAllBarang();
  const allTransaksi = await getAllTransaksi();

  const kategoriCount: Record<string, number> = {};
  let totalStok = 0, stokRendah = 0, stokKosong = 0;

  allBarang.forEach((item) => {
    totalStok += item.stok;
    if (item.stok === 0) stokKosong++;
    else if (item.stok <= item.stokMinimum) stokRendah++;
    if (item.kategori) kategoriCount[item.kategori] = (kategoriCount[item.kategori] || 0) + 1;
  });

  const todayStr = new Date().toLocaleDateString("id-ID", { timeZone: "Asia/Jakarta" });
  let totalMasukHariIni = 0, totalKeluarHariIni = 0;
  allTransaksi.forEach((trx) => {
    if (trx.tanggal.includes(todayStr)) {
      if (trx.tipe === "Masuk") totalMasukHariIni++; else totalKeluarHariIni++;
    }
  });

  return { totalBarang: allBarang.length, totalStok, stokRendah, stokKosong, kategoriCount, totalTransaksiHariIni: totalMasukHariIni + totalKeluarHariIni, totalMasukHariIni, totalKeluarHariIni };
}

export function getExcelPath(): string { return EXCEL_PATH; }

// ============================================
// PO: Helpers
// ============================================

/** Merge duplicate itemCode entries — sum qtyOrdered, accumulate qtyReceived */
function deduplicatePOItems(items: PurchaseOrder["items"]): PurchaseOrder["items"] {
  const map = new Map<string, PurchaseOrder["items"][number]>();
  for (const item of items) {
    const key = item.itemCode.trim();
    if (map.has(key)) {
      const existing = map.get(key)!;
      existing.qtyOrdered += item.qtyOrdered;
      existing.qtyReceived = (existing.qtyReceived || 0) + (item.qtyReceived || 0);
    } else {
      map.set(key, { ...item, itemCode: key });
    }
  }
  return Array.from(map.values());
}

// ============================================
// PO: Row parser
// ============================================
function rowToPO(row: ExcelJS.Row): PurchaseOrder {
  let items: PurchaseOrder["items"] = [];
  try {
    const raw = String(row.getCell(7).value || "[]");
    items = JSON.parse(raw);
  } catch { items = []; }

  return {
    id: String(row.getCell(1).value || ""),
    poNumber: String(row.getCell(2).value || ""),
    poDate: String(row.getCell(3).value || ""),
    supplier: String(row.getCell(4).value || ""),
    description: String(row.getCell(5).value || ""),
    status: String(row.getCell(6).value || "Pending") as POStatus,
    items: deduplicatePOItems(items),
    createdAt: String(row.getCell(8).value || ""),
    updatedAt: String(row.getCell(9).value || ""),
  };
}

function calcPOStatus(items: PurchaseOrder["items"]): POStatus {
  if (items.length === 0) return "Pending";
  const allReceived = items.every((i) => i.qtyReceived >= i.qtyOrdered);
  const someReceived = items.some((i) => i.qtyReceived > 0);
  if (allReceived) return "Complete";
  if (someReceived) return "Partial";
  return "Pending";
}

// ============================================
// PO: Get All
// ============================================
export async function getAllPO(): Promise<PurchaseOrder[]> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  const items: PurchaseOrder[] = [];
  sheet.eachRow((row, n) => { if (n === 1) return; const po = rowToPO(row); if (po.id) items.push(po); });
  return items;
}

// ============================================
// PO: Create
// ============================================
export async function createPO(data: POFormData): Promise<PurchaseOrder> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  const id = generateId("PO");
  const now = getNow();
  const dedupedItems = deduplicatePOItems(data.items);
  const status = calcPOStatus(dedupedItems);

  const r = sheet.addRow([
    id, data.poNumber, data.poDate, data.supplier, data.description,
    status, JSON.stringify(dedupedItems), now, now,
  ]);
  r.alignment = { vertical: "middle" }; r.commit();
  await workbook.xlsx.writeFile(EXCEL_PATH);

  return { id, poNumber: data.poNumber, poDate: data.poDate, supplier: data.supplier, description: data.description, status, items: dedupedItems, createdAt: now, updatedAt: now };
}

// ============================================
// PO: Create Batch — saves multiple POs in one workbook open/write cycle
// This avoids the Vercel Lambda race condition where sequential requests
// may hit different instances and overwrite each other's data.
export async function createPOBatch(dataList: POFormData[]): Promise<PurchaseOrder[]> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  const now = getNow();
  const results: PurchaseOrder[] = [];

  for (const data of dataList) {
    const id = generateId("PO");
    const dedupedItems = deduplicatePOItems(data.items);
    const status = calcPOStatus(dedupedItems);

    const r = sheet.addRow([
      id, data.poNumber, data.poDate, data.supplier, data.description,
      status, JSON.stringify(dedupedItems), now, now,
    ]);
    r.alignment = { vertical: "middle" }; r.commit();

    results.push({
      id, poNumber: data.poNumber, poDate: data.poDate, supplier: data.supplier,
      description: data.description, status, items: dedupedItems,
      createdAt: now, updatedAt: now,
    });
  }

  // Single write for all POs — atomic
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return results;
}

// PO: Update (full or items only)
// ============================================
export async function updatePO(id: string, data: Partial<POFormData>): Promise<PurchaseOrder | null> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  let targetRow: ExcelJS.Row | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === id) targetRow = row; });
  if (!targetRow) return null;

  const r = targetRow as ExcelJS.Row;
  const now = getNow();

  if (data.poNumber !== undefined) r.getCell(2).value = data.poNumber;
  if (data.poDate !== undefined) r.getCell(3).value = data.poDate;
  if (data.supplier !== undefined) r.getCell(4).value = data.supplier;
  if (data.description !== undefined) r.getCell(5).value = data.description;
  if (data.items !== undefined) {
    r.getCell(7).value = JSON.stringify(data.items);
    r.getCell(6).value = calcPOStatus(data.items);
  }
  r.getCell(9).value = now;
  r.commit();

  await workbook.xlsx.writeFile(EXCEL_PATH);
  return rowToPO(r);
}

// ============================================
// PO: Delete
// ============================================
export async function deletePO(id: string): Promise<boolean> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  let targetRowNumber: number | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === id) targetRowNumber = n; });
  if (targetRowNumber === null) return false;
  sheet.spliceRows(targetRowNumber, 1);
  await workbook.xlsx.writeFile(EXCEL_PATH);
  return true;
}

// ============================================
// PO: Receive item (update qty received, auto-update status)
// ============================================
export async function receivePOItem(
  poId: string,
  itemCode: string,
  qtyReceived: number
): Promise<PurchaseOrder | null> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  let targetRow: ExcelJS.Row | null = null;
  sheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === poId) targetRow = row; });
  if (!targetRow) return null;

  const r = targetRow as ExcelJS.Row;
  let items: PurchaseOrder["items"] = [];
  try { items = JSON.parse(String(r.getCell(7).value || "[]")); } catch { items = []; }

  const item = items.find((i) => i.itemCode === itemCode);
  if (item) {
    item.qtyReceived = qtyReceived;
  }

  r.getCell(7).value = JSON.stringify(items);
  r.getCell(6).value = calcPOStatus(items);
  r.getCell(9).value = getNow();
  r.commit();

  await workbook.xlsx.writeFile(EXCEL_PATH);
  return rowToPO(r);
}

// ============================================
// PO: Receive items from PO (full flow)
// Creates transaksi "Masuk" + updates stock + updates PO
// ============================================
export interface ReceiveItem {
  itemCode: string;
  namaBarang: string;
  qtyToReceive: number;
}

export async function receiveFromPO(
  poId: string,
  itemsToReceive: ReceiveItem[],
  keterangan: string
): Promise<{ created: number; poUpdated: PurchaseOrder }> {
  const workbook = await ensureWorkbook();
  const now = getNow();
  let created = 0;

  // 1. Find the PO
  const poSheet = workbook.getWorksheet(SHEET_PO)!;
  let poRow: ExcelJS.Row | null = null;
  poSheet.eachRow((row, n) => { if (n === 1) return; if (String(row.getCell(1).value) === poId) poRow = row; });
  if (!poRow) throw new Error("PO tidak ditemukan");

  const pr = poRow as ExcelJS.Row;
  const poNumber = String(pr.getCell(2).value || "");
  let poItems: PurchaseOrder["items"] = [];
  try { poItems = JSON.parse(String(pr.getCell(7).value || "[]")); } catch { poItems = []; }

  // 2. Get existing barang list for matching
  const barangSheet = workbook.getWorksheet(SHEET_BARANG)!;
  const trxSheet = workbook.getWorksheet(SHEET_TRANSAKSI)!;

  for (const recv of itemsToReceive) {
    if (recv.qtyToReceive <= 0) continue;

    // Find existing barang by itemCode
    let barangId = "";
    let barangKode = "";
    let barangNama = recv.namaBarang; // fallback ke nama dari PO jika tidak ada di Master Barang
    let barangSatuan = "Pcs";
    let stokSebelum = 0;

    barangSheet.eachRow((row, n) => {
      if (n === 1) return;
      const kode = String(row.getCell(2).value || "");
      if (kode === recv.itemCode) {
        barangId = String(row.getCell(1).value || "");
        barangKode = kode;
        barangNama = String(row.getCell(3).value || recv.namaBarang); // gunakan nama dari Master Barang
        barangSatuan = String(row.getCell(5).value || "Pcs");
        stokSebelum = Number(row.getCell(6).value) || 0;
      }
    });

    // Auto-create barang if not found
    if (!barangId) {
      barangId = generateId("BRG");
      barangKode = recv.itemCode;
      barangNama = recv.namaBarang;
      const newRow = barangSheet.addRow([
        barangId, recv.itemCode, recv.namaBarang, "Lainnya", "Pcs",
        0, 0, "", `Auto-created dari PO ${poNumber}`, now, now,
      ]);
      newRow.alignment = { vertical: "middle" };
      newRow.commit();
      stokSebelum = 0;
    }

    // Update barang stock
    const stokSesudah = stokSebelum + recv.qtyToReceive;
    barangSheet.eachRow((row, n) => {
      if (n === 1) return;
      if (String(row.getCell(1).value) === barangId) {
        row.getCell(6).value = stokSesudah;
        row.getCell(12).value = now;
        row.commit();
      }
    });

    // Create transaksi "Masuk" — gunakan nama dari Master Barang (bukan dari PO)
    const trxId = generateId("TRX");
    const trxNote = keterangan ? `${keterangan} (PO: ${poNumber})` : `Penerimaan dari PO: ${poNumber}`;
    const trxRow = trxSheet.addRow([
      trxId, now, "Masuk", barangId, barangKode, barangNama,
      recv.qtyToReceive, barangSatuan, stokSebelum, stokSesudah, trxNote, now,
    ]);
    trxRow.getCell(3).font = { bold: true, color: { argb: "FF10B981" } };
    trxRow.alignment = { vertical: "middle" };
    trxRow.commit();

    // Update PO item received qty (trim untuk toleransi spasi)
    const poItem = poItems.find((i) => i.itemCode.trim() === recv.itemCode.trim());
    if (poItem) {
      poItem.qtyReceived = (poItem.qtyReceived || 0) + recv.qtyToReceive;
    }

    created++;
  }

  // 3. Update PO status — deduplicate dulu sebelum tulis & hitung status
  const finalItems = deduplicatePOItems(poItems);
  const finalStatus = calcPOStatus(finalItems);
  pr.getCell(7).value = JSON.stringify(finalItems);
  pr.getCell(6).value = finalStatus;
  pr.getCell(9).value = now;
  pr.commit();

  await workbook.xlsx.writeFile(EXCEL_PATH);

  // Build return value langsung (jangan pakai rowToPO agar tidak double-count)
  const poUpdated: PurchaseOrder = {
    id: String(pr.getCell(1).value || ""),
    poNumber: String(pr.getCell(2).value || ""),
    poDate: String(pr.getCell(3).value || ""),
    supplier: String(pr.getCell(4).value || ""),
    description: String(pr.getCell(5).value || ""),
    status: finalStatus,
    items: finalItems,
    createdAt: String(pr.getCell(8).value || ""),
    updatedAt: now,
  };

  return { created, poUpdated };
}

// ============================================
// PO: Recalculate all PO statuses (fix stale status)
// ============================================
export async function recalcAllPOStatuses(): Promise<number> {
  const workbook = await ensureWorkbook();
  const sheet = workbook.getWorksheet(SHEET_PO)!;
  const now = getNow();
  let fixed = 0;

  sheet.eachRow((row, n) => {
    if (n === 1) return;
    const id = String(row.getCell(1).value || "");
    if (!id) return;

    let items: PurchaseOrder["items"] = [];
    try { items = deduplicatePOItems(JSON.parse(String(row.getCell(7).value || "[]"))); } catch { items = []; }

    const correctStatus = calcPOStatus(items);
    const currentStatus = String(row.getCell(6).value || "");

    if (currentStatus !== correctStatus) {
      row.getCell(6).value = correctStatus;
      row.getCell(7).value = JSON.stringify(items); // simpan versi dedup
      row.getCell(9).value = now;
      row.commit();
      fixed++;
    }
  });

  if (fixed > 0) await workbook.xlsx.writeFile(EXCEL_PATH);
  return fixed;
}

// ============================================
// LAPORAN: Generate Excel Report
// ============================================
export async function generateExcelReport(
  transaksiList: Transaksi[],
  barangList: Barang[],
  filter: { dari: string; sampai: string; tipe: string }
): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "Saberindo WMS";
  wb.created = new Date();

  // --- Sheet 1: Laporan Transaksi ---
  const s1 = wb.addWorksheet("Laporan Transaksi");

  // Title rows
  s1.mergeCells("A1:H1");
  const titleCell = s1.getCell("A1");
  titleCell.value = "LAPORAN TRANSAKSI GUDANG";
  titleCell.font = { bold: true, size: 14, color: { argb: "FF102A43" } };
  titleCell.alignment = { horizontal: "center", vertical: "middle" };
  s1.getRow(1).height = 30;

  s1.mergeCells("A2:H2");
  const subtitleCell = s1.getCell("A2");
  subtitleCell.value = `PT Saberindo Pacific — Fire Protection`;
  subtitleCell.font = { size: 10, color: { argb: "FF627D98" } };
  subtitleCell.alignment = { horizontal: "center" };

  s1.mergeCells("A3:H3");
  const periodCell = s1.getCell("A3");
  periodCell.value = `Periode: ${filter.dari || "Awal"} s/d ${filter.sampai || "Sekarang"}${filter.tipe ? ` | Tipe: ${filter.tipe}` : ""}`;
  periodCell.font = { size: 10, color: { argb: "FF627D98" } };
  periodCell.alignment = { horizontal: "center" };

  // Summary row
  const totalMasuk = transaksiList.filter(t => t.tipe === "Masuk");
  const totalKeluar = transaksiList.filter(t => t.tipe === "Keluar");
  const qtyMasuk = totalMasuk.reduce((s, t) => s + t.jumlah, 0);
  const qtyKeluar = totalKeluar.reduce((s, t) => s + t.jumlah, 0);

  s1.getRow(5).values = ["Total Transaksi:", transaksiList.length, "", "Masuk:", totalMasuk.length, `(${qtyMasuk} unit)`, "Keluar:", totalKeluar.length];
  s1.getRow(5).font = { bold: true, size: 10 };

  // Table headers at row 7
  const headers = ["No", "Tanggal", "Tipe", "Kode Barang", "Nama Barang", "Jumlah", "Stok Sebelum", "Stok Sesudah", "Keterangan"];
  const headerRow = s1.getRow(7);
  headerRow.values = headers;
  headerRow.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
  headerRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF102A43" } };
  headerRow.alignment = { horizontal: "center", vertical: "middle" };
  headerRow.height = 26;

  // Column widths
  s1.getColumn(1).width = 5;
  s1.getColumn(2).width = 20;
  s1.getColumn(3).width = 10;
  s1.getColumn(4).width = 14;
  s1.getColumn(5).width = 30;
  s1.getColumn(6).width = 10;
  s1.getColumn(7).width = 14;
  s1.getColumn(8).width = 14;
  s1.getColumn(9).width = 30;

  // Data rows
  transaksiList.forEach((trx, i) => {
    const row = s1.getRow(8 + i);
    row.values = [i + 1, trx.tanggal, trx.tipe, trx.kodeBarang, trx.namaBarang, trx.jumlah, trx.stokSebelum, trx.stokSesudah, trx.keterangan];
    row.alignment = { vertical: "middle" };

    // Color code tipe
    const tipeCell = row.getCell(3);
    tipeCell.font = { bold: true, color: { argb: trx.tipe === "Masuk" ? "FF10B981" : "FFEF4444" } };

    // Alternating row color
    if (i % 2 === 0) {
      row.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF7FAFC" } };
    }
  });

  // Borders for all data cells
  const lastDataRow = 7 + transaksiList.length;
  for (let r = 7; r <= lastDataRow; r++) {
    for (let c = 1; c <= 9; c++) {
      s1.getRow(r).getCell(c).border = {
        top: { style: "thin", color: { argb: "FFD9E2EC" } },
        bottom: { style: "thin", color: { argb: "FFD9E2EC" } },
        left: { style: "thin", color: { argb: "FFD9E2EC" } },
        right: { style: "thin", color: { argb: "FFD9E2EC" } },
      };
    }
  }

  // --- Sheet 2: Ringkasan Stok ---
  const s2 = wb.addWorksheet("Ringkasan Stok");

  s2.mergeCells("A1:G1");
  s2.getCell("A1").value = "RINGKASAN STOK BARANG";
  s2.getCell("A1").font = { bold: true, size: 14, color: { argb: "FF102A43" } };
  s2.getCell("A1").alignment = { horizontal: "center" };
  s2.getRow(1).height = 30;

  const stockHeaders = ["No", "Kode", "Nama Barang", "Kategori", "Stok", "Minimum", "Status"];
  const shRow = s2.getRow(3);
  shRow.values = stockHeaders;
  shRow.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 10 };
  shRow.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF102A43" } };
  shRow.alignment = { horizontal: "center", vertical: "middle" };
  shRow.height = 26;

  s2.getColumn(1).width = 5;
  s2.getColumn(2).width = 14;
  s2.getColumn(3).width = 35;
  s2.getColumn(4).width = 18;
  s2.getColumn(5).width = 10;
  s2.getColumn(6).width = 10;
  s2.getColumn(7).width = 12;

  const sortedBarang = [...barangList].sort((a, b) => {
    const sa = a.stok === 0 ? 0 : a.stok <= a.stokMinimum ? 1 : 2;
    const sb = b.stok === 0 ? 0 : b.stok <= b.stokMinimum ? 1 : 2;
    return sa - sb;
  });

  sortedBarang.forEach((b, i) => {
    const row = s2.getRow(4 + i);
    const status = b.stok === 0 ? "KOSONG" : b.stok <= b.stokMinimum ? "RENDAH" : "AMAN";
    row.values = [i + 1, b.kode, b.nama, b.kategori, b.stok, b.stokMinimum, status];
    row.alignment = { vertical: "middle" };

    const statusCell = row.getCell(7);
    statusCell.font = {
      bold: true,
      color: { argb: status === "KOSONG" ? "FFEF4444" : status === "RENDAH" ? "FFF59E0B" : "FF10B981" },
    };

    if (i % 2 === 0) {
      row.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF7FAFC" } };
    }

    for (let c = 1; c <= 7; c++) {
      row.getCell(c).border = {
        top: { style: "thin", color: { argb: "FFD9E2EC" } },
        bottom: { style: "thin", color: { argb: "FFD9E2EC" } },
        left: { style: "thin", color: { argb: "FFD9E2EC" } },
        right: { style: "thin", color: { argb: "FFD9E2EC" } },
      };
    }
  });

  // Footer
  const footerRow = s2.getRow(4 + sortedBarang.length + 1);
  footerRow.getCell(1).value = `Dicetak: ${getNow()}`;
  footerRow.getCell(1).font = { size: 9, italic: true, color: { argb: "FF829AB1" } };

  const buffer = await wb.xlsx.writeBuffer();
  return Buffer.from(buffer);
}