export interface Barang {
  id: string;
  kode: string;
  nama: string;
  kategori: string;
  satuan: string;
  stok: number;
  stokMinimum: number;
  stokAwal: number;  // untuk threshold notifikasi 40%
  lokasi: string;
  keterangan: string;
  createdAt: string;
  updatedAt: string;
}

export interface BarangFormData {
  kode: string;
  nama: string;
  kategori: string;
  satuan: string;
  stok: number;
  stokMinimum: number;
  stokAwal: number;  // untuk threshold notifikasi 40%
  lokasi: string;
  keterangan: string;
}

export const KATEGORI_OPTIONS = [
  "APAR",
  "Sprinkler",
  "Hydrant",
  "Fire Alarm",
  "Valve & Fitting",
  "Pipa",
  "Selang",
  "Nozzle",
  "Foam & Chemical",
  "Aksesori",
  "Lainnya",
] as const;

export const SATUAN_OPTIONS = [
  "Pcs",
  "Unit",
  "Set",
  "Meter",
  "Roll",
  "Kg",
  "Liter",
  "Box",
  "Dozen",
  "Batang",
] as const;

// ============================================
// Transaksi (Part 2)
// ============================================
export type TipeTransaksi = "Masuk" | "Keluar";

export interface Transaksi {
  id: string;
  tanggal: string;
  tipe: TipeTransaksi;
  barangId: string;
  kodeBarang: string;
  namaBarang: string;
  jumlah: number;
  satuanBarang: string;
  stokSebelum: number;
  stokSesudah: number;
  keterangan: string;
  createdAt: string;
}

export interface TransaksiFormData {
  tipe: TipeTransaksi;
  barangId: string;
  jumlah: number;
  keterangan: string;
}

// ============================================
// Lokasi Gudang (Part 4)
// ============================================
export interface Lokasi {
  id: string;
  kode: string;
  nama: string;
  zona: string;
  kapasitas: number;
  terpakai: number;
  keterangan: string;
  createdAt: string;
  updatedAt: string;
}

export interface LokasiFormData {
  kode: string;
  nama: string;
  zona: string;
  kapasitas: number;
  keterangan: string;
}

export const ZONA_OPTIONS = [
  "Gudang Utama",
  "Gudang B",
  "Zona A",
  "Zona B",
  "Zona C",
  "Outdoor",
  "Staging Area",
] as const;

// ============================================
// Purchase Order (Part 6)
// ============================================
export type POStatus = "Pending" | "Partial" | "Complete";

export interface POItem {
  itemCode: string;
  namaBarang: string;
  qtyOrdered: number;
  qtyReceived: number;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  poDate: string;
  supplier: string;
  description: string;
  status: POStatus;
  items: POItem[];
  createdAt: string;
  updatedAt: string;
}

export interface POFormData {
  poNumber: string;
  poDate: string;
  supplier: string;
  description: string;
  items: POItem[];
}

// ============================================
// Laporan (Part 5)
// ============================================
export interface LaporanFilter {
  dari: string;     // date string YYYY-MM-DD
  sampai: string;   // date string YYYY-MM-DD
  tipe: "" | "Masuk" | "Keluar";
  kategori: string;
}

export interface LaporanSummary {
  totalTransaksi: number;
  totalMasuk: number;
  totalKeluar: number;
  jumlahMasuk: number;   // total qty masuk
  jumlahKeluar: number;  // total qty keluar
  barangTerbanyakMasuk: string;
  barangTerbanyakKeluar: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
}

export interface DashboardStats {
  totalBarang: number;
  totalStok: number;
  stokRendah: number;
  stokKosong: number;
  kategoriCount: Record<string, number>;
  totalTransaksiHariIni: number;
  totalMasukHariIni: number;
  totalKeluarHariIni: number;
}