import { NextRequest, NextResponse } from "next/server";

export function verifyAuth(request: NextRequest): boolean {
  const authCookie = request.cookies.get("wms_auth");
  return authCookie?.value === "authenticated";
}

export function unauthorizedResponse() {
  return NextResponse.json(
    { success: false, error: "Unauthorized" },
    { status: 401 }
  );
}
