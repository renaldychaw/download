"use client";

import { useEffect, useState } from "react";
import { Bell, AlertTriangle, X, ArrowRight, Menu } from "lucide-react";
import { Barang } from "@/lib/types";

interface TopbarProps {
  onMenuClick?: () => void;
}

export default function Topbar({ onMenuClick }: TopbarProps) {
  const [alertItems, setAlertItems] = useState<Barang[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);

  const fetchAlerts = async () => {
    try {
      const res = await fetch("/api/barang");
      const data = await res.json();
      if (data.success) {
        const critical = (data.data as Barang[]).filter((b) => {
          if (b.stokAwal > 0) {
            return b.stok <= b.stokAwal * 0.4;
          }
          return b.stok <= b.stokMinimum;
        });
        setAlertItems(critical);
      }
    } catch {
      // silent fail
    }
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000);
    return () => clearInterval(interval);
  }, []);

  const alertCount = alertItems.length;

  return (
    <div className="sticky top-0 z-20 bg-white/80 backdrop-blur-md border-b border-navy-100">
      <div className="flex items-center gap-3 px-4 lg:px-8 py-3">
        {/* Hamburger button — mobile only */}
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-lg text-navy-500 hover:bg-navy-50 hover:text-navy-700 transition-colors"
          aria-label="Buka menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Left: Alert banner if critical items exist */}
        <div className="flex-1 min-w-0">
          {alertCount > 0 && (
            <div className="flex items-center gap-2 text-sm">
              <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
              <span className="text-navy-600 truncate">
                <span className="font-semibold text-amber-600">{alertCount} barang</span>
                <span className="hidden sm:inline"> di bawah stok minimum</span>
              </span>
              <a
                href="/dashboard/stok"
                className="text-brand-600 hover:text-brand-700 font-medium text-xs ml-1 flex-shrink-0"
              >
                Lihat →
              </a>
            </div>
          )}
        </div>

        {/* Right: Notification bell */}
        <div className="relative flex-shrink-0">
          <button
            onClick={() => setShowDropdown(!showDropdown)}
            className="relative p-2 rounded-lg text-navy-400 hover:bg-navy-50 hover:text-navy-600 transition-colors"
          >
            <Bell className="w-5 h-5" />
            {alertCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white">
                {alertCount > 9 ? "9+" : alertCount}
              </span>
            )}
          </button>

          {/* Dropdown */}
          {showDropdown && (
            <>
              <div
                className="fixed inset-0 z-10"
                onClick={() => setShowDropdown(false)}
              />
              <div className="absolute right-0 top-full mt-2 w-80 max-w-[calc(100vw-2rem)] card shadow-xl z-20 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-3 border-b border-navy-100 bg-navy-50/50">
                  <h3 className="text-sm font-semibold text-navy-800">
                    Alert Stok ({alertCount})
                  </h3>
                  <button
                    onClick={() => setShowDropdown(false)}
                    className="p-1 rounded text-navy-400 hover:text-navy-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {alertCount === 0 ? (
                  <div className="px-4 py-6 text-center text-sm text-navy-400">
                    Semua stok aman, tidak ada alert.
                  </div>
                ) : (
                  <div className="max-h-64 overflow-y-auto divide-y divide-navy-50">
                    {alertItems.map((item) => (
                      <div
                        key={item.id}
                        className="px-4 py-3 hover:bg-navy-50/50 transition-colors"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-sm font-medium text-navy-800 truncate">
                              {item.nama}
                            </p>
                            <p className="text-xs text-navy-400 mt-0.5">
                              <span className="font-mono">{item.kode}</span>
                              {item.lokasi && <> &bull; {item.lokasi}</>}
                            </p>
                          </div>
                          <span
                            className={`flex-shrink-0 text-xs font-bold px-2 py-0.5 rounded-full ${
                              item.stok === 0
                                ? "bg-red-100 text-red-700"
                                : "bg-amber-100 text-amber-700"
                            }`}
                          >
                            {item.stok === 0 ? "KOSONG" : item.stokAwal > 0 ? `${item.stok}/${item.stokAwal}` : `${item.stok}/${item.stokMinimum}`}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {alertCount > 0 && (
                  <a
                    href="/dashboard/stok"
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 text-xs font-semibold text-brand-600 hover:bg-brand-50 border-t border-navy-100 transition-colors"
                    onClick={() => setShowDropdown(false)}
                  >
                    Buka Stok Monitor
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
