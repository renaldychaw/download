"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Package,
  ArrowLeftRight,
  Activity,
  MapPin,
  FileBarChart,
  ClipboardList,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Flame,
  Download,
  X,
} from "lucide-react";
import { useState, useEffect } from "react";
import toast from "react-hot-toast";

const menuItems = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Master Barang", href: "/dashboard/barang", icon: Package },
  { label: "Purchase Order", href: "/dashboard/po", icon: ClipboardList },
  { label: "Barang Masuk/Keluar", href: "/dashboard/transaksi", icon: ArrowLeftRight },
  { label: "Stok Monitor", href: "/dashboard/stok", icon: Activity },
  { label: "Lokasi Gudang", href: "/dashboard/lokasi", icon: MapPin },
  { label: "Laporan & Export", href: "/dashboard/laporan", icon: FileBarChart },
];

const upcomingItems: { label: string; icon: typeof LayoutDashboard; part: string }[] = [];

interface SidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

export default function Sidebar({ mobileOpen = false, onMobileClose }: SidebarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [collapsed, setCollapsed] = useState(false);

  // Close mobile sidebar on route change
  useEffect(() => {
    onMobileClose?.();
  }, [pathname]);

  const handleLogout = async () => {
    await fetch("/api/auth", { method: "DELETE" });
    router.push("/");
  };

  const handleDownloadExcel = async () => {
    try {
      const res = await fetch("/api/download");
      if (!res.ok) {
        toast.error("File Excel belum tersedia");
        return;
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `warehouse_${new Date().toISOString().slice(0, 10)}.xlsx`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("File Excel berhasil diunduh");
    } catch {
      toast.error("Gagal mengunduh file");
    }
  };

  const sidebarContent = (isMobile: boolean) => (
    <aside
      className={`h-full bg-navy-900 text-white flex flex-col ${
        isMobile ? "w-72" : collapsed ? "w-[72px]" : "w-64"
      }`}
    >
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-navy-700/50">
        <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-brand-600 flex items-center justify-center">
          <Flame className="w-5 h-5 text-white" />
        </div>
        {(isMobile || !collapsed) && (
          <div className="min-w-0 flex-1">
            <h1 className="text-sm font-bold truncate">Saberindo WMS</h1>
            <p className="text-[11px] text-navy-400 truncate">Fire Protection</p>
          </div>
        )}
        {isMobile && (
          <button
            onClick={onMobileClose}
            className="p-1.5 rounded-lg text-navy-400 hover:text-white hover:bg-navy-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
        <div className={`text-[10px] uppercase tracking-widest text-navy-500 font-semibold mb-2 ${(!isMobile && collapsed) ? "text-center" : "px-3"}`}>
          {(!isMobile && collapsed) ? "•" : "Menu"}
        </div>

        {menuItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all ${
                isActive
                  ? "bg-brand-600 text-white shadow-md shadow-brand-600/20"
                  : "text-navy-300 hover:bg-navy-800 hover:text-white"
              } ${(!isMobile && collapsed) ? "justify-center" : ""}`}
              title={(!isMobile && collapsed) ? item.label : undefined}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {(isMobile || !collapsed) && item.label}
            </Link>
          );
        })}

        {/* Upcoming */}
        <div className={`text-[10px] uppercase tracking-widest text-navy-600 font-semibold mt-6 mb-2 ${(!isMobile && collapsed) ? "text-center" : "px-3"}`}>
          {(!isMobile && collapsed) ? "•" : "Segera Hadir"}
        </div>

        {upcomingItems.map((item) => (
          <div
            key={item.label}
            className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-navy-600 cursor-not-allowed ${
              (!isMobile && collapsed) ? "justify-center" : ""
            }`}
            title={(!isMobile && collapsed) ? `${item.label} (${item.part})` : undefined}
          >
            <item.icon className="w-5 h-5 flex-shrink-0" />
            {(isMobile || !collapsed) && (
              <div className="flex items-center justify-between w-full">
                <span>{item.label}</span>
                <span className="text-[10px] bg-navy-800 px-1.5 py-0.5 rounded-md">{item.part}</span>
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className="border-t border-navy-700/50 p-3 space-y-1">
        <button
          onClick={handleDownloadExcel}
          className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-navy-400 hover:bg-navy-800 hover:text-emerald-400 transition-all w-full ${
            (!isMobile && collapsed) ? "justify-center" : ""
          }`}
          title={(!isMobile && collapsed) ? "Download Excel" : undefined}
        >
          <Download className="w-5 h-5 flex-shrink-0" />
          {(isMobile || !collapsed) && "Download Excel"}
        </button>

        <button
          onClick={handleLogout}
          className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-navy-400 hover:bg-navy-800 hover:text-red-400 transition-all w-full ${
            (!isMobile && collapsed) ? "justify-center" : ""
          }`}
          title={(!isMobile && collapsed) ? "Logout" : undefined}
        >
          <LogOut className="w-5 h-5 flex-shrink-0" />
          {(isMobile || !collapsed) && "Logout"}
        </button>

        {/* Collapse button — desktop only */}
        {!isMobile && (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-navy-500 hover:bg-navy-800 hover:text-navy-300 transition-all w-full ${
              collapsed ? "justify-center" : ""
            }`}
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <><ChevronLeft className="w-4 h-4" /><span>Collapse</span></>
            )}
          </button>
        )}
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop sidebar — fixed */}
      <div
        className={`hidden lg:flex fixed left-0 top-0 h-screen z-30 transition-all duration-300 ${
          collapsed ? "w-[72px]" : "w-64"
        }`}
      >
        {sidebarContent(false)}
      </div>

      {/* Mobile sidebar — overlay drawer */}
      {mobileOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40 bg-black/50 lg:hidden"
            onClick={onMobileClose}
          />
          {/* Drawer */}
          <div className="fixed left-0 top-0 h-full z-50 lg:hidden shadow-2xl">
            {sidebarContent(true)}
          </div>
        </>
      )}
    </>
  );
}
