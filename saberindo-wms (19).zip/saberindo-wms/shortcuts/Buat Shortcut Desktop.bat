@echo off
title Saberindo WMS - Buat Shortcut Desktop
color 0B

echo ==========================================
echo   Saberindo WMS - Buat Shortcut Desktop
echo ==========================================
echo.

:: Detect IP address
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    set "LOCAL_IP=%%a"
    goto :found_ip
)
:found_ip
set LOCAL_IP=%LOCAL_IP: =%

echo [i] IP komputer ini: %LOCAL_IP%
echo.
echo Pilih mode:
echo   1. Shortcut untuk PC INI (localhost)
echo   2. Shortcut untuk PC LAIN di jaringan (IP: %LOCAL_IP%)
echo.
set /p MODE="Pilih (1/2): "

if "%MODE%"=="1" (
    set "WMS_URL=http://localhost:3000"
    echo [*] Membuat shortcut ke localhost...
) else (
    set "WMS_URL=http://%LOCAL_IP%:3000"
    echo [*] Membuat shortcut ke %LOCAL_IP%:3000...
)

:: Create .url shortcut on Desktop
set "DESKTOP=%USERPROFILE%\Desktop"
set "SHORTCUT=%DESKTOP%\Saberindo WMS.url"

echo [InternetShortcut]> "%SHORTCUT%"
echo URL=%WMS_URL%>> "%SHORTCUT%"
echo IconFile=C:\Windows\System32\shell32.dll>> "%SHORTCUT%"
echo IconIndex=13>> "%SHORTCUT%"

echo.
echo ==========================================
echo   Shortcut berhasil dibuat!
echo   Lokasi: %SHORTCUT%
echo   URL: %WMS_URL%
echo ==========================================
echo.

:: If mode 2, also create the shortcut file for distribution
if "%MODE%"=="2" (
    set "DIST_SHORTCUT=%~dp0Saberindo WMS (LAN).url"
    echo [InternetShortcut]> "%DIST_SHORTCUT%"
    echo URL=%WMS_URL%>> "%DIST_SHORTCUT%"
    echo IconFile=C:\Windows\System32\shell32.dll>> "%DIST_SHORTCUT%"
    echo IconIndex=13>> "%DIST_SHORTCUT%"
    echo.
    echo [+] File "Saberindo WMS (LAN).url" juga dibuat.
    echo     Kirim file ini ke PC kepala gudang,
    echo     taruh di Desktop-nya.
    echo.
)

pause
