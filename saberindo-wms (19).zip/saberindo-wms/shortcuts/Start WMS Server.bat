@echo off
title Saberindo WMS Server
color 0A

echo ==========================================
echo   Saberindo WMS - Fire Protection
echo   Warehouse Management System
echo ==========================================
echo.

:: Path ke folder project (otomatis dari lokasi bat file)
cd /d "%~dp0.."

:: Cek apakah node_modules ada
if not exist "node_modules" (
    echo [!] Installing dependencies...
    call npm install
    echo.
)

echo [*] Starting server...
echo [*] Buka browser: http://localhost:3000
echo [*] Tekan Ctrl+C untuk stop server
echo.

:: Buka browser setelah 3 detik (biar server sempat start)
start /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:3000"

:: Start server
call npm run dev
