@echo off
title Saberindo WMS Server (Production)
color 0A

echo ==========================================
echo   Saberindo WMS - Production Mode
echo   Warehouse Management System
echo ==========================================
echo.

cd /d "%~dp0.."

:: Cek apakah sudah di-build
if not exist ".next" (
    echo [*] Building project...
    call npm run build
    echo.
)

:: Tampilkan IP untuk akses dari PC lain
echo [i] Akses dari PC ini  : http://localhost:3000
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    echo [i] Akses dari PC lain : http://%%a:3000
    goto :start
)

:start
echo.
echo [*] Server berjalan. Jangan tutup window ini.
echo [*] Tekan Ctrl+C untuk stop.
echo.

call npm start
