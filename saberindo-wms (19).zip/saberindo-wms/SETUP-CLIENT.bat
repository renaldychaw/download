@echo off
title Saberindo WMS - Setup Akses
color 0B
chcp 65001 >nul 2>&1

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║    SABERINDO WMS - SETUP AKSES               ║
echo  ║    Untuk PC Kepala Gudang / Staff             ║
echo  ╚══════════════════════════════════════════════╝
echo.
echo  Script ini membuat shortcut di Desktop
echo  agar bisa langsung akses WMS.
echo.
echo  ──────────────────────────────────────────────
echo.

set /p SERVER_IP="  Masukkan IP PC Server (contoh: 192.168.1.100): "

if "%SERVER_IP%"=="" (
    echo  IP tidak boleh kosong!
    pause
    exit /b 1
)

set "WMS_URL=http://%SERVER_IP%:3000"
set "DESKTOP=%USERPROFILE%\Desktop"

:: Create shortcut
echo [InternetShortcut]> "%DESKTOP%\Saberindo WMS.url"
echo URL=%WMS_URL%>> "%DESKTOP%\Saberindo WMS.url"
echo IconFile=C:\Windows\System32\shell32.dll>> "%DESKTOP%\Saberindo WMS.url"
echo IconIndex=13>> "%DESKTOP%\Saberindo WMS.url"

echo.
echo  ══════════════════════════════════════════════
echo.
echo  Shortcut "Saberindo WMS" berhasil dibuat
echo  di Desktop!
echo.
echo  Klik 2x icon tersebut untuk buka WMS.
echo  Login password: saberindo2024
echo.
echo  URL: %WMS_URL%
echo.
echo  ══════════════════════════════════════════════
echo.

set /p OPEN_NOW="  Buka WMS sekarang? (y/n): "
if /i "%OPEN_NOW%"=="y" start %WMS_URL%

pause
