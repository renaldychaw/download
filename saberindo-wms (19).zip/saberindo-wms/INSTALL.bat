@echo off
setlocal enabledelayedexpansion
title Saberindo WMS - Auto Installer
color 0B
chcp 65001 >nul 2>&1

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║    SABERINDO WMS - AUTO INSTALLER            ║
echo  ║    Warehouse Management System               ║
echo  ║    PT Saberindo Pacific                       ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ============================================
:: Config — ubah path sesuai kebutuhan
:: ============================================
set "PROJECT_DIR=%~dp0"
set "ERRORS=0"

echo  [i] Lokasi project: %PROJECT_DIR%
echo.
echo  Mengecek kebutuhan sistem...
echo  ──────────────────────────────────────────────
echo.

:: ============================================
:: 1. Cek Node.js
:: ============================================
echo  [1/5] Mengecek Node.js...
where node >nul 2>&1
if %ERRORLEVEL%==0 (
    for /f "tokens=1" %%v in ('node --version') do set "NODE_VER=%%v"
    echo        OK - Node.js !NODE_VER! terinstall
) else (
    echo        BELUM TERINSTALL
    echo.
    echo  ┌─────────────────────────────────────────┐
    echo  │  Node.js belum terinstall!               │
    echo  │                                          │
    echo  │  Download dari:                          │
    echo  │  https://nodejs.org/en/download           │
    echo  │                                          │
    echo  │  Pilih "Windows Installer (.msi)"        │
    echo  │  Install, lalu jalankan script ini lagi  │
    echo  └─────────────────────────────────────────┘
    echo.
    set /p OPEN_NODE="  Buka halaman download Node.js? (y/n): "
    if /i "!OPEN_NODE!"=="y" start https://nodejs.org/en/download
    set /a ERRORS+=1
    goto :check_python
)

:: ============================================
:: 2. Cek Python
:: ============================================
:check_python
echo.
echo  [2/5] Mengecek Python...

:: Try "python" first (Windows default), then "python3"
set "PYTHON_CMD="
where python >nul 2>&1
if %ERRORLEVEL%==0 (
    :: Verify it's real Python, not Windows Store alias
    python --version >nul 2>&1
    if !ERRORLEVEL!==0 (
        for /f "tokens=*" %%v in ('python --version 2^>^&1') do set "PYTHON_VER=%%v"
        set "PYTHON_CMD=python"
        echo        OK - !PYTHON_VER! terinstall
    )
)

if "!PYTHON_CMD!"=="" (
    where python3 >nul 2>&1
    if !ERRORLEVEL!==0 (
        for /f "tokens=*" %%v in ('python3 --version 2^>^&1') do set "PYTHON_VER=%%v"
        set "PYTHON_CMD=python3"
        echo        OK - !PYTHON_VER! terinstall
    )
)

if "!PYTHON_CMD!"=="" (
    echo        BELUM TERINSTALL
    echo.
    echo  ┌──────────────────────────────────────────────┐
    echo  │  Python belum terinstall!                     │
    echo  │                                               │
    echo  │  Download dari:                               │
    echo  │  https://www.python.org/downloads/             │
    echo  │                                               │
    echo  │  PENTING: Centang "Add Python to PATH"        │
    echo  │  saat install!                                │
    echo  │                                               │
    echo  │  Install, lalu jalankan script ini lagi       │
    echo  └──────────────────────────────────────────────┘
    echo.
    set /p OPEN_PY="  Buka halaman download Python? (y/n): "
    if /i "!OPEN_PY!"=="y" start https://www.python.org/downloads/
    set /a ERRORS+=1
    goto :check_deps
)

:: ============================================
:: 3. Install Python dependencies (pdfplumber)
:: ============================================
echo.
echo  [3/5] Mengecek Python packages...

!PYTHON_CMD! -c "import pdfplumber" >nul 2>&1
if %ERRORLEVEL%==0 (
    echo        OK - pdfplumber sudah terinstall
) else (
    echo        Installing pdfplumber...
    !PYTHON_CMD! -m pip install pdfplumber --quiet 2>nul
    if !ERRORLEVEL!==0 (
        echo        OK - pdfplumber berhasil diinstall
    ) else (
        echo        GAGAL - Coba jalankan manual:
        echo               pip install pdfplumber
        set /a ERRORS+=1
    )
)

:: ============================================
:: 4. Install Node.js dependencies
:: ============================================
:check_deps
echo.
echo  [4/5] Mengecek Node.js packages...

where node >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo        SKIP - Node.js belum terinstall
    goto :create_shortcuts
)

cd /d "%PROJECT_DIR%"

if exist "node_modules\next" (
    echo        OK - node_modules sudah ada
) else (
    echo        Installing npm packages...
    call npm install --loglevel=error 2>nul
    if !ERRORLEVEL!==0 (
        echo        OK - npm packages berhasil diinstall
    ) else (
        echo        GAGAL - Coba jalankan manual:
        echo               npm install
        set /a ERRORS+=1
    )
)

:: ============================================
:: 5. Setup environment file
:: ============================================
echo.
echo  [5/5] Mengecek konfigurasi...

cd /d "%PROJECT_DIR%"

if exist ".env.local" (
    echo        OK - .env.local sudah ada
) else (
    if exist ".env.local.example" (
        copy ".env.local.example" ".env.local" >nul
        echo        OK - .env.local dibuat dari template
    ) else (
        echo # Admin Login Password> ".env.local"
        echo ADMIN_PASSWORD=saberindo2024>> ".env.local"
        echo        OK - .env.local dibuat (password: saberindo2024)
    )
)

:: ============================================
:: Create data directory
:: ============================================
if not exist "data" mkdir data

:: ============================================
:: Create desktop shortcuts
:: ============================================
:create_shortcuts
echo.
echo  ──────────────────────────────────────────────
echo.

:: Detect local IP
set "LOCAL_IP=localhost"
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    set "LOCAL_IP=%%a"
    set "LOCAL_IP=!LOCAL_IP: =!"
    goto :got_ip
)
:got_ip

echo  Membuat shortcut di Desktop...

set "DESKTOP=%USERPROFILE%\Desktop"

:: Create WMS shortcut
echo [InternetShortcut]> "%DESKTOP%\Saberindo WMS.url"
echo URL=http://localhost:3000>> "%DESKTOP%\Saberindo WMS.url"
echo IconFile=C:\Windows\System32\shell32.dll>> "%DESKTOP%\Saberindo WMS.url"
echo IconIndex=13>> "%DESKTOP%\Saberindo WMS.url"
echo        OK - "Saberindo WMS" shortcut dibuat di Desktop

:: Create Start Server shortcut  
echo [InternetShortcut]> "%DESKTOP%\Start WMS Server.url"
echo URL=file:///%PROJECT_DIR:\=/%shortcuts/Start WMS Server.bat>> "%DESKTOP%\Start WMS Server.url"
echo        OK - "Start WMS Server" shortcut dibuat di Desktop

:: Also create LAN shortcut for other PCs
echo [InternetShortcut]> "%PROJECT_DIR%shortcuts\Saberindo WMS (LAN).url"
echo URL=http://!LOCAL_IP!:3000>> "%PROJECT_DIR%shortcuts\Saberindo WMS (LAN).url"
echo IconFile=C:\Windows\System32\shell32.dll>> "%PROJECT_DIR%shortcuts\Saberindo WMS (LAN).url"
echo IconIndex=13>> "%PROJECT_DIR%shortcuts\Saberindo WMS (LAN).url"

:: ============================================
:: Summary
:: ============================================
echo.
echo  ══════════════════════════════════════════════
echo.

if %ERRORS%==0 (
    color 0A
    echo  ✓ INSTALASI BERHASIL!
    echo.
    echo  Semua kebutuhan sudah terpenuhi.
    echo.
    echo  ┌──────────────────────────────────────────────┐
    echo  │                                               │
    echo  │  Cara menjalankan WMS:                        │
    echo  │                                               │
    echo  │  1. Klik 2x "Start WMS Server.bat"            │
    echo  │     di folder shortcuts/                       │
    echo  │                                               │
    echo  │  2. Klik 2x "Saberindo WMS" di Desktop        │
    echo  │                                               │
    echo  │  Login: password = saberindo2024               │
    echo  │                                               │
    echo  │  Akses dari PC lain (LAN):                    │
    echo  │  http://!LOCAL_IP!:3000                       │
    echo  │                                               │
    echo  └──────────────────────────────────────────────┘
) else (
    color 0C
    echo  ⚠ INSTALASI BELUM LENGKAP
    echo.
    echo  Ada %ERRORS% komponen yang belum terinstall.
    echo  Install komponen yang kurang, lalu jalankan
    echo  script ini lagi.
)

echo.
echo  ══════════════════════════════════════════════
echo.

set /p START_NOW="  Mau langsung jalankan WMS server? (y/n): "
if /i "%START_NOW%"=="y" (
    echo.
    echo  Starting WMS server...
    cd /d "%PROJECT_DIR%"
    start http://localhost:3000
    call npm run dev
)

pause
